# Independent synthetic demo operations

## Boundaries and current deployment status

Public deployment is NOT verified. The proposed hostname is `rewards-demo.driveonyxsolutions.com`; a no-answer DNS lookup is not proof of availability or zone permission. The existing portal, its process on 4173 and its Cloudflare connector are not RewardPoint resources and must not be edited, stopped or reused.

The current computer has an existing Cloudflare connector service but no discovered account/zone administration credential or signed-in administration surface. A connector token is not permission to create routes. The missing input is an authorized local account configuration path or signed-in dashboard, not a token pasted into chat. No DNS record, connector, paid service or deployment workflow has been created.

RewardPoint uses 4184 for its separate loopback origin, 4187 for isolated browser tests, 4188 for process-restart tests and 4191 for rollback rehearsal. Verify each is free before use. Keep the server loopback-only. SQLite and captured recovery links belong only to this application.

## Start and stop

See README for first installation. Do not rerun setup or seed against existing data. For an existing instance, back up before migrations, run `npm run db:migrate`, then `npm run build` and `npm start`. The production frontend and API are served by Express; Vite dev/preview is not the deployed server.

Stop only the foreground RewardPoint process with Ctrl+C. If running separately, identify its exact listening PID and working directory before sending SIGTERM. Never use blanket process-name kills. Startup requires all three checksummed application migrations and valid demo configuration. Auth migrations are provided by Better Auth. No secret values are logged.

For an immutable release built from a clean checkout:

```sh
npm ci
npm run build
npm run snapshot -- release-name
npm run serve:release -- release-name
```

The artifact contains built frontend/server code and metadata, not secrets or a database. The launcher verifies the dependency lock hash and uses absolute database/capture paths with the existing private environment. `dist/release.json` and `/api/health` expose the build commit, dirty flag and build time; `/api/ready` checks database readiness. A dirty artifact is a development checkpoint, not a clean release. Review the build identity, not just the configured release label.

## Backup and restore

```sh
npm run backup -- .local/backups/operator-selected-name.sqlite
npm run restore -- .local/backups/operator-selected-name.sqlite .local/restore-check/new.sqlite
```

Backup uses SQLite's online backup API, not a raw copy of an open WAL database. Files are private and excluded from Git. Restore refuses an existing destination, creates a separate database, and checks integrity and foreign keys. Start a separate RewardPoint instance with its database path pointing to the restored file before considering a cutover. Do not replace a live database or its WAL files. Protect the auth secret separately: encrypted referral tokens depend on it, and careless rotation invalidates existing links/sessions.

The automated restoration test verifies customers, leads, consents, ledger, audit, operation retries and receipts, plus exact reconciliation. The real local demo also has a verified pre-hardening backup and a separately restored copy. Backup files may contain session/recovery material; never upload them with test evidence.

## Rollback

```sh
npm run rehearse:rollback -- .local/releases/checkpoint-a .local/releases/checkpoint-b
```

The rehearsal stages two distinct built artifacts into non-hidden runtime directories, creates a disposable database, and runs A -> B -> A on 4191. Each step verifies the exact frontend bytes, authenticated customer data and the same durable session. It never touches either live origin. An early rehearsal exposed an old deep-link issue under hidden artifact paths; current code uses an explicit static root and supports `.local/releases`.

For a real rollback, stop ONLY RewardPoint, take a backup, validate the previous artifact and matching dependency lock, and restart that release. Do not run an older binary against a newer incompatible schema. This rehearsal proves compatible application rollback, not destructive schema downgrade. For incompatible migrations, restore the pre-change backup to a new database and test it separately before changing the RewardPoint configuration. Retain the failed version and database for investigation.

## Authentication and capture mode

Operator-only initial credentials are in `.local/demo-access.txt`, never in the UI, source, CI or public docs. Use the generated account names for synthetic tests; distribute access privately. Public signup is disabled. Administrators can provision synthetic staff or verified customers, but cannot silently take over an existing account. Recovery links are single-use, privately captured, and revoke old sessions when used. Do not publish captured links or browser traces.

Only `.invalid` addresses and `APP_ENV=demo|test` are accepted. `NOTIFICATION_MODE=capture` and `LIVE_CAMPAIGNS_ENABLED=false` are enforced server-side. D01-D12 remain unapproved assumptions. Notifications are queued, suppression-checked again and captured, never sent. Private Settings shows captured previews; it never claims delivery. No money, real invoice adjustment or payment gateway is involved.

## Authorized public deployment procedure

Once account/zone access is available, inspect the proposed hostname's DNS and existing route ownership. Create a separately named RewardPoint tunnel/connector and route only that hostname to 127.0.0.1:4184. Do not replace the existing connector configuration. Store its credential in a private file and use a dedicated supervisor/log path; do not put credentials in process arguments, repository files or chat. No paid resource may be provisioned without separate approval.

Set the private `PUBLIC_ORIGIN` to the verified new HTTPS origin, retain a unique auth secret/database, and restart ONLY RewardPoint. Exact-origin mutation checks and host-only Secure/HttpOnly/SameSite cookies then apply. Rate limits conservatively share an origin IP bucket behind a tunnel; do not blindly trust forwarded headers. Validate trusted proxy behavior before increasing traffic limits.

Public release acceptance requires HTTPS, matching clean build commit, health/readiness, assets and notices, refresh on deep links, real dealer login, No Contact acceptance, lead persistence, verified sale/credits, partial redemption/reconciliation, private-customer isolation, logout/recovery, capture-only settings, and before/after checks of the unchanged original portal. Until these run against the new hostname, status remains NOT DEPLOYED.

A laptop-hosted demo stops when the computer sleeps, shuts down or loses internet, or when unsupervised processes exit. No high-availability or monitoring claim is made. A host-specific unattended supervisor and public restart checks remain part of the blocked deployment stage.

## Scope limits

This is a bounded synthetic single-host demo. Broad production pagination/load testing, multi-region failover, live messaging, legal/commercial wording, customer data retention and real-money controls are not approved. Earned credit does not automatically expire under the D07 demo assumption. Uncertain or old holds must be reviewed by an administrator; time alone never releases credit. Daily exception review is a human demo operation, not an external invoice integration.

Chromium is verified. Safari/Firefox and real email delivery have not been verified. Proprietary logo/showroom redistribution is still awaiting permission; current assets contain no copied proprietary binaries.
