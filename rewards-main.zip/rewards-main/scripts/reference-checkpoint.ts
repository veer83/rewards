import { execFileSync } from "node:child_process";
import {
  readFileSync,
  readdirSync,
  writeFileSync,
  mkdirSync,
  existsSync,
} from "node:fs";
import { resolve, relative } from "node:path";
import { createHash } from "node:crypto";

const root = process.argv[2];
if (!root) throw new Error("Provide the read-only reference checkout path");
const sha = (v: string | Buffer) =>
  createHash("sha256").update(v).digest("hex");
const git = (args: string[]) =>
  execFileSync("git", ["-C", root, ...args], { maxBuffer: 64 * 1024 * 1024 });
const files: Record<string, string> = {};
function visit(dir: string) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const p = resolve(dir, entry.name);
    if (entry.isDirectory()) visit(p);
    else if (entry.isFile()) files[relative(root, p)] = sha(readFileSync(p));
  }
}
visit(resolve(root, "src"));
for (const file of [
  "package.json",
  "package-lock.json",
  "vite.config.ts",
  "index.html",
])
  if (existsSync(resolve(root, file)))
    files[file] = sha(readFileSync(resolve(root, file)));
const snapshot = {
  head: git(["rev-parse", "HEAD"]).toString().trim(),
  status_sha: sha(git(["status", "--porcelain=v1", "-z"])),
  staged_sha: sha(git(["diff", "--cached", "--binary"])),
  unstaged_sha: sha(git(["diff", "--binary"])),
  source_files: files,
};
mkdirSync(".local", { recursive: true, mode: 0o700 });
const dest = ".local/portal-reference-baseline.json";
if (!existsSync(dest)) {
  writeFileSync(dest, JSON.stringify(snapshot, null, 2), { mode: 0o600 });
  console.log(
    `Recorded reference metadata and ${Object.keys(files).length} source hashes; no source files or secrets copied.`,
  );
} else {
  const previous = JSON.parse(readFileSync(dest, "utf8"));
  if (JSON.stringify(previous) !== JSON.stringify(snapshot))
    throw new Error(
      "Reference changed since checkpoint; investigate without reverting user work",
    );
  console.log(
    `Reference source, Git index and working diff unchanged (${Object.keys(files).length} files).`,
  );
}
