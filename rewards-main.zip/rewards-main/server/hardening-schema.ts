export const hardeningMigration = {
  version: 3,
  sql: `
CREATE TABLE receipts (token_hash TEXT PRIMARY KEY, created_at TEXT NOT NULL);
ALTER TABLE outbox ADD COLUMN captured_body TEXT;
ALTER TABLE outbox ADD COLUMN captured_at TEXT;
CREATE INDEX customers_tenant ON customers(tenant_id);
CREATE INDEX leads_tenant_assignee ON leads(tenant_id,assigned_to);
CREATE INDEX ledger_grant ON ledger(grant_id);
CREATE INDEX consents_customer_purpose ON consents(customer_id,purpose);
CREATE INDEX outbox_tenant_status ON outbox(tenant_id,status);
`,
};
