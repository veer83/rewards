import { useEffect, useState, useRef, type FormEvent } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import {
  FiGrid,
  FiUsers,
  FiShare2,
  FiInbox,
  FiFlag,
  FiGift,
  FiBarChart2,
  FiSettings,
  FiLogOut,
  FiArrowUpRight,
  FiPlus,
  FiArrowRight,
  FiShield,
  FiMenu,
  FiCheckCircle,
} from "react-icons/fi";
import { api, ApiError, money, date } from "./api";
import {
  ActionForm,
  Badge,
  Brand,
  Empty,
  Modal,
  Notice,
  Table,
  Theme,
  type Field,
} from "./ui";
import type {
  Campaign,
  Customer,
  Lead,
  LeadDetail,
  Me,
  Offer,
  Referral,
  Settings,
  Reconciliation,
} from "./shared";
import { FinancialWorkspace } from "./FinancialWorkspace";
import { CustomerDetail } from "./CustomerDetail";

type Dialog = {
  title: string;
  path: string;
  fields: Field[];
  extra?: Record<string, unknown>;
  submit?: string;
};
const nav = [
  ["/", "Overview", FiGrid],
  ["/customers", "Customers", FiUsers],
  ["/referrals", "Referrals", FiShare2],
  ["/leads", "Lead Bank", FiInbox],
  ["/campaigns", "Campaigns", FiFlag],
  ["/rewards", "Rewards & Credits", FiGift],
  ["/reports", "Reports", FiBarChart2],
  ["/settings", "Settings", FiSettings],
] as const;

export function App() {
  const location = useLocation();
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const epoch = useRef(0);
  const channel = useRef<BroadcastChannel | null>(null);
  async function refreshIdentity() {
    const current = ++epoch.current;
    setMe(null);
    setLoading(true);
    setError("");
    try {
      const user = await api<Me>("/me");
      if (current === epoch.current) setMe(user);
    } catch (e) {
      if (
        current === epoch.current &&
        (!(e instanceof ApiError) || e.status !== 401)
      )
        setError(e instanceof Error ? e.message : "Sign-in unavailable");
    } finally {
      if (current === epoch.current) setLoading(false);
    }
  }
  useEffect(() => {
    void refreshIdentity();
    channel.current = new BroadcastChannel("rewardpoint-session");
    channel.current.onmessage = (event) => {
      if (event.data === "cleared") {
        epoch.current++;
        setMe(null);
        setLoading(false);
        setError("");
      }
      if (event.data === "changed") void refreshIdentity();
    };
    const expired = () => {
      epoch.current++;
      setMe(null);
      setLoading(false);
      setError("Your session ended. Sign in again.");
    };
    window.addEventListener("rewardpoint-session-expired", expired);
    return () => {
      epoch.current++;
      channel.current?.close();
      window.removeEventListener("rewardpoint-session-expired", expired);
    };
  }, []);
  if (location.pathname.startsWith("/r/"))
    return <PublicOffer publicToken={location.pathname.split("/")[2]} />;
  if (location.pathname.startsWith("/offer/confirmation/"))
    return <Receipt receipt={location.pathname.split("/")[3]} />;
  if (loading)
    return (
      <PublicShell>
        <Notice>Checking your secure session...</Notice>
      </PublicShell>
    );
  if (!me)
    return (
      <Login
        error={error}
        onLogin={async () => {
          await refreshIdentity();
          channel.current?.postMessage("changed");
        }}
      />
    );
  return (
    <Workspace
      key={`${me.user_id}:${me.tenant_id}`}
      me={me}
      onLogout={async () => {
        epoch.current++;
        setMe(null);
        setError("");
        channel.current?.postMessage("cleared");
        try {
          await api("/api/auth/sign-out", {});
        } catch {
          setError(
            "Local workspace cleared. Server logout could not be confirmed; retry sign-out before sharing this device.",
          );
        }
      }}
    />
  );
}
function PublicShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="public-page">
      <header>
        <Brand />
        <Theme />
      </header>
      {children}
      <footer>
        DriveOnyx RewardPoint <span>Synthetic demo · D01–D12 unapproved</span>
      </footer>
    </div>
  );
}
function Receipt({ receipt }: { receipt: string }) {
  const [state, setState] = useState("loading");
  useEffect(() => {
    const c = new AbortController();
    api(`/public/receipts/${receipt}`, undefined, undefined, c.signal)
      .then(() => setState("received"))
      .catch((e) => {
        if (!c.signal.aborted) setState(e.message);
      });
    return () => c.abort();
  }, [receipt]);
  return (
    <PublicShell>
      {state === "received" ? (
        <div className="receipt">
          <FiCheckCircle />
          <p className="eyebrow">REQUEST RECEIVED</p>
          <h1>You’re on the list.</h1>
          <p>
            Your request has been recorded for dealership review. Accepting
            creates a lead, not earned credit. You have no obligation to
            purchase.
          </p>
          <Notice>
            This is a synthetic demo. No monetary value or real messages.
          </Notice>
          <Link to="/login">Dealer sign-in</Link>
        </div>
      ) : (
        <Notice error={state !== "loading"}>
          {state === "loading" ? "Checking your receipt..." : state}
        </Notice>
      )}
    </PublicShell>
  );
}
function Login({
  onLogin,
  error,
}: {
  onLogin: () => Promise<void>;
  error: string;
}) {
  const [recovery, setRecovery] = useState(false);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState("");
  const params = new URLSearchParams(useLocation().search);
  const resetToken = params.get("token");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    setBusy(true);
    setFailure("");
    try {
      if (resetToken) {
        await api("/api/auth/reset-password", {
          token: resetToken,
          newPassword: data.get("password"),
        });
        history.replaceState(null, "", "/login");
        setSent(true);
      } else if (recovery) {
        await api("/api/auth/request-password-reset", {
          email: data.get("email"),
          redirectTo: "/login",
        });
        setSent(true);
      } else {
        await api("/api/auth/sign-in/email", {
          email: data.get("email"),
          password: data.get("password"),
        });
        await onLogin();
      }
    } catch (e) {
      setFailure(e instanceof Error ? e.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="login">
      <section className="login-story">
        <Brand />
        <div>
          <p className="eyebrow">CONNECTIONS THAT GO FURTHER</p>
          <h1>
            A good drive.
            <br />
            An even better
            <br />
            recommendation.
          </h1>
          <p>
            Turn customer confidence into meaningful connections, and give them
            a reason to return.
          </p>
        </div>
        <div className="login-highlights">
          <article>
            <FiShare2 />
            <strong>Make connections</strong>
            <span>A personal referral, a new beginning.</span>
          </article>
          <article>
            <FiGift />
            <strong>Reward loyalty</strong>
            <span>Service credit, earned with care.</span>
          </article>
          <article>
            <FiShield />
            <strong>Stay in control</strong>
            <span>Clear consent. Every action recorded.</span>
          </article>
        </div>
      </section>
      <section className="login-panel">
        <div className="login-theme">
          <Theme />
        </div>
        <div className="login-card">
          <p className="eyebrow">DEALER & CUSTOMER WORKSPACE</p>
          <h2>
            {resetToken
              ? "Choose a new password"
              : recovery
                ? "Recover your access"
                : "Sign in to your workspace"}
          </h2>
          <p>Welcome to DriveOnyx RewardPoint.</p>
          <div className="login-context">
            <FiShield />
            <div>
              <strong>Independent, secure access</strong>
              <small>Synthetic demonstration environment</small>
            </div>
          </div>
          {sent ? (
            <Notice>
              {resetToken
                ? "Password updated. Return to sign-in."
                : "If that account exists, recovery was captured for the local operator. Nothing was emailed."}
              <a href="/login">Return to sign-in</a>
            </Notice>
          ) : (
            <form className="form-stack" onSubmit={submit}>
              {!resetToken && (
                <label className="field">
                  <span>Email address</span>
                  <input
                    type="email"
                    name="email"
                    required
                    autoComplete="username"
                  />
                </label>
              )}
              {(!recovery || resetToken) && (
                <label className="field">
                  <span>{resetToken ? "New password" : "Password"}</span>
                  <input
                    type="password"
                    name="password"
                    required
                    minLength={resetToken ? 14 : 1}
                    autoComplete={
                      resetToken ? "new-password" : "current-password"
                    }
                  />
                </label>
              )}
              {(failure || error) && <Notice error>{failure || error}</Notice>}
              <button className="primary" disabled={busy}>
                {busy
                  ? "Please wait..."
                  : resetToken
                    ? "Set password"
                    : recovery
                      ? "Request recovery"
                      : "Sign In"}
                <FiArrowRight />
              </button>
              {!resetToken && (
                <button
                  type="button"
                  className="text-button"
                  onClick={() => {
                    setRecovery(!recovery);
                    setFailure("");
                  }}
                >
                  {recovery ? "Back to sign-in" : "Forgot password?"}
                </button>
              )}
            </form>
          )}
          <p className="small muted">
            Demo access is provisioned by the operator. No public registration,
            real customer sends, or monetary value.
          </p>
        </div>
        <p className="login-footer">
          Trusted connections. Thoughtfully rewarded.
        </p>
      </section>
    </div>
  );
}
function PublicOffer({ publicToken }: { publicToken: string }) {
  const [offer, setOffer] = useState<Offer | null>(null),
    [error, setError] = useState(""),
    [contact, setContact] = useState("");
  const [revision, setRevision] = useState(0);
  const navigate = useNavigate();
  useEffect(() => {
    const abort = new AbortController();
    setOffer(null);
    setError("");
    api<Offer>(
      `/public/referrals/${publicToken}`,
      undefined,
      undefined,
      abort.signal,
    )
      .then((value) => {
        if (!abort.signal.aborted) setOffer(value);
      })
      .catch((e) => {
        if (!abort.signal.aborted) setError(e.message);
      });
    return () => abort.abort();
  }, [publicToken, revision]);
  return (
    <PublicShell>
      {error ? (
        <Notice error>
          {error}
          <button onClick={() => setRevision((n) => n + 1)}>Retry</button>
        </Notice>
      ) : !offer ? (
        <Notice>Loading your offer...</Notice>
      ) : (
        <main className="offer-grid">
          <section className="offer-story">
            <Badge tone="purple">A PERSONAL INTRODUCTION</Badge>
            <h1>
              Your next chapter
              <br />
              starts with a referral.
            </h1>
            <p>{offer.dealer}</p>
            <p>
              Accept this invitation with no obligation to purchase. Your
              contact choices are always yours.
            </p>
            <div className="offer-benefits">
              <article>
                <span>YOUR VEHICLE DISCOUNT</span>
                <strong>{money(offer.discount_amount)}</strong>
                <small>Recorded separately at the qualifying sale</small>
              </article>
              <article>
                <span>YOUR SERVICE CREDIT</span>
                <strong>{money(offer.recipient_amount)}</strong>
                <small>Earned after a delivered, verified sale</small>
              </article>
            </div>
            <p>
              Your referrer can earn {money(offer.referrer_amount)} in service
              credit.
            </p>
            <details>
              <summary>Offer terms · version {offer.version}</summary>
              <p>{offer.terms}</p>
              <p>
                Accept by {date(offer.ends_at)}. Purchase by{" "}
                {date(offer.purchase_by)}.
              </p>
            </details>
            <Notice>
              DEMO ONLY · D01–D12 are unapproved assumptions. No real credit,
              purchase, or messages.
            </Notice>
          </section>
          <section className="panel offer-form">
            <p className="eyebrow">NO OBLIGATION TO PURCHASE</p>
            <h2>Keep the offer. Choose the contact.</h2>
            <p>Use fictional information and an email ending in .invalid.</p>
            <div
              onChange={(e) => {
                const t = e.target as HTMLInputElement;
                if (t.name === "contact") setContact(t.value);
              }}
            >
              <ActionForm
                path={`/public/referrals/${publicToken}/acceptances`}
                submit="Accept demo offer"
                extra={{
                  version_id: offer.version_id,
                  ...(contact === "none" ? { marketing: false } : {}),
                }}
                fields={[
                  { name: "name", label: "Full name" },
                  {
                    name: "email",
                    label: "Email address",
                    type: "email",
                    hint: "Example: pat@example.invalid",
                  },
                  {
                    name: "interest",
                    label: "Vehicle interest (optional)",
                    required: false,
                  },
                  {
                    name: "contact",
                    label: "Contact about this offer",
                    options: [
                      { value: "email", label: "Email me about this offer" },
                      { value: "none", label: "Do not contact me" },
                    ],
                  },
                  ...(contact === "none"
                    ? []
                    : [
                        {
                          name: "marketing",
                          label:
                            "I would like future email marketing (optional)",
                          type: "checkbox",
                        },
                      ]),
                  {
                    name: "terms_accepted",
                    label: "I accept the displayed demo terms",
                    type: "checkbox",
                    required: true,
                  },
                  {
                    name: "privacy_acknowledged",
                    label:
                      "I understand this synthetic information will be stored for dealership review",
                    type: "checkbox",
                    required: true,
                  },
                ]}
                onDone={(r) =>
                  navigate(`/offer/confirmation/${r.receipt_token}`)
                }
              />
            </div>
          </section>
        </main>
      )}
    </PublicShell>
  );
}

function Workspace({
  me,
  onLogout,
}: {
  me: Me;
  onLogout: () => Promise<void>;
}) {
  const location = useLocation();
  const navigate = useNavigate();
  const [revision, setRevision] = useState(0);
  const [customers, setCustomers] = useState<Customer[]>([]),
    [campaigns, setCampaigns] = useState<Campaign[]>([]),
    [referrals, setReferrals] = useState<Referral[]>([]),
    [leads, setLeads] = useState<Lead[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null),
    [loading, setLoading] = useState(true),
    [ready, setReady] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [query, setQuery] = useState(""),
    [menu, setMenu] = useState(false);
  const [dialog, setDialog] = useState<Dialog | null>(null),
    [detail, setDetail] = useState<LeadDetail | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
    null,
  );
  const [summary, setSummary] = useState<Reconciliation | null>(null);
  const [stageFilter, setStageFilter] = useState("all"),
    [contactFilter, setContactFilter] = useState("all"),
    [assignmentFilter, setAssignmentFilter] = useState("all");
  const current = location.pathname === "/login" ? "/" : location.pathname;
  const admin = me.role === "admin";
  const isCustomer = me.role === "customer";
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    Promise.all([
      api<Customer[]>("/customers", undefined, undefined, controller.signal),
      api<Referral[]>("/referrals", undefined, undefined, controller.signal),
      isCustomer
        ? Promise.resolve([])
        : api<Campaign[]>(
            "/campaigns",
            undefined,
            undefined,
            controller.signal,
          ),
      isCustomer
        ? Promise.resolve([])
        : api<Lead[]>("/leads", undefined, undefined, controller.signal),
      admin
        ? api<Settings>("/settings", undefined, undefined, controller.signal)
        : Promise.resolve(null),
      admin
        ? api<Reconciliation>(
            "/reports/reconciliation",
            undefined,
            undefined,
            controller.signal,
          )
        : Promise.resolve(null),
    ])
      .then(([c, r, p, l, s, totals]) => {
        if (!controller.signal.aborted) {
          setCustomers(c);
          setReferrals(r);
          setCampaigns(p);
          setLeads(l);
          setSettings(s);
          setSummary(totals);
          setReady(true);
        }
      })
      .catch((e) => {
        if (!controller.signal.aborted) setError(e.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [revision, me.user_id, admin, isCustomer]);
  useEffect(() => {
    setQuery("");
    setMenu(false);
  }, [current]);
  const refresh = () => setRevision((n) => n + 1);
  const done = () => {
    setDialog(null);
    setNotice("Saved to RewardPoint.");
    refresh();
  };
  async function act(path: string, body: unknown = {}) {
    setError("");
    try {
      await api(path, body, crypto.randomUUID());
      setNotice("Saved to RewardPoint.");
      refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Action failed");
    }
  }
  async function copy(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setNotice("Public offer link copied. It cannot access private credits.");
    } catch {
      setNotice(`Copy this public offer address: ${value}`);
    }
  }
  const addCustomer = () =>
    setDialog({
      title: "Add a customer",
      path: "/customers",
      fields: [
        { name: "name", label: "Full name" },
        {
          name: "email",
          label: "Synthetic email",
          type: "email",
          hint: "Use an address ending in .invalid",
        },
        {
          name: "dealer_reference",
          label: "Dealer customer reference (optional)",
          required: false,
        },
      ],
    });
  const enrollment = (cid?: string) =>
    setDialog({
      title: "Enroll an eligible referrer",
      path: "/enrolments",
      submit: "Enroll customer",
      fields: [
        {
          name: "customer_id",
          label: "Customer",
          value: cid,
          options: customers.map((c) => ({ value: c.id, label: c.name })),
        },
        {
          name: "version_id",
          label: "Published demo campaign",
          options: campaigns
            .filter(
              (c) =>
                c.published_at &&
                c.status === "active" &&
                !campaigns.some(
                  (other) =>
                    other.id === c.id &&
                    other.published_at &&
                    other.version > c.version,
                ),
            )
            .map((c) => ({
              value: c.version_id,
              label: `${c.name} · v${c.version}`,
            })),
        },
        {
          name: "eligibility",
          label: "Purchaser eligibility evidence",
          type: "textarea",
          hint: "Describe the verified synthetic purchase reference.",
        },
        {
          name: "invitation_consent",
          label: "I have recorded permission to invite this customer",
          type: "checkbox",
        },
      ],
    });
  const campaignForm = (c?: Campaign) =>
    setDialog({
      title: c ? "Create a new campaign version" : "Create a campaign",
      path: c ? `/campaigns/${c.id}/versions` : "/campaigns",
      fields: [
        { name: "name", label: "Campaign name", value: c?.name },
        {
          name: "referrer_amount",
          label: "Referrer service credit (CAD cents)",
          type: "number",
          value: c?.referrer_amount ?? 50000,
          min: 0,
          max: 10000000,
        },
        {
          name: "discount_amount",
          label: "Recipient vehicle discount (CAD cents)",
          type: "number",
          value: c?.discount_amount ?? 50000,
          min: 0,
          max: 10000000,
        },
        {
          name: "recipient_amount",
          label: "Recipient service credit (CAD cents)",
          type: "number",
          value: c?.recipient_amount ?? 50000,
          min: 0,
          max: 10000000,
        },
        {
          name: "terms",
          label: "Demo terms / qualification / usage",
          type: "textarea",
          value:
            c?.terms ||
            "Synthetic demo only. No real monetary value. D01-D12 unapproved. Credits require a delivered, verified sale; same-dealer service usage only.",
        },
        ...(["starts_at", "ends_at", "purchase_by"] as const).map(
          (name, i) => ({
            name,
            label: [
              "Acceptance starts",
              "Acceptance ends",
              "Purchase deadline",
            ][i],
            type: "datetime-local",
            value: new Date(
              Date.now() + (i === 0 ? -1 : i === 1 ? 90 : 180) * 86400000,
            )
              .toISOString()
              .slice(0, 16),
          }),
        ),
      ],
    });
  const filtered = <T,>(rows: T[]) =>
    rows.filter((r) =>
      JSON.stringify(r).toLowerCase().includes(query.toLowerCase()),
    );
  const visibleLeads = filtered(leads).filter(
    (l) =>
      (stageFilter === "all" || l.stage === stageFilter) &&
      (contactFilter === "all" ||
        Boolean(l.contact) === (contactFilter === "email")) &&
      (assignmentFilter === "all" ||
        (assignmentFilter === "mine"
          ? l.assigned_to === me.user_id
          : !l.assigned_to)),
  );
  const pageName = isCustomer
    ? "Your connections & credits"
    : nav.find((n) => n[0] === current)?.[1] || "Page not found";
  const navItems = isCustomer
    ? [["/", "Your workspace", FiGrid] as const]
    : nav.filter(
        (n) => admin || !["/settings", "/reports", "/rewards"].includes(n[0]),
      );
  return (
    <div className="shell">
      <aside className={`sidebar ${menu ? "open" : ""}`}>
        <Brand />
        <div className="workspace-label">
          {isCustomer ? "CUSTOMER WORKSPACE" : "DEALER WORKSPACE"}
        </div>
        <nav aria-label="Main navigation">
          {navItems.map(([path, label, Icon]) => (
            <NavLink key={path} to={path} end onClick={() => setMenu(false)}>
              <Icon />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="demo-note">
            <FiShield />
            <strong>Designed for trust</strong>
            <p>
              Consent first.
              <br />
              Every credit accounted for.
            </p>
          </div>
          <Badge tone="warning">SYNTHETIC DEMO</Badge>
          <small>No real monetary value</small>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <button
            className="icon-button mobile-menu"
            aria-label="Toggle navigation"
            onClick={() => setMenu(!menu)}
          >
            <FiMenu />
          </button>
          <div>
            <strong>{me.dealer.name}</strong>
            <small>RewardPoint / {pageName}</small>
          </div>
          <div className="topbar-right">
            <Theme />
            <div className="profile">
              <span>
                {me.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </span>
              <div>
                <strong>{me.name}</strong>
                <small>{me.role}</small>
              </div>
            </div>
            <button
              className="icon-button"
              aria-label="Sign out"
              onClick={onLogout}
            >
              <FiLogOut />
            </button>
          </div>
        </header>
        <main className="content">
          <div className="demo-strip">
            <span>DEMO ENVIRONMENT</span> Synthetic records. Captured
            notifications only. D01–D12 remain unapproved.
          </div>
          <div className="page-heading">
            <div>
              <p className="eyebrow">DRIVEONYX REWARDPOINT</p>
              <h1>{pageName}</h1>
              <p>
                {current === "/"
                  ? "Meaningful introductions. Measurable rewards."
                  : current === "/leads"
                    ? "Every introduction, with the right context."
                    : current === "/rewards"
                      ? "Earned carefully. Used with confidence."
                      : "Your dealership, connected by trust."}
              </p>
            </div>
            {!isCustomer &&
              ["/", "/customers", "/referrals"].includes(current) && (
                <button
                  className="primary"
                  onClick={
                    current === "/customers" ? addCustomer : () => enrollment()
                  }
                  disabled={loading || !ready}
                >
                  <FiPlus />
                  {current === "/customers"
                    ? "Add customer"
                    : "Enroll customer"}
                </button>
              )}
            {admin && current === "/campaigns" && (
              <button className="primary" onClick={() => campaignForm()}>
                <FiPlus />
                Create campaign
              </button>
            )}
          </div>
          {notice && (
            <Notice>
              {notice}
              <button className="text-button" onClick={() => setNotice("")}>
                Dismiss
              </button>
            </Notice>
          )}
          {error && (
            <Notice error>
              {error}
              <button onClick={refresh}>Retry</button>
            </Notice>
          )}
          {loading && ready && <Notice>Refreshing saved records...</Notice>}
          {!ready ? (
            <Notice>Loading your dealership workspace...</Notice>
          ) : (
            <>
              {current === "/" && !isCustomer && (
                <>
                  <section className="kpis">
                    {[
                      [
                        "Accepted referrals",
                        leads.length,
                        "Unique accepted leads",
                      ],
                      [
                        "Recorded sales",
                        leads.filter((l) => l.stage === "Sold").length,
                        "Submitted evidence, not approval",
                      ],
                      [
                        "Enrolled referrers",
                        referrals.length,
                        "Unique campaign enrollments",
                      ],
                      [
                        "No Contact",
                        leads.filter((l) => !l.contact).length,
                        "Preferences respected",
                      ],
                    ].map(([label, value, sub]) => (
                      <article key={label}>
                        <span>{label}</span>
                        <strong>{value}</strong>
                        <small>{sub}</small>
                      </article>
                    ))}
                  </section>
                  {admin && summary && (
                    <section className="kpis" aria-label="Credit overview">
                      {[
                        ["Pending verification", summary.pending],
                        ["Available service credit", summary.available],
                        ["Reserved service credit", summary.held],
                        ["Used service credit", summary.used],
                      ].map(([label, value]) => (
                        <article key={label}>
                          <span>{label}</span>
                          <strong>{money(Number(value))}</strong>
                          <Link to="/rewards">Review credits & approvals</Link>
                        </article>
                      ))}
                    </section>
                  )}
                  <div className="overview-grid">
                    <section className="panel">
                      <div className="section-heading">
                        <div>
                          <h2>Recent introductions</h2>
                          <p>A relationship starts here.</p>
                        </div>
                        <Link to="/leads">
                          View Lead Bank <FiArrowUpRight />
                        </Link>
                      </div>
                      {leads.length ? (
                        <Table
                          label="Recent leads"
                          headers={["Customer", "Contact preference", "Stage"]}
                        >
                          {leads.slice(0, 5).map((l) => (
                            <tr key={l.id}>
                              <td>
                                <strong>{l.name}</strong>
                                <small>{l.campaign}</small>
                              </td>
                              <td>
                                <Badge tone={l.contact ? "success" : "warning"}>
                                  {l.contact ? "Offer email" : "No Contact"}
                                </Badge>
                              </td>
                              <td>
                                <Badge>{l.stage}</Badge>
                              </td>
                            </tr>
                          ))}
                        </Table>
                      ) : (
                        <Empty>
                          <FiShare2 />
                          <h3>
                            Your first introduction starts with a customer.
                          </h3>
                          <p>
                            Enroll an eligible purchaser and share their public
                            offer link.
                          </p>
                          <button onClick={() => enrollment()}>
                            Enroll a customer
                          </button>
                        </Empty>
                      )}
                    </section>
                    <section className="panel journey-card">
                      <p className="eyebrow">THE REWARDPOINT JOURNEY</p>
                      <h2>
                        Connections,
                        <br />
                        with follow-through.
                      </h2>
                      {[
                        "Enroll an eligible customer",
                        "Accept an offer with consent",
                        "Verify the delivered sale",
                        "Issue and track service credit",
                      ].map((t, i) => (
                        <div key={t}>
                          <span>{String(i + 1).padStart(2, "0")}</span>
                          <p>{t}</p>
                        </div>
                      ))}
                      <Link to="/campaigns">
                        View demo campaigns <FiArrowRight />
                      </Link>
                    </section>
                  </div>
                </>
              )}
              {current === "/customers" && !isCustomer && (
                <section className="panel">
                  <ListHeader
                    query={query}
                    setQuery={setQuery}
                    title="Customers"
                    count={customers.length}
                  />
                  <Table
                    label="Customers"
                    headers={[
                      "Customer",
                      "Dealer reference",
                      "Identity",
                      "Actions",
                    ]}
                  >
                    {filtered(customers).map((c) => (
                      <tr key={c.id}>
                        <td>
                          <strong>{c.name}</strong>
                          <small>{c.email}</small>
                        </td>
                        <td>{c.dealer_reference || "Not recorded"}</td>
                        <td>
                          <Badge tone={c.verified ? "success" : "warning"}>
                            {c.verified ? "Verified" : "Unverified"}
                          </Badge>
                        </td>
                        <td>
                          <div className="row-actions">
                            <button onClick={() => setSelectedCustomer(c)}>
                              View customer
                            </button>
                            <button onClick={() => enrollment(c.id)}>
                              Enroll
                            </button>
                            {admin && !c.verified && (
                              <button
                                onClick={() =>
                                  setDialog({
                                    title: `Verify identity · ${c.name}`,
                                    path: `/customers/${c.id}/verify`,
                                    fields: [
                                      {
                                        name: "reason",
                                        label: "Independent identity evidence",
                                        type: "textarea",
                                      },
                                    ],
                                  })
                                }
                              >
                                Verify identity
                              </button>
                            )}
                            {admin && c.verified && !c.user_id && (
                              <button
                                onClick={() =>
                                  setDialog({
                                    title: `Provision private access · ${c.name}`,
                                    path: `/customers/${c.id}/access`,
                                    submit: "Provision access",
                                    fields: [
                                      {
                                        name: "reason",
                                        label:
                                          "Verified identity and access authorization",
                                        type: "textarea",
                                        hint: "Recovery instructions are captured privately for the operator. No email will be sent.",
                                      },
                                    ],
                                  })
                                }
                              >
                                Private access
                              </button>
                            )}
                            <button
                              onClick={() =>
                                setDialog({
                                  title: `Record withdrawal · ${c.name}`,
                                  path: `/customers/${c.id}/consents`,
                                  extra: { granted: false },
                                  fields: [
                                    {
                                      name: "purpose",
                                      label: "Contact purpose",
                                      options: [
                                        {
                                          value: "offer",
                                          label: "Offer follow-up",
                                        },
                                        {
                                          value: "marketing",
                                          label: "Marketing",
                                        },
                                        {
                                          value: "invitation",
                                          label: "Referral invitations",
                                        },
                                      ],
                                    },
                                    {
                                      name: "evidence",
                                      label: "Customer withdrawal evidence",
                                      type: "textarea",
                                    },
                                  ],
                                })
                              }
                            >
                              Record opt-out
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </Table>
                  {!filtered(customers).length && (
                    <Empty>
                      No matching customers. Add a synthetic customer to begin.
                    </Empty>
                  )}
                </section>
              )}
              {(current === "/referrals" || isCustomer) && (
                <section className="panel">
                  <ListHeader
                    query={query}
                    setQuery={setQuery}
                    title={
                      isCustomer
                        ? "Your referral invitations"
                        : "Referral invitations"
                    }
                    count={referrals.length}
                  />
                  <Table
                    label="Referral invitations"
                    headers={[
                      "Referrer / campaign",
                      "Accepted",
                      "Link status",
                      "Share offer",
                    ]}
                  >
                    {filtered(referrals).map((r) => (
                      <tr key={r.id}>
                        <td>
                          <strong>{r.name}</strong>
                          <small>{r.campaign}</small>
                        </td>
                        <td>{r.accepted}</td>
                        <td>
                          <Badge>{r.revoked ? "Revoked" : "Active"}</Badge>
                        </td>
                        <td>
                          <div className="row-actions">
                            {!r.revoked && (
                              <>
                                <button onClick={() => copy(r.share_url)}>
                                  Copy link
                                </button>
                                <a
                                  className="button"
                                  href={r.share_url}
                                  target="_blank"
                                  rel="noreferrer"
                                >
                                  View offer
                                </a>
                              </>
                            )}
                            <button
                              onClick={() => act(`/enrolments/${r.id}/rotate`)}
                            >
                              Rotate
                            </button>
                            {!r.revoked && (
                              <button
                                onClick={() =>
                                  act(`/enrolments/${r.id}/revoke`)
                                }
                              >
                                Revoke
                              </button>
                            )}
                            {!isCustomer && (
                              <button
                                onClick={() =>
                                  act(`/enrolments/${r.id}/invite`)
                                }
                              >
                                Capture invitation
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </Table>
                  {!referrals.length && (
                    <Empty>
                      No referral invitations yet. Your dealership can enroll
                      you in an eligible campaign.
                    </Empty>
                  )}
                </section>
              )}
              {isCustomer && customers[0] && (
                <button onClick={() => setSelectedCustomer(customers[0])}>
                  Your profile & contact preferences
                </button>
              )}
              {current === "/campaigns" && !isCustomer && (
                <div className="campaign-grid">
                  {campaigns.map((c) => (
                    <section className="panel campaign-card" key={c.version_id}>
                      <div className="section-heading">
                        <Badge
                          tone={c.status === "active" ? "success" : "neutral"}
                        >
                          {c.published_at ? c.status : "draft"} · v{c.version}
                        </Badge>
                        <FiFlag />
                      </div>
                      <h2>{c.name}</h2>
                      <p className="small">Accept by {date(c.ends_at)}</p>
                      <div className="benefit-list">
                        <div>
                          <span>Referrer service credit</span>
                          <strong>{money(c.referrer_amount)}</strong>
                        </div>
                        <div>
                          <span>Recipient vehicle discount</span>
                          <strong>{money(c.discount_amount)}</strong>
                        </div>
                        <div>
                          <span>Recipient service credit</span>
                          <strong>{money(c.recipient_amount)}</strong>
                        </div>
                      </div>
                      <details>
                        <summary>Terms & qualification</summary>
                        <p>{c.terms}</p>
                        <p>Purchase deadline: {date(c.purchase_by)}</p>
                      </details>
                      <Badge tone="warning">D01–D12 · DEMO ASSUMPTIONS</Badge>
                      {admin &&
                        !campaigns.some(
                          (other) =>
                            other.id === c.id && other.version > c.version,
                        ) && (
                          <div className="row-actions">
                            <button
                              onClick={() =>
                                act(
                                  `/campaigns/${c.id}/${c.status === "active" && c.published_at ? "pause" : "publish"}`,
                                )
                              }
                            >
                              {c.status === "active" && c.published_at
                                ? "Pause"
                                : "Publish demo"}
                            </button>
                            <button onClick={() => campaignForm(c)}>
                              New version
                            </button>
                          </div>
                        )}
                    </section>
                  ))}
                </div>
              )}
              {current === "/leads" && !isCustomer && (
                <section className="panel">
                  <ListHeader
                    query={query}
                    setQuery={setQuery}
                    title="Lead Bank"
                    count={leads.length}
                  />
                  <div className="lead-filters padded">
                    <label>
                      Stage
                      <select
                        aria-label="Filter lead stage"
                        value={stageFilter}
                        onChange={(e) => setStageFilter(e.target.value)}
                      >
                        <option value="all">All stages</option>
                        {[...new Set(leads.map((l) => l.stage))].map(
                          (stage) => (
                            <option key={stage}>{stage}</option>
                          ),
                        )}
                      </select>
                    </label>
                    <label>
                      Contact
                      <select
                        aria-label="Filter contact preference"
                        value={contactFilter}
                        onChange={(e) => setContactFilter(e.target.value)}
                      >
                        <option value="all">All preferences</option>
                        <option value="email">Offer email</option>
                        <option value="none">No Contact</option>
                      </select>
                    </label>
                    <label>
                      Assignment
                      <select
                        aria-label="Filter assignment"
                        value={assignmentFilter}
                        onChange={(e) => setAssignmentFilter(e.target.value)}
                      >
                        <option value="all">All assignments</option>
                        <option value="mine">Assigned to me</option>
                        <option value="unassigned">Unassigned</option>
                      </select>
                    </label>
                    <span>{visibleLeads.length} matching leads</span>
                  </div>
                  <Table
                    label="Lead Bank"
                    headers={[
                      "Recipient",
                      "Referral source",
                      "Preferences",
                      "Stage",
                      "Actions",
                    ]}
                  >
                    {visibleLeads.map((l) => (
                      <tr key={l.id}>
                        <td>
                          <strong>{l.name}</strong>
                          <small>{l.email}</small>
                        </td>
                        <td>
                          {l.referrer}
                          <small>{l.campaign}</small>
                        </td>
                        <td>
                          <Badge tone={l.contact ? "success" : "warning"}>
                            {l.contact ? "Offer email" : "No Contact"}
                          </Badge>
                          <small>
                            Marketing: {l.marketing ? "opted in" : "off"}
                          </small>
                        </td>
                        <td>
                          <Badge>{l.stage}</Badge>
                          {l.review > 0 && <Badge tone="warning">Review</Badge>}
                        </td>
                        <td>
                          <div className="row-actions">
                            <button
                              onClick={async () => {
                                try {
                                  setDetail(await api(`/leads/${l.id}`));
                                } catch (e) {
                                  setError((e as Error).message);
                                }
                              }}
                            >
                              View
                            </button>
                            <button
                              onClick={() =>
                                setDialog({
                                  title: `Add activity · ${l.name}`,
                                  path: `/leads/${l.id}/activities`,
                                  fields: [
                                    {
                                      name: "kind",
                                      label: "Activity",
                                      options: [
                                        {
                                          value: "note",
                                          label: "Internal note",
                                        },
                                        {
                                          value: "stage",
                                          label: "Change stage",
                                        },
                                        ...(admin
                                          ? [
                                              {
                                                value: "identity",
                                                label:
                                                  "Verify identity / resolve match",
                                              },
                                            ]
                                          : []),
                                      ],
                                    },
                                    {
                                      name: "value",
                                      label: "Stage (for stage changes)",
                                      required: false,
                                      options: [
                                        "New",
                                        "Contacted",
                                        "Qualified",
                                        "Lost",
                                      ].map((v) => ({ value: v, label: v })),
                                    },
                                    {
                                      name: "note",
                                      label: "Evidence / note",
                                      type: "textarea",
                                    },
                                  ],
                                })
                              }
                            >
                              Add activity
                            </button>
                            {l.stage !== "Sold" && (
                              <button
                                onClick={() =>
                                  setDialog({
                                    title: `Record sale · ${l.name}`,
                                    path: `/leads/${l.id}/sales`,
                                    submit: "Submit for verification",
                                    fields: [
                                      {
                                        name: "reference",
                                        label: "Unique dealer sale reference",
                                      },
                                      {
                                        name: "delivered_at",
                                        label: "Delivered at",
                                        type: "datetime-local",
                                        value: new Date(
                                          Date.now() -
                                            new Date().getTimezoneOffset() *
                                              60000,
                                        )
                                          .toISOString()
                                          .slice(0, 23),
                                      },
                                      {
                                        name: "discount_amount",
                                        label:
                                          "Vehicle discount applied (CAD cents)",
                                        type: "number",
                                        value: 50000,
                                        min: 0,
                                        max: 10000000,
                                      },
                                      {
                                        name: "evidence",
                                        label:
                                          "Delivery and source-system evidence",
                                        type: "textarea",
                                        hint: "Submission does not issue credit. An administrator must verify the sale.",
                                      },
                                    ],
                                  })
                                }
                              >
                                Record sale
                              </button>
                            )}
                            {admin && (
                              <button
                                onClick={() =>
                                  setDialog({
                                    title: `Assign lead · ${l.name}`,
                                    path: `/leads/${l.id}/activities`,
                                    extra: { kind: "assign" },
                                    fields: [
                                      {
                                        name: "value",
                                        label: "Assigned staff",
                                        options: (settings?.users || [])
                                          .filter(
                                            (u) =>
                                              u.active && u.role !== "customer",
                                          )
                                          .map((u) => ({
                                            value: u.user_id,
                                            label: u.name,
                                          })),
                                      },
                                      {
                                        name: "note",
                                        label: "Assignment reason",
                                        type: "textarea",
                                      },
                                    ],
                                  })
                                }
                              >
                                Assign
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </Table>
                  {!visibleLeads.length && (
                    <Empty>
                      No matching leads. Accepted public offers appear here.
                    </Empty>
                  )}
                </section>
              )}
              {current === "/settings" && admin && settings && (
                <>
                  <div className="settings-grid">
                    <section className="panel padded">
                      <h2>Workspace safeguards</h2>
                      <p>{me.dealer.name}</p>
                      <p>{me.dealer.timezone} · CAD</p>
                      <Notice>
                        Notifications are captured, never delivered. Real
                        campaign activation is disabled on the server.
                      </Notice>
                      <button onClick={() => act("/notifications/dispatch")}>
                        Process captured notifications
                      </button>
                      <p className="small">
                        Recovery links are stored privately for the local
                        operator, never exposed in this workspace.
                      </p>
                    </section>
                    <section className="panel">
                      <div className="section-heading">
                        <h2>Authorized access</h2>
                        <button
                          onClick={() =>
                            setDialog({
                              title: "Provision synthetic staff access",
                              path: "/users",
                              submit: "Provision access",
                              fields: [
                                { name: "name", label: "Staff name" },
                                {
                                  name: "email",
                                  label: "Synthetic staff email",
                                  type: "email",
                                  hint: "Use .invalid; single-use recovery is captured for the local operator.",
                                },
                                {
                                  name: "role",
                                  label: "Role",
                                  options: [
                                    {
                                      value: "sales",
                                      label: "Sales representative",
                                    },
                                    {
                                      value: "admin",
                                      label: "Dealer administrator",
                                    },
                                  ],
                                },
                              ],
                            })
                          }
                        >
                          Add staff
                        </button>
                      </div>
                      <Table label="Users" headers={["Name", "Role", "Access"]}>
                        {settings.users.map((u) => (
                          <tr key={u.user_id}>
                            <td>{u.name}</td>
                            <td>{u.role}</td>
                            <td>
                              {u.user_id === me.user_id ||
                              u.role === "customer" ? (
                                <Badge>
                                  {u.active ? "Active" : "Disabled"}
                                </Badge>
                              ) : (
                                <button
                                  onClick={() =>
                                    act(`/users/${u.user_id}/access`, {
                                      active: !u.active,
                                      role: u.role,
                                    })
                                  }
                                >
                                  {u.active ? "Disable" : "Enable"}
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </Table>
                    </section>
                  </div>
                  <section className="panel">
                    <div className="section-heading">
                      <h2>Notification history</h2>
                      <Badge>Capture only</Badge>
                    </div>
                    <Table
                      label="Notifications"
                      headers={["Purpose", "Outcome", "Attempts", "Created"]}
                    >
                      {settings.outbox.map((o) => (
                        <tr key={o.id}>
                          <td>{o.purpose}</td>
                          <td>
                            <Badge>{o.status}</Badge>
                          </td>
                          <td>{o.attempts}</td>
                          <td>
                            {date(o.created_at)}
                            {o.captured_body && (
                              <details>
                                <summary>Captured preview</summary>
                                <p className="capture-preview">
                                  {o.captured_body}
                                </p>
                              </details>
                            )}
                          </td>
                        </tr>
                      ))}
                    </Table>
                  </section>
                  <section className="panel">
                    <div className="section-heading">
                      <h2>Audit history</h2>
                      <span>Latest 200 events</span>
                    </div>
                    <Table
                      label="Audit history"
                      headers={["Action", "Reason", "Time"]}
                    >
                      {settings.audit.map((a) => (
                        <tr key={a.id}>
                          <td>{a.action}</td>
                          <td>{a.reason || "—"}</td>
                          <td>{date(a.created_at)}</td>
                        </tr>
                      ))}
                    </Table>
                  </section>
                </>
              )}
              {((admin && ["/rewards", "/reports"].includes(current)) ||
                isCustomer) && (
                <FinancialWorkspace
                  me={me}
                  reports={current === "/reports" && admin}
                  revision={revision}
                  onChange={refresh}
                />
              )}
              {!admin &&
                !isCustomer &&
                ["/rewards", "/reports", "/settings"].includes(current) && (
                  <Notice error>
                    Administrator access is required for this workspace.
                  </Notice>
                )}
              {!nav.some((n) => n[0] === current) &&
                current !== "/customer/referrals" && (
                  <Empty>
                    This page does not exist.{" "}
                    <button onClick={() => navigate("/")}>Open Overview</button>
                  </Empty>
                )}
            </>
          )}
          <footer className="workspace-footer">
            <span>DriveOnyx RewardPoint</span>
            <span>{me.release} · Capture mode</span>
          </footer>
        </main>
      </div>
      {dialog && (
        <Modal title={dialog.title} onClose={() => setDialog(null)}>
          <ActionForm {...dialog} onDone={done} />
        </Modal>
      )}
      {selectedCustomer && (
        <Modal
          title={selectedCustomer.name}
          onClose={() => setSelectedCustomer(null)}
          wide
        >
          <CustomerDetail customer={selectedCustomer} me={me} />
        </Modal>
      )}
      {detail && (
        <Modal
          title={detail.customer.name}
          onClose={() => setDetail(null)}
          wide
        >
          <div className="padded">
            <h3>Accepted offer</h3>
            <p>{detail.offer.terms}</p>
            <h3>Consent history</h3>
            {detail.consents.map((c) => (
              <p key={c.id}>
                <Badge tone={c.granted ? "success" : "warning"}>
                  {c.purpose}: {c.granted ? "granted" : "not granted"}
                </Badge>{" "}
                <small>{date(c.created_at)}</small>
              </p>
            ))}
            <h3>Activity</h3>
            {detail.activities.length ? (
              detail.activities.map((a) => (
                <article key={a.id}>
                  <strong>{a.kind}</strong>
                  <p>{a.note}</p>
                  <small>{date(a.created_at)}</small>
                </article>
              ))
            ) : (
              <Empty>No staff activity recorded.</Empty>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}
function ListHeader({
  query,
  setQuery,
  title,
  count,
}: {
  query: string;
  setQuery: (v: string) => void;
  title: string;
  count: number;
}) {
  return (
    <div className="section-heading">
      <div className="heading-count">
        <h2>{title}</h2>
        <Badge>{count}</Badge>
      </div>
      <label className="search">
        <span className="sr-only">Search {title}</span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={`Search ${title.toLowerCase()}...`}
        />
      </label>
    </div>
  );
}
