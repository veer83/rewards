# DriveOnyx RewardPoint

Independent referral, lead and service-credit application. React/TypeScript frontend, Express API, Better Auth sessions, and a durable SQLite WAL database. The built frontend is served by Express on a dedicated loopback port. No Service Portal imports, API calls, database access or authentication dependency.

## Local synthetic demo

Use Node 24 LTS (Node 25 is also supported for this development checkout).

```sh
npm ci
npm run setup:demo
npm run db:migrate
npm run db:seed
npm run build
npm start
```

Open `http://127.0.0.1:4184`. Setup generates a private `.env` and `.local/demo-access.txt`; passwords are random and never printed. Setup refuses to overwrite an existing configuration, and seeding refuses a nonempty database. Stopping this server with Ctrl+C affects RewardPoint only.

The seeded accounts cover an administrator, restricted salesperson and customer at Northstar, plus an administrator at Lakeside, all fictional `.invalid` identities. Private customer access uses the same real authentication flow and server ownership checks. No credential is bundled into the frontend. Password recovery is captured to private local files for the operator; no email is sent.

## Verified workflow

Enroll a verified synthetic purchaser, share their opaque public offer link, accept using a synthetic `.invalid` address and explicit contact choices, inspect the resulting lead, verify beneficiary identities, record delivered-sale evidence, approve the two-beneficiary service-credit bundle, reserve partial credit against an external invoice, and confirm or reconcile external usage. Vehicle discount remains separate from service credit.

All monetary figures are integer CAD cents. Public acceptance creates no credit. Published terms and posted ledger entries are immutable. Immediate database transactions, event uniqueness and payload-bound idempotency protect issuance and redemption. Uncertain usage stays held. Used-credit source cancellations freeze remaining balances for explicit review, without creating customer debt.

## Checks

```sh
npm run lint
npm run build
npm test
PLAYWRIGHT_BROWSERS_PATH=.local/browsers npx playwright install chromium
PLAYWRIGHT_BROWSERS_PATH=.local/browsers npm run test:browser
```

Browser tests start their own isolated database and production-build server on 4187. No Service Portal process is stopped. Screenshots are written to ignored `output/screenshots/`; traces, databases and credentials are never committed. Run the build before tests that exercise compiled worker-thread concurrency paths.

## Boundaries

This is a synthetic demo, not a commercial launch. D01-D12 are explicitly unapproved assumptions. Server configuration rejects live campaigns, real addresses, real notification modes and a production environment. No payment processing or actual invoice-system integration exists; staff record and verify external references. Administrative accounts are not publicly advertised.

The requested custom-domain deployment is not yet verified. Asset redistribution confirmation is pending; proprietary logo/artwork is not currently copied. See `codex/PROGRESS.md` for actual stage results and outstanding work. Do not infer deployment from a successful build or Git push.

Backup/restore, immutable releases, rollback rehearsal and the separate-host deployment gate are documented in [Operations](docs/OPERATIONS.md). Theme and asset permission boundaries are recorded in [Provenance](docs/PROVENANCE.md). Public production notices are available at `/THIRD_PARTY_NOTICES.txt`.

Official authentication references: [Express integration](https://better-auth.com/docs/integrations/express), [SQLite adapter](https://better-auth.com/docs/adapters/sqlite), [schema migrations](https://better-auth.com/docs/concepts/database).
