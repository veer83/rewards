import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { hash, id, now, type Store } from "./db.js";
import { requireThat, type Actor, type Customer, type Lead } from "./model.js";
import type { Config } from "./config.js";

export function audit(
  db: Store,
  actor: Actor,
  action: string,
  object: string,
  reason = "",
) {
  db.run(
    "INSERT INTO audit VALUES (?,?,?,?,?,?,?)",
    id(),
    actor.tenant_id,
    actor.user_id,
    action,
    object,
    reason,
    now(),
  );
}
export function operation<T>(
  db: Store,
  scope: string,
  key: string | undefined,
  body: unknown,
  fn: () => T,
): T {
  requireThat(
    key && /^[a-zA-Z0-9_-]{8,100}$/.test(key),
    400,
    "A valid Idempotency-Key is required",
  );
  const fingerprint = hash(JSON.stringify(body));
  return db.transaction(() => {
    const existing = db.get<{ request_hash: string; result: string }>(
      "SELECT * FROM operations WHERE scope=? AND key=?",
      scope,
      key,
    );
    if (existing) {
      requireThat(
        existing.request_hash === fingerprint,
        409,
        "Idempotency key was used with a different request",
      );
      return JSON.parse(existing.result) as T;
    }
    const result = fn();
    db.run(
      "INSERT INTO operations VALUES (?,?,?,?,?)",
      scope,
      key,
      fingerprint,
      JSON.stringify(result),
      now(),
    );
    return result;
  });
}
export function customer(db: Store, actor: Actor, customerId: string) {
  const c = db.get<Customer>(
    "SELECT * FROM customers WHERE id=? AND tenant_id=?",
    customerId,
    actor.tenant_id,
  );
  requireThat(
    c &&
      (actor.role === "admin" ||
        (actor.role === "sales" && c.owner_id === actor.user_id) ||
        (actor.role === "customer" && c.id === actor.customer_id)),
    404,
    "Customer unavailable",
  );
  return c;
}
export function lead(db: Store, actor: Actor, leadId: string) {
  const l = db.get<Lead>(
    "SELECT * FROM leads WHERE id=? AND tenant_id=?",
    leadId,
    actor.tenant_id,
  );
  requireThat(
    l &&
      actor.role !== "customer" &&
      (actor.role === "admin" || l.assigned_to === actor.user_id),
    404,
    "Lead unavailable",
  );
  return l;
}
export function consent(
  db: Store,
  tenant: string,
  customerId: string,
  purpose: string,
): boolean {
  return (
    db.get<{ granted: number }>(
      "SELECT granted FROM consents WHERE tenant_id=? AND customer_id=? AND purpose=? ORDER BY rowid DESC LIMIT 1",
      tenant,
      customerId,
      purpose,
    )?.granted === 1
  );
}
export function appendConsent(
  db: Store,
  tenant: string,
  customerId: string,
  purpose: string,
  granted: boolean,
  source: string,
  version: string,
) {
  db.run(
    "INSERT INTO consents VALUES (?,?,?,?,?,?,?,?)",
    id(),
    tenant,
    customerId,
    purpose,
    Number(granted),
    version,
    source,
    now(),
  );
}
export function queue(
  db: Store,
  tenant: string,
  customerId: string,
  purpose: string,
  event: string,
) {
  db.run(
    "INSERT OR IGNORE INTO outbox(id,tenant_id,customer_id,purpose,event_key,status,created_at) VALUES (?,?,?,?,?,?,?)",
    id(),
    tenant,
    customerId,
    purpose,
    event,
    consent(db, tenant, customerId, purpose) ? "queued" : "suppressed",
    now(),
  );
}
export function dispatch(db: Store, tenant: string, cfg?: Config) {
  return db.transaction(() => {
    const rows = db.all<{
      id: string;
      customer_id: string;
      purpose: string;
      event_key: string;
    }>(
      "SELECT * FROM outbox WHERE tenant_id=? AND status IN ('queued','failed')",
      tenant,
    );
    for (const r of rows) {
      let allowed = consent(db, tenant, r.customer_id, r.purpose);
      let content =
        "CAPTURE ONLY - NOT DELIVERED. DriveOnyx RewardPoint synthetic demo. Your " +
        r.purpose +
        " update is available in your authenticated RewardPoint workspace. Credits require a delivered, verified sale; acceptance alone earns nothing. Contact preferences can be withdrawn in your private workspace or recorded by dealership staff. D01-D12 remain unapproved; no real monetary value.";
      if (
        r.purpose === "invitation" &&
        /^(enrollment|invite):/.test(r.event_key) &&
        cfg
      ) {
        const e = db.get<{
          token_cipher: string;
          referrer_amount: number;
          recipient_amount: number;
          discount_amount: number;
          ends_at: string;
          terms: string;
        }>(
          "SELECT e.token_cipher,v.referrer_amount,v.recipient_amount,v.discount_amount,v.ends_at,v.terms FROM enrolments e JOIN campaign_versions v ON v.id=e.version_id JOIN campaigns c ON c.id=v.campaign_id WHERE e.id=? AND e.tenant_id=? AND e.revoked=0 AND c.status='active' AND v.published_at IS NOT NULL AND v.ends_at>? AND v.id=(SELECT id FROM campaign_versions WHERE campaign_id=c.id AND published_at IS NOT NULL ORDER BY version DESC LIMIT 1)",
          r.event_key.split(":")[1],
          tenant,
          now(),
        );
        allowed = allowed && Boolean(e);
        if (e)
          content += `\nPublic offer to share: ${cfg.PUBLIC_ORIGIN}/r/${decrypt(e.token_cipher, cfg.AUTH_SECRET)}\nReferrer service credit: CAD ${(e.referrer_amount / 100).toFixed(2)}. Recipient vehicle discount: CAD ${(e.discount_amount / 100).toFixed(2)}. Recipient service credit: CAD ${(e.recipient_amount / 100).toFixed(2)}.\nAccept before ${e.ends_at}. ${e.terms}`;
      }
      db.run(
        "UPDATE outbox SET status=?, attempts=attempts+1,captured_body=?,captured_at=? WHERE id=?",
        allowed ? "captured" : "suppressed",
        allowed ? content : null,
        allowed ? now() : null,
        r.id,
      );
    }
    return { processed: rows.length, mode: "capture" };
  });
}
export function encrypt(token: string, secret: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv(
    "aes-256-gcm",
    Buffer.from(hash(secret), "hex"),
    iv,
  );
  return Buffer.concat([
    iv,
    cipher.update(token),
    cipher.final(),
    cipher.getAuthTag(),
  ]).toString("base64url");
}
export function decrypt(value: string, secret: string) {
  const b = Buffer.from(value, "base64url");
  const decipher = createDecipheriv(
    "aes-256-gcm",
    Buffer.from(hash(secret), "hex"),
    b.subarray(0, 12),
  );
  decipher.setAuthTag(b.subarray(-16));
  return Buffer.concat([
    decipher.update(b.subarray(12, -16)),
    decipher.final(),
  ]).toString();
}
export const token = () => randomBytes(32).toString("base64url");
