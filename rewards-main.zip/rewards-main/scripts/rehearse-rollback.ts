import { resolve } from "node:path";
import { readFileSync, mkdirSync, mkdtempSync, cpSync } from "node:fs";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createHash } from "node:crypto";
import assert from "node:assert/strict";
import { fixture } from "../tests/helpers.js";

const [beforeArg, afterArg] = process.argv.slice(2);
if (!beforeArg || !afterArg)
  throw new Error("Provide two existing isolated artifact directories");
mkdirSync("output", { recursive: true, mode: 0o700 });
const runtime = mkdtempSync(resolve("output/rollback-"));
const before = resolve(runtime, "A"),
  after = resolve(runtime, "B"),
  origin = "http://127.0.0.1:4191";
// Stage immutable artifacts into non-hidden runtime directories, as on a host release path.
cpSync(resolve(beforeArg), before, { recursive: true });
cpSync(resolve(afterArg), after, { recursive: true });
const digest = (path: string) =>
  createHash("sha256")
    .update(readFileSync(resolve(path, "dist/index.html")))
    .digest("hex");
assert.notEqual(
  digest(before),
  digest(after),
  "Rehearsal requires distinct frontend builds",
);
const f = await fixture();
f.db.close();
let child: ReturnType<typeof spawn> | undefined,
  cookie = "";
let customers: unknown;
async function stop() {
  if (child && child.exitCode === null) {
    const exited = once(child, "exit");
    child.kill("SIGTERM");
    await exited;
  }
}
try {
  for (const [index, path] of [before, after, before].entries()) {
    const release = `rollback-rehearsal-${index}`;
    child = spawn(
      process.execPath,
      [resolve(path, "dist-server/server/index.js")],
      {
        cwd: path,
        env: {
          ...process.env,
          ...f.cfg,
          PORT: "4191",
          PUBLIC_ORIGIN: origin,
          RELEASE_ID: release,
        },
        stdio: ["ignore", "pipe", "pipe"],
      },
    );
    let ready = false;
    for (let i = 0; i < 120; i++) {
      if (child.exitCode !== null)
        throw new Error("Isolated artifact failed to start");
      try {
        const h = await fetch(`${origin}/api/health`);
        if (h.ok && (await h.json()).release === release) {
          ready = true;
          break;
        }
      } catch {
        /* Wait for this isolated origin only. */
      }
      await new Promise((r) => setTimeout(r, 50));
    }
    assert(ready, "Isolated origin readiness timeout");
    if (!cookie) {
      const login = await fetch(`${origin}/api/auth/sign-in/email`, {
        method: "POST",
        headers: { origin, "content-type": "application/json" },
        body: JSON.stringify({
          email: "admin@northstar.invalid",
          password: f.password,
        }),
      });
      assert.equal(login.status, 200);
      cookie = login.headers
        .getSetCookie()
        .map((c) => c.split(";")[0])
        .join("; ");
    }
    const response = await fetch(`${origin}/api/v1/customers`, {
      headers: { cookie },
    });
    assert.equal(response.status, 200);
    const records = await response.json();
    if (index === 0) customers = records;
    else assert.deepEqual(records, customers);
    const document = await fetch(`${origin}/customers`, {
      headers: { accept: "text/html" },
    });
    assert.equal(document.status, 200);
    const html = await document.text();
    assert.equal(createHash("sha256").update(html).digest("hex"), digest(path));
    await stop();
    console.log(
      `PASS isolated artifact ${index === 1 ? "B" : "A"}: exact frontend, durable customer data and persistent auth session.`,
    );
  }
  console.log(
    "PASS A -> B -> A rollback rehearsal on disposable database; live origins untouched.",
  );
} finally {
  await stop();
}
