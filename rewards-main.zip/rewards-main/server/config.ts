import { z } from "zod";

const schema = z.object({
  APP_ENV: z.enum(["demo", "test"]),
  PUBLIC_ORIGIN: z.url(),
  PORT: z.coerce.number().int().min(1024).max(65535),
  DATABASE_PATH: z.string().min(1),
  AUTH_SECRET: z
    .string()
    .min(32)
    .refine((s) => !s.includes("replace-with")),
  NOTIFICATION_MODE: z.literal("capture"),
  LIVE_CAMPAIGNS_ENABLED: z.literal("false"),
  RELEASE_ID: z.string().min(1),
  CAPTURE_DIR: z.string().min(1),
});
export type Config = z.infer<typeof schema>;
export function config(env: NodeJS.ProcessEnv = process.env): Config {
  const result = schema.safeParse(env);
  if (!result.success)
    throw new Error(
      `Invalid configuration keys: ${result.error.issues.map((i) => i.path.join(".")).join(", ")}`,
    );
  const url = new URL(result.data.PUBLIC_ORIGIN);
  if (
    url.origin !== result.data.PUBLIC_ORIGIN ||
    (url.protocol !== "https:" &&
      !["127.0.0.1", "localhost"].includes(url.hostname))
  ) {
    throw new Error(
      "PUBLIC_ORIGIN must be a bare HTTPS origin or local loopback origin",
    );
  }
  return result.data;
}
