import { config } from "./config.js";
import { Store } from "./db.js";
import { createAuth } from "./auth.js";
import { createApp } from "./app.js";

const cfg = config();
const db = new Store(cfg.DATABASE_PATH);
if (!db.get("SELECT version FROM schema_migrations WHERE version=3"))
  throw new Error("Run db:migrate before starting");
const app = createApp(db, createAuth(db, cfg), cfg).finish();
const server = app.listen(cfg.PORT, "127.0.0.1", () =>
  console.log(
    `RewardPoint ${cfg.RELEASE_ID} listening on loopback port ${cfg.PORT}; capture mode`,
  ),
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () =>
    server.close(() => {
      db.close();
      process.exit(0);
    }),
  );
