import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import request from "supertest";
import { Store, migrate } from "../server/db.js";
import { createAuth, migrateAuth } from "../server/auth.js";
import { createApp } from "../server/app.js";
import { seed } from "../server/seed.js";
import type { Config } from "../server/config.js";

export async function fixture() {
  const dir = mkdtempSync(join(tmpdir(), "rewardpoint-test-"));
  const cfg: Config = {
    APP_ENV: "test",
    PORT: 4187,
    PUBLIC_ORIGIN: "http://127.0.0.1:4187",
    DATABASE_PATH: join(dir, "test.sqlite"),
    AUTH_SECRET: randomBytes(48).toString("hex"),
    NOTIFICATION_MODE: "capture",
    LIVE_CAMPAIGNS_ENABLED: "false",
    RELEASE_ID: "test",
    CAPTURE_DIR: join(dir, "capture"),
  };
  const db = new Store(cfg.DATABASE_PATH);
  const auth = createAuth(db, cfg);
  await migrateAuth(auth);
  migrate(db);
  const password = randomBytes(24).toString("hex");
  const users = await seed(db, cfg, password);
  const app = createApp(db, auth, cfg).finish();
  async function login(email = "admin@northstar.invalid") {
    const agent = request.agent(app);
    await agent
      .post("/api/auth/sign-in/email")
      .set("Origin", cfg.PUBLIC_ORIGIN)
      .send({ email, password })
      .expect(200);
    return agent;
  }
  return { db, auth, cfg, app, users, password, login, dir };
}
