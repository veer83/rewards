export interface Me {
  user_id: string;
  tenant_id: string;
  name: string;
  email: string;
  role: "admin" | "sales" | "customer";
  customer_id: string | null;
  dealer: { name: string; currency: string; timezone: string };
  release: string;
}
export interface Customer {
  id: string;
  name: string;
  email: string;
  verified: number;
  dealer_reference: string;
  created_at: string;
  user_id?: string | null;
}
export interface Campaign {
  id: string;
  name: string;
  status: string;
  version_id: string;
  version: number;
  referrer_amount: number;
  recipient_amount: number;
  discount_amount: number;
  currency: string;
  terms: string;
  starts_at: string;
  ends_at: string;
  purchase_by: string;
  published_at: string | null;
}
export interface Referral {
  id: string;
  customer_id: string;
  name: string;
  campaign: string;
  accepted: number;
  revoked: number;
  share_url: string;
}
export interface Lead {
  id: string;
  name: string;
  email: string;
  referrer: string;
  campaign: string;
  customer_id: string;
  contact: number;
  marketing: number;
  stage: string;
  review: number;
  verified: number;
  created_at: string;
  interest: string;
  assigned_to: string;
}
export interface Offer {
  campaign: string;
  dealer: string;
  version_id: string;
  version: number;
  referrer_amount: number;
  recipient_amount: number;
  discount_amount: number;
  currency: string;
  terms: string;
  ends_at: string;
  purchase_by: string;
}
export interface Audit {
  id: string;
  action: string;
  object_id: string;
  reason: string;
  created_at: string;
}
export interface Settings {
  users: {
    user_id: string;
    name: string;
    email: string;
    role: string;
    active: number;
  }[];
  audit: Audit[];
  outbox: {
    id: string;
    purpose: string;
    status: string;
    attempts: number;
    created_at: string;
    captured_body?: string | null;
  }[];
  notification_mode: string;
  assumptions: string;
}
export interface LeadDetail {
  customer: Customer;
  activities: { id: string; kind: string; note: string; created_at: string }[];
  consents: {
    id: string;
    purpose: string;
    granted: number;
    text_version: string;
    created_at: string;
  }[];
  offer: Campaign;
}
export interface Grant {
  id: string;
  customer_id: string;
  sale_id: string;
  name: string;
  beneficiary: string;
  amount: number;
  balance: number;
  held: number;
  available: number;
  state: string;
  currency: string;
  created_at: string;
}
export interface Sale {
  id: string;
  lead_id: string;
  reference: string;
  recipient: string;
  referrer: string;
  discount_amount: number;
  status: string;
  evidence: string;
  delivered_at: string;
  created_at: string;
}
export interface Redemption {
  id: string;
  customer_id: string;
  name: string;
  invoice: string;
  amount: number;
  status: string;
  reason: string;
  created_at: string;
  updated_at: string;
}
export interface Ledger {
  id: string;
  customer_id: string;
  kind: string;
  amount: number;
  currency: string;
  reason: string;
  source_id: string | null;
  created_at: string;
}
export interface Review {
  id: string;
  object_id: string;
  kind: string;
  reason: string;
  status: string;
  resolution: string | null;
  created_at: string;
}
export interface Reconciliation {
  currency: string;
  issued: number;
  used: number;
  restored: number;
  reversed: number;
  posted: number;
  held: number;
  frozen: number;
  available: number;
  pending: number;
  balanced: boolean;
  cohort: string;
  as_of: string;
  accepted: number;
  recorded_sales: number;
  verified_sales: number;
  open_reviews: number;
}
