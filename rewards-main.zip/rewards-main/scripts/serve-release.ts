import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { config } from "../server/config.js";

const name = process.argv[2];
if (!name || !/^[a-zA-Z0-9_-]{3,80}$/.test(name))
  throw new Error("Provide an existing release artifact name");
const root = resolve("."),
  artifact = resolve(".local/releases", name),
  cfg = config();
const manifest = JSON.parse(
  readFileSync(resolve(artifact, "manifest.json"), "utf8"),
);
if (
  createHash("sha256")
    .update(readFileSync("package-lock.json"))
    .digest("hex") !== manifest.lock_sha256
)
  throw new Error(
    "Dependency lock differs from artifact; use the matching isolated release checkout and npm ci",
  );
const child = spawn(
  process.execPath,
  [resolve(artifact, "dist-server/server/index.js")],
  {
    cwd: artifact,
    env: {
      ...process.env,
      ...cfg,
      PORT: String(cfg.PORT),
      DATABASE_PATH: resolve(root, cfg.DATABASE_PATH),
      CAPTURE_DIR: resolve(root, cfg.CAPTURE_DIR),
      RELEASE_ID: `${manifest.git_head.slice(0, 12)}${manifest.dirty ? "-dirty" : ""}`,
    },
    stdio: "inherit",
  },
);
for (const signal of ["SIGINT", "SIGTERM"] as const)
  process.on(signal, () => child.kill(signal));
child.on("exit", (code) => process.exit(code ?? 1));
