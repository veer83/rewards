import { config } from "../server/config.js";
import { Store } from "../server/db.js";
import { seed } from "../server/seed.js";
const cfg = config();
const db = new Store(cfg.DATABASE_PATH);
await seed(db, cfg, process.env.SEED_PASSWORD || "");
db.close();
console.log("Synthetic RewardPoint seed complete; no messages delivered.");
