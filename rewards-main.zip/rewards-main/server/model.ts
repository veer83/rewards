export interface Actor {
  user_id: string;
  tenant_id: string;
  role: "admin" | "sales" | "customer";
  customer_id: string | null;
  active: number;
  name: string;
  email: string;
}
export interface Customer {
  id: string;
  tenant_id: string;
  name: string;
  email: string;
  dealer_reference: string;
  verified: number;
  owner_id: string;
  user_id: string | null;
  created_at: string;
}
export interface Version {
  id: string;
  tenant_id: string;
  campaign_id: string;
  version: number;
  referrer_amount: number;
  discount_amount: number;
  recipient_amount: number;
  currency: string;
  terms: string;
  starts_at: string;
  ends_at: string;
  purchase_by: string;
  published_at: string | null;
}
export interface Campaign {
  id: string;
  tenant_id: string;
  name: string;
  status: string;
  created_at: string;
}
export interface Enrollment {
  id: string;
  tenant_id: string;
  customer_id: string;
  version_id: string;
  token_hash: string;
  token_cipher: string;
  eligibility: string;
  revoked: number;
  created_at: string;
}
export interface Lead {
  id: string;
  tenant_id: string;
  enrolment_id: string;
  customer_id: string;
  email_normalized: string;
  interest: string;
  stage: string;
  assigned_to: string;
  review: number;
  created_at: string;
}
export class DomainError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export function requireThat(
  condition: unknown,
  status: number,
  message: string,
): asserts condition {
  if (!condition) throw new DomainError(status, message);
}
export function admin(actor: Actor) {
  requireThat(actor.role === "admin", 403, "Administrator access required");
}
export function staff(actor: Actor) {
  requireThat(actor.role !== "customer", 403, "Staff access required");
}
