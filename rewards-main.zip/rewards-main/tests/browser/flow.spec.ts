import { test, expect } from "@playwright/test";
import { readFileSync, mkdirSync } from "node:fs";

test("built app: sign-in, enrollment, no-contact public offer, persistent lead, theme and logout", async ({
  page,
  browser,
}) => {
  const { password } = JSON.parse(readFileSync(".local/e2e.json", "utf8"));
  await page
    .context()
    .route("**/*", (route) =>
      new URL(route.request().url()).hostname === "127.0.0.1"
        ? route.continue()
        : route.abort(),
    );
  await page.goto("/");
  mkdirSync("output/screenshots", { recursive: true });
  await page.screenshot({
    path: "output/screenshots/login-desktop.png",
    fullPage: true,
  });
  await page
    .getByLabel("Email address", { exact: true })
    .fill("admin@northstar.invalid");
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign In", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Overview", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Enroll customer", exact: true })
    .click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByLabel("Customer", { exact: true })
    .selectOption({ label: "Alex Morgan" });
  await dialog.getByLabel("Published demo campaign").selectOption({ index: 1 });
  await dialog
    .getByLabel("Purchaser eligibility evidence")
    .fill("Verified synthetic vehicle purchase DEMO-001");
  await dialog
    .getByLabel("I have recorded permission to invite this customer")
    .check();
  await dialog.getByRole("button", { name: "Enroll customer" }).click();
  await expect(dialog).not.toBeVisible();
  await page.getByRole("link", { name: "Referrals", exact: true }).click();
  await expect(page.getByRole("link", { name: "View offer" })).toBeVisible();
  const url = await page
    .getByRole("link", { name: "View offer" })
    .getAttribute("href");
  await page.screenshot({
    path: "output/screenshots/referrals-desktop.png",
    fullPage: true,
  });
  const recipient = await browser.newContext({
    viewport: { width: 390, height: 844 },
  });
  await recipient.route("**/*", (route) =>
    new URL(route.request().url()).hostname === "127.0.0.1"
      ? route.continue()
      : route.abort(),
  );
  const offer = await recipient.newPage();
  await offer.goto(url!);
  await expect(
    offer.getByRole("heading", { name: "Keep the offer. Choose the contact." }),
  ).toBeVisible();
  await offer.screenshot({
    path: "output/screenshots/offer-mobile.png",
    fullPage: true,
  });
  await offer.getByLabel("Full name").fill("Casey Demo");
  await offer
    .getByLabel("Email address", { exact: true })
    .fill("casey@recipient.invalid");
  await offer.getByLabel("Contact about this offer").selectOption("none");
  await offer.getByLabel("I accept the displayed demo terms").check();
  await offer.getByLabel("I understand this synthetic information").check();
  await offer.getByRole("button", { name: "Accept demo offer" }).click();
  await expect(
    offer.getByRole("heading", { name: "You’re on the list." }),
  ).toBeVisible();
  await page.getByRole("link", { name: "Lead Bank", exact: true }).click();
  await page.reload();
  await expect(page.getByText("Casey Demo", { exact: true })).toBeVisible();
  await expect(
    page
      .getByRole("region", { name: "Lead Bank" })
      .getByText("No Contact", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "View", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.screenshot({
    path: "output/screenshots/lead-detail.png",
    fullPage: true,
  });
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await expect(
    page.getByRole("button", { name: "View", exact: true }),
  ).toBeFocused();
  await page.getByRole("button", { name: "Add activity", exact: true }).click();
  await page
    .getByRole("dialog")
    .getByLabel("Activity", { exact: true })
    .selectOption("identity");
  await page
    .getByRole("dialog")
    .getByLabel("Evidence / note")
    .fill(
      "Verified synthetic recipient identity against independent delivery evidence",
    );
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Save", exact: true })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByRole("button", { name: "Record sale", exact: true }).click();
  await page
    .getByRole("dialog")
    .getByLabel("Unique dealer sale reference")
    .fill("BROWSER-SALE-001");
  await page
    .getByRole("dialog")
    .getByLabel("Delivery and source-system evidence")
    .fill("Verified synthetic delivered vehicle sale in isolated browser test");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Submit for verification" })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page
    .getByRole("link", { name: "Rewards & Credits", exact: true })
    .click();
  await page.getByRole("tab", { name: /Sale approvals/ }).click();
  await page.getByRole("button", { name: "Verify & issue" }).click();
  await page
    .getByRole("dialog")
    .getByLabel("I verified the delivered sale")
    .check();
  await page
    .getByRole("dialog")
    .getByLabel("Evidence and reason")
    .fill(
      "Both synthetic beneficiaries and delivered vehicle sale independently verified",
    );
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Approve & issue once" })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByRole("tab", { name: "Service credits", exact: true }).click();
  await expect(
    page.getByRole("region", { name: "Service credits" }).getByRole("row"),
  ).toHaveCount(3);
  await page
    .getByRole("button", { name: "Reserve credit", exact: true })
    .click();
  await page
    .getByRole("dialog")
    .getByLabel("Customer", { exact: true })
    .selectOption({ label: "Alex Morgan" });
  await page
    .getByRole("dialog")
    .getByLabel("External invoice reference")
    .fill("BROWSER-INVOICE-001");
  await page
    .getByRole("dialog")
    .getByLabel("Amount to reserve (CAD cents)")
    .fill("12500");
  await page
    .getByRole("dialog")
    .getByLabel("Evidence and reason")
    .fill("Verified identity and eligible synthetic service invoice");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Reserve credit" })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByRole("tab", { name: "Redemptions", exact: true }).click();
  await page.getByRole("button", { name: "Uncertain", exact: true }).click();
  await page
    .getByRole("dialog")
    .getByLabel("Verified external outcome")
    .selectOption("uncertain");
  await page
    .getByRole("dialog")
    .getByLabel("Evidence and reason")
    .fill(
      "External response unavailable; retain reservation for investigation",
    );
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Flag uncertain invoice usage" })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByRole("button", { name: "Confirm", exact: true }).click();
  await page
    .getByRole("dialog")
    .getByLabel("Verified external outcome")
    .selectOption("applied");
  await page
    .getByRole("dialog")
    .getByLabel("Evidence and reason")
    .fill(
      "Checked external synthetic invoice and confirmed credit was applied",
    );
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Confirm external application" })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.screenshot({
    path: "output/screenshots/redemption-desktop.png",
    fullPage: true,
  });
  await page.getByRole("link", { name: "Reports", exact: true }).click();
  await expect(
    page.getByText("Ledger reconciles exactly.", { exact: false }),
  ).toBeVisible();
  await page.screenshot({
    path: "output/screenshots/reconciliation-desktop.png",
    fullPage: true,
  });
  await page.getByRole("link", { name: "Overview", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Overview", exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: "output/screenshots/overview-light.png",
    fullPage: true,
  });
  await page.getByLabel("Theme", { exact: true }).selectOption("dark");
  await page.screenshot({
    path: "output/screenshots/overview-dark.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Sign in to your workspace" }),
  ).toBeVisible();
  await page
    .getByLabel("Email address", { exact: true })
    .fill("customer@northstar.invalid");
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign In", exact: true }).click();
  await expect(
    page.getByRole("heading", {
      name: "Your connections & credits",
      exact: true,
    }),
  ).toBeVisible();
  await expect(
    page.getByRole("region", { name: "Service credits" }).getByRole("row"),
  ).toHaveCount(2);
  await expect(page.getByText("Casey Demo", { exact: true })).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "Reserve credit", exact: true }),
  ).toHaveCount(0);
  await page.screenshot({
    path: "output/screenshots/customer-private-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await expect
    .poll(() =>
      page.evaluate(() => document.documentElement.scrollWidth <= innerWidth),
    )
    .toBe(true);
  await page.screenshot({
    path: "output/screenshots/customer-private-mobile.png",
    fullPage: true,
  });
  await page
    .getByRole("button", { name: "Your profile & contact preferences" })
    .click();
  await page
    .getByRole("dialog")
    .getByLabel("Contact purpose")
    .selectOption("marketing");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Save", exact: true })
    .click();
  await expect(page.getByText("Your preference was saved.")).toBeVisible();
  await page.keyboard.press("Escape");
  await page.setViewportSize({ width: 1440, height: 900 });
  const secondTab = await page.context().newPage();
  await secondTab.goto("/");
  await expect(
    secondTab.getByRole("heading", {
      name: "Your connections & credits",
      exact: true,
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(
    secondTab.getByRole("heading", { name: "Sign in to your workspace" }),
  ).toBeVisible();
  await page
    .getByLabel("Email address", { exact: true })
    .fill("admin@lakeside.invalid");
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign In", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Overview", exact: true }),
  ).toBeVisible();
  await page.getByRole("link", { name: "Customers", exact: true }).click();
  await expect(page.getByText("Alex Morgan", { exact: true })).toHaveCount(0);
  await expect(
    secondTab.getByRole("heading", { name: "Overview", exact: true }),
  ).toBeVisible();
  await secondTab.close();
  await recipient.close();
});

test("configuration/API failure never falls back to a demo identity; responsive themes and invalid links", async ({
  page,
}) => {
  await page.route("**/api/v1/me", (route) =>
    route.fulfill({
      status: 503,
      contentType: "application/json",
      body: JSON.stringify({
        error: "Isolated test: session service unavailable",
      }),
    }),
  );
  await page.goto("/customers");
  await expect(page.getByRole("alert")).toContainText(
    "session service unavailable",
  );
  await expect(
    page.getByRole("navigation", { name: "Main navigation" }),
  ).toHaveCount(0);
  for (const width of [390, 768, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    await page.getByLabel("Theme", { exact: true }).selectOption("system");
    await page.emulateMedia({ colorScheme: "dark" });
    await expect(page.locator("html")).toHaveAttribute("data-theme", "dark");
    await page.emulateMedia({ colorScheme: "light" });
    await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
    await expect
      .poll(() =>
        page.evaluate(() => document.documentElement.scrollWidth <= innerWidth),
      )
      .toBe(true);
  }
  await page.goto("/r/not-a-real-offer");
  await expect(page.getByRole("alert")).toContainText("Offer unavailable");
  await expect(
    page.getByRole("button", { name: "Accept demo offer" }),
  ).toHaveCount(0);
  await page.getByRole("button", { name: "Retry", exact: true }).click();
  await expect(page.getByRole("alert")).toContainText("Offer unavailable");
  await page.goto("/offer/confirmation/not-a-receipt");
  await expect(page.getByRole("alert")).toContainText("Receipt unavailable");
});
