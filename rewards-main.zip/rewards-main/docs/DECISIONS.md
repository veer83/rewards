# Independent synthetic demo

RewardPoint owns its authentication, database, sessions, and ledger. It has no Service Portal network or filesystem dependency. Existing React/TypeScript and Node conventions are retained; SQLite WAL avoids provisioning paid resources for the isolated single-host demo. Write transactions use BEGIN IMMEDIATE and database uniqueness to serialize competing financial operations. A multi-host deployment needs a separate database scaling decision.

All amounts are integer currency minor units. Referrer service credit, recipient service credit and vehicle discount remain distinct. Terms and benefits are versioned. No real money, external invoice posting, email or SMS delivery is enabled.

D01-D12 remain unapproved: delivered-sale qualification; CAD; verified purchaser eligibility; first valid attribution with conflict review; separate acceptance and purchase windows; same-dealer partial service usage; no automatic credit expiry; linked reversals and used-credit exceptions; administrator financial authority; consent-aware invitations; retention/privacy/sender approval; one referral offer type.

Original source in this repository is authorized for this private destination by the project owner. No licence is inferred for third-party artwork. Reused brand files need explicit confirmation and a provenance record. Fonts are not copied from local or assistant font collections.

Authentication uses Better Auth, following its official Express and SQLite integration documentation. Public signup is disabled. Synthetic seed accounts authenticate through the same password/session flow as all accounts. Credentials and captures remain local and ignored.
