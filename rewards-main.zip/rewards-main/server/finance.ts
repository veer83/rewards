import { z } from "zod";
import { id, now, type Store } from "./db.js";
import {
  admin,
  requireThat,
  type Actor,
  type Enrollment,
  type Version,
  type Customer,
} from "./model.js";
import { audit, customer, lead, operation, queue } from "./common.js";

export interface Sale {
  id: string;
  tenant_id: string;
  lead_id: string;
  reference: string;
  delivered_at: string;
  evidence: string;
  discount_amount: number;
  status: string;
  created_at: string;
}
export interface Grant {
  id: string;
  tenant_id: string;
  sale_id: string;
  customer_id: string;
  beneficiary: string;
  amount: number;
  currency: string;
  state: string;
  created_at: string;
  balance: number;
  held: number;
  available: number;
}
export interface Redemption {
  id: string;
  tenant_id: string;
  customer_id: string;
  invoice: string;
  amount: number;
  currency: string;
  status: string;
  reason: string;
  created_at: string;
  updated_at: string;
}
interface Ledger {
  id: string;
  tenant_id: string;
  grant_id: string;
  customer_id: string;
  kind: string;
  amount: number;
  currency: string;
  operation_id: string;
  source_id: string | null;
}
const note = z.string().trim().min(10).max(1500);
const reference = z
  .string()
  .trim()
  .min(3)
  .max(100)
  .transform((s) => s.toUpperCase());

export function grants(db: Store, tenant: string, customerId?: string) {
  return db
    .all<Grant>(
      `SELECT g.*, COALESCE((SELECT sum(amount) FROM ledger WHERE grant_id=g.id),0) balance,
    COALESCE((SELECT sum(a.amount) FROM allocations a JOIN redemptions r ON r.id=a.redemption_id WHERE a.grant_id=g.id AND r.status IN ('reserved','review')),0) held
    FROM grants g WHERE g.tenant_id=? ${customerId ? "AND g.customer_id=?" : ""} ORDER BY g.created_at,g.id`,
      tenant,
      ...(customerId ? [customerId] : []),
    )
    .map((g) => ({
      ...g,
      available: g.state === "issued" ? g.balance - g.held : 0,
    }));
}
export function recordSale(
  db: Store,
  a: Actor,
  lid: string,
  input: unknown,
  key?: string,
) {
  const v = z
    .object({
      reference,
      delivered_at: z.iso
        .datetime()
        .transform((value) => new Date(value).toISOString()),
      evidence: note,
      discount_amount: z.number().int().min(0).max(10000000),
    })
    .strict()
    .parse(input);
  return operation(
    db,
    `${a.tenant_id}:${a.user_id}:sale:${lid}`,
    key,
    v,
    () => {
      const l = lead(db, a, lid);
      requireThat(
        !l.review,
        409,
        "Resolve identity or attribution review before recording a sale",
      );
      const version = db.get<Version>(
        "SELECT v.* FROM campaign_versions v JOIN enrolments e ON e.version_id=v.id WHERE e.id=?",
        l.enrolment_id,
      )!;
      requireThat(
        v.delivered_at <= now() &&
          v.delivered_at >= l.created_at &&
          v.delivered_at <= version.purchase_by,
        400,
        "Delivery must follow acceptance, be in the past, and meet the accepted purchase deadline",
      );
      requireThat(
        v.discount_amount <= version.discount_amount,
        400,
        "Vehicle discount exceeds accepted offer",
      );
      const sid = id();
      db.run(
        "INSERT INTO sales(id,tenant_id,lead_id,reference,delivered_at,evidence,discount_amount,status,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
        sid,
        a.tenant_id,
        lid,
        v.reference,
        v.delivered_at,
        v.evidence,
        v.discount_amount,
        "pending",
        now(),
      );
      db.run("UPDATE leads SET stage='Sold' WHERE id=?", lid);
      audit(db, a, "sale.recorded", sid, v.evidence);
      return { id: sid, status: "pending" };
    },
  );
}
function post(
  db: Store,
  a: Actor,
  g: Pick<Grant, "id" | "customer_id" | "currency">,
  kind: string,
  amount: number,
  op: string,
  reason: string,
  source: string | null = null,
) {
  db.run(
    "INSERT INTO ledger VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
    id(),
    a.tenant_id,
    g.id,
    g.customer_id,
    kind,
    amount,
    g.currency,
    op,
    source,
    a.user_id,
    reason,
    now(),
  );
}
export function approveSale(
  db: Store,
  a: Actor,
  sid: string,
  input: unknown,
  key?: string,
) {
  admin(a);
  const v = z
    .object({ verified: z.literal(true), reason: note })
    .strict()
    .parse(input);
  return operation(
    db,
    `${a.tenant_id}:${a.user_id}:approve:${sid}`,
    key,
    v,
    () => {
      const sale = db.get<Sale>(
        "SELECT * FROM sales WHERE id=? AND tenant_id=?",
        sid,
        a.tenant_id,
      );
      requireThat(sale, 404, "Sale unavailable");
      if (sale.status === "approved") return { id: sid, status: "approved" };
      requireThat(
        sale.status === "pending",
        409,
        "Sale is not pending approval",
      );
      const l = lead(db, a, sale.lead_id);
      const e = db.get<Enrollment>(
        "SELECT * FROM enrolments WHERE id=?",
        l.enrolment_id,
      )!;
      const version = db.get<Version>(
        "SELECT * FROM campaign_versions WHERE id=?",
        e.version_id,
      )!;
      const recipient = db.get<Customer>(
        "SELECT * FROM customers WHERE id=?",
        l.customer_id,
      )!;
      const referrer = db.get<Customer>(
        "SELECT * FROM customers WHERE id=?",
        e.customer_id,
      )!;
      requireThat(
        recipient.verified &&
          referrer.verified &&
          !l.review &&
          recipient.id !== referrer.id &&
          recipient.email.toLowerCase() !== referrer.email.toLowerCase(),
        409,
        "Verify both beneficiary identities and resolve duplicate/self-referral checks first",
      );
      for (const [role, cid, amount] of [
        ["referrer", referrer.id, version.referrer_amount],
        ["recipient", recipient.id, version.recipient_amount],
      ] as const) {
        if (amount === 0) continue;
        const gid = id();
        db.run(
          "INSERT INTO grants VALUES (?,?,?,?,?,?,?,?,?)",
          gid,
          a.tenant_id,
          sid,
          cid,
          role,
          amount,
          version.currency,
          "issued",
          now(),
        );
        post(
          db,
          a,
          { id: gid, customer_id: cid, currency: version.currency },
          "issue",
          amount,
          `sale:${sid}`,
          v.reason,
        );
        queue(
          db,
          a.tenant_id,
          cid,
          role === "referrer" ? "invitation" : "offer",
          `grant:${gid}`,
        );
      }
      db.run(
        "UPDATE sales SET status='approved',verified_by=?,verified_at=? WHERE id=?",
        a.user_id,
        now(),
        sid,
      );
      audit(db, a, "sale.approved.credit_bundle_issued", sid, v.reason);
      return { id: sid, status: "approved" };
    },
  );
}
export function reserve(db: Store, a: Actor, input: unknown, key?: string) {
  admin(a);
  const v = z
    .object({
      customer_id: z.string(),
      invoice: reference,
      amount: z.number().int().min(1).max(10000000),
      reason: note,
    })
    .strict()
    .parse(input);
  return operation(db, `${a.tenant_id}:${a.user_id}:reserve`, key, v, () => {
    const c = customer(db, a, v.customer_id);
    requireThat(c.verified, 409, "Verify customer identity before redemption");
    const eligible = grants(db, a.tenant_id, c.id).filter(
      (g) => g.available > 0,
    );
    const available = eligible.reduce((s, g) => s + g.available, 0);
    requireThat(
      available >= v.amount,
      409,
      "Insufficient available credit; held or frozen funds cannot be spent",
    );
    const rid = id();
    db.run(
      "INSERT INTO redemptions VALUES (?,?,?,?,?,?,?,?,?,?)",
      rid,
      a.tenant_id,
      c.id,
      v.invoice,
      v.amount,
      "CAD",
      "reserved",
      v.reason,
      now(),
      now(),
    );
    let remainder = v.amount;
    for (const g of eligible) {
      if (remainder === 0) break;
      const allocation = Math.min(g.available, remainder);
      db.run(
        "INSERT INTO allocations VALUES (?,?,?,?)",
        rid,
        a.tenant_id,
        g.id,
        allocation,
      );
      remainder -= allocation;
    }
    audit(db, a, "redemption.reserved", rid, v.reason);
    return { id: rid, status: "reserved", amount: v.amount };
  });
}
export function redemptionAction(
  db: Store,
  a: Actor,
  rid: string,
  action: string,
  input: unknown,
  key?: string,
) {
  admin(a);
  const v = z
    .object({
      reason: note,
      external_outcome: z.enum([
        "applied",
        "not_applied",
        "uncertain",
        "invoice_voided",
      ]),
    })
    .strict()
    .parse(input);
  return operation(
    db,
    `${a.tenant_id}:${a.user_id}:redemption:${rid}:${action}`,
    key,
    v,
    () => {
      const r = db.get<Redemption>(
        "SELECT * FROM redemptions WHERE id=? AND tenant_id=?",
        rid,
        a.tenant_id,
      );
      requireThat(r, 404, "Redemption unavailable");
      const target = (
        {
          confirm: "confirmed",
          release: "released",
          review: "review",
          reverse: "reversed",
        } as Record<string, string>
      )[action];
      requireThat(target, 400, "Unknown redemption action");
      requireThat(
        (action === "confirm" && v.external_outcome === "applied") ||
          (action === "release" && v.external_outcome === "not_applied") ||
          (action === "review" && v.external_outcome === "uncertain") ||
          (action === "reverse" && v.external_outcome === "invoice_voided"),
        400,
        "Explicit matching external outcome is required",
      );
      if (r.status === target) return { id: rid, status: target };
      requireThat(
        action === "reverse"
          ? r.status === "confirmed"
          : ["reserved", "review"].includes(r.status),
        409,
        "Redemption state does not allow that action",
      );
      const allocations = db.all<{ grant_id: string; amount: number }>(
        "SELECT grant_id,amount FROM allocations WHERE redemption_id=?",
        rid,
      );
      for (const alloc of allocations) {
        const g = db.get<Grant>(
          "SELECT * FROM grants WHERE id=?",
          alloc.grant_id,
        )!;
        if (action === "confirm") {
          requireThat(
            g.state !== "reversed",
            409,
            "Source entitlement reversed; reconcile before posting",
          );
          post(db, a, g, "use", -alloc.amount, `redemption:${rid}`, v.reason);
        }
        if (action === "reverse") {
          requireThat(
            g.state === "issued",
            409,
            "Source sale is frozen or reversed; resolve the source-sale exception before restoring credit",
          );
          const original = db.get<Ledger>(
            "SELECT * FROM ledger WHERE grant_id=? AND operation_id=? AND kind='use'",
            g.id,
            `redemption:${rid}`,
          )!;
          post(
            db,
            a,
            g,
            "restore",
            alloc.amount,
            `restore:${rid}`,
            v.reason,
            original.id,
          );
        }
      }
      db.run(
        "UPDATE redemptions SET status=?,reason=?,updated_at=? WHERE id=?",
        target,
        v.reason,
        now(),
        rid,
      );
      if (action === "review")
        db.run(
          "INSERT INTO reviews(id,tenant_id,object_id,kind,reason,created_at) VALUES (?,?,?,?,?,?)",
          id(),
          a.tenant_id,
          rid,
          "uncertain_invoice",
          v.reason,
          now(),
        );
      else
        db.run(
          "UPDATE reviews SET status='resolved',resolution=? WHERE object_id=? AND tenant_id=? AND kind='uncertain_invoice' AND status='open'",
          v.reason,
          rid,
          a.tenant_id,
        );
      audit(db, a, `redemption.${action}`, rid, v.reason);
      return { id: rid, status: target };
    },
  );
}
export function cancelSale(
  db: Store,
  a: Actor,
  sid: string,
  input: unknown,
  key?: string,
) {
  admin(a);
  const v = z.object({ reason: note }).strict().parse(input);
  return operation(
    db,
    `${a.tenant_id}:${a.user_id}:cancel-sale:${sid}`,
    key,
    v,
    () => {
      const s = db.get<Sale>(
        "SELECT * FROM sales WHERE id=? AND tenant_id=?",
        sid,
        a.tenant_id,
      );
      requireThat(s, 404, "Sale unavailable");
      if (["cancelled", "reversed", "review"].includes(s.status))
        return { id: sid, status: s.status };
      if (s.status === "pending") {
        db.run("UPDATE sales SET status='cancelled' WHERE id=?", sid);
        audit(db, a, "sale.cancelled", sid, v.reason);
        return { id: sid, status: "cancelled" };
      }
      const bundle = grants(db, a.tenant_id).filter((g) => g.sale_id === sid);
      const unsafe = bundle.some((g) => g.balance !== g.amount || g.held > 0);
      if (unsafe) {
        db.run("UPDATE grants SET state='review' WHERE sale_id=?", sid);
        db.run("UPDATE sales SET status='review' WHERE id=?", sid);
        db.run(
          "INSERT INTO reviews(id,tenant_id,object_id,kind,reason,created_at) VALUES (?,?,?,?,?,?)",
          id(),
          a.tenant_id,
          sid,
          "used_credit_cancellation",
          v.reason,
          now(),
        );
      } else {
        for (const g of bundle) {
          const original = db.get<Ledger>(
            "SELECT * FROM ledger WHERE grant_id=? AND kind='issue'",
            g.id,
          )!;
          post(
            db,
            a,
            g,
            "reverse",
            -g.amount,
            `cancel-sale:${sid}`,
            v.reason,
            original.id,
          );
        }
        db.run("UPDATE grants SET state='reversed' WHERE sale_id=?", sid);
        db.run("UPDATE sales SET status='reversed' WHERE id=?", sid);
      }
      audit(
        db,
        a,
        unsafe ? "sale.cancellation_review" : "sale.reversed",
        sid,
        v.reason,
      );
      return { id: sid, status: unsafe ? "review" : "reversed" };
    },
  );
}
export function resolveReview(
  db: Store,
  a: Actor,
  reviewId: string,
  input: unknown,
  key?: string,
) {
  admin(a);
  const v = z
    .object({
      reason: note,
      outcome: z.enum([
        "uphold_sale",
        "confirm_cancellation",
        "reviewed_no_change",
      ]),
    })
    .strict()
    .parse(input);
  return operation(
    db,
    `${a.tenant_id}:${a.user_id}:review:${reviewId}`,
    key,
    v,
    () => {
      const r = db.get<{
        id: string;
        object_id: string;
        kind: string;
        status: string;
      }>(
        "SELECT * FROM reviews WHERE id=? AND tenant_id=?",
        reviewId,
        a.tenant_id,
      );
      requireThat(r, 404, "Review unavailable");
      if (r.status === "resolved") return { id: reviewId, status: "resolved" };
      requireThat(
        r.kind !== "uncertain_invoice",
        409,
        "Resolve uncertain usage using the redemption confirmation or safe release action",
      );
      if (r.kind === "used_credit_cancellation") {
        const bundle = grants(db, a.tenant_id).filter(
          (g) => g.sale_id === r.object_id,
        );
        requireThat(
          v.outcome !== "reviewed_no_change",
          400,
          "Choose a source-sale outcome",
        );
        if (v.outcome === "confirm_cancellation") {
          requireThat(
            bundle.every((g) => g.held === 0 && g.balance === g.amount),
            409,
            "Used or held credit still requires review. No automatic debt or partial source reversal is allowed",
          );
          for (const g of bundle) {
            const original = db.get<Ledger>(
              "SELECT * FROM ledger WHERE grant_id=? AND kind='issue'",
              g.id,
            )!;
            post(
              db,
              a,
              g,
              "reverse",
              -g.amount,
              `review:${reviewId}`,
              v.reason,
              original.id,
            );
          }
          db.run(
            "UPDATE grants SET state='reversed' WHERE sale_id=?",
            r.object_id,
          );
          db.run("UPDATE sales SET status='reversed' WHERE id=?", r.object_id);
        } else {
          db.run(
            "UPDATE grants SET state='issued' WHERE sale_id=?",
            r.object_id,
          );
          db.run("UPDATE sales SET status='approved' WHERE id=?", r.object_id);
        }
      } else
        requireThat(
          v.outcome === "reviewed_no_change",
          400,
          "Attribution review preserves the original acceptance",
        );
      db.run(
        "UPDATE reviews SET status='resolved',resolution=? WHERE id=?",
        v.reason,
        reviewId,
      );
      if (
        r.kind === "attribution" &&
        !db.get(
          "SELECT id FROM reviews WHERE object_id=? AND kind='attribution' AND status='open'",
          r.object_id,
        )
      )
        db.run(
          "UPDATE leads SET review=0 WHERE id=? AND tenant_id=?",
          r.object_id,
          a.tenant_id,
        );
      audit(db, a, "review.resolved", reviewId, v.reason);
      return { id: reviewId, status: "resolved" };
    },
  );
}
export function reconciliation(db: Store, a: Actor) {
  admin(a);
  return db.transaction(() => {
    const g = grants(db, a.tenant_id);
    const ledger = db.all<{ kind: string; amount: number }>(
      "SELECT kind,sum(amount) amount FROM ledger WHERE tenant_id=? GROUP BY kind",
      a.tenant_id,
    );
    const sum = (kind: string) =>
      ledger.find((l) => l.kind === kind)?.amount || 0;
    const posted = g.reduce((s, g) => s + g.balance, 0),
      held = g.reduce((s, g) => s + g.held, 0),
      available = g.reduce((s, g) => s + g.available, 0);
    const frozen = g.reduce(
      (s, g) => s + (g.state === "review" ? g.balance - g.held : 0),
      0,
    );
    const pending = db.get<{ amount: number }>(
      "SELECT COALESCE(sum(v.referrer_amount+v.recipient_amount),0) amount FROM sales s JOIN leads l ON l.id=s.lead_id JOIN enrolments e ON e.id=l.enrolment_id JOIN campaign_versions v ON v.id=e.version_id WHERE s.tenant_id=? AND s.status='pending'",
      a.tenant_id,
    )!.amount;
    return {
      currency: "CAD",
      issued: sum("issue"),
      used: -sum("use"),
      restored: sum("restore"),
      reversed: -sum("reverse"),
      posted,
      held,
      frozen,
      available,
      pending,
      balanced:
        sum("issue") + sum("use") + sum("restore") + sum("reverse") ===
          posted &&
        posted - held - frozen === available &&
        g.every((g) => g.balance >= 0 && g.held <= g.balance),
      cohort: "All programme dates; unique accepted leads at this dealership",
      as_of: now(),
      accepted: db.get<{ n: number }>(
        "SELECT count(*) n FROM leads WHERE tenant_id=?",
        a.tenant_id,
      )!.n,
      recorded_sales: db.get<{ n: number }>(
        "SELECT count(*) n FROM sales WHERE tenant_id=?",
        a.tenant_id,
      )!.n,
      verified_sales: db.get<{ n: number }>(
        "SELECT count(*) n FROM sales WHERE tenant_id=? AND status='approved'",
        a.tenant_id,
      )!.n,
      open_reviews: db.get<{ n: number }>(
        "SELECT count(*) n FROM reviews WHERE tenant_id=? AND status='open'",
        a.tenant_id,
      )!.n,
    };
  });
}
