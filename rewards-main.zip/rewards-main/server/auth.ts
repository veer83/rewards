import { betterAuth } from "better-auth";
import { getMigrations } from "better-auth/db/migration";
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import type { Config } from "./config.js";
import type { Store } from "./db.js";

export function createAuth(store: Store, cfg: Config, provisioning = false) {
  return betterAuth({
    appName: "DriveOnyx RewardPoint",
    baseURL: cfg.PUBLIC_ORIGIN,
    secret: cfg.AUTH_SECRET,
    database: store.db,
    trustedOrigins: [cfg.PUBLIC_ORIGIN],
    emailAndPassword: {
      enabled: true,
      disableSignUp: !provisioning,
      minPasswordLength: 14,
      revokeSessionsOnPasswordReset: true,
      sendResetPassword: async ({ url }) => {
        mkdirSync(cfg.CAPTURE_DIR, { recursive: true, mode: 0o700 });
        writeFileSync(
          join(cfg.CAPTURE_DIR, `recovery-${randomUUID()}.txt`),
          `CAPTURE ONLY. Not delivered.\n${url}\n`,
          { mode: 0o600 },
        );
      },
    },
    session: {
      expiresIn: 60 * 60 * 8,
      updateAge: 60 * 30,
      cookieCache: { enabled: false },
    },
    advanced: {
      cookiePrefix: "rewardpoint",
      useSecureCookies: cfg.PUBLIC_ORIGIN.startsWith("https:"),
      defaultCookieAttributes: { httpOnly: true, sameSite: "lax", path: "/" },
    },
    rateLimit: { enabled: true, window: 60, max: 30 },
    logger: { disabled: true },
  });
}
export type Auth = ReturnType<typeof createAuth>;
export async function migrateAuth(auth: Auth) {
  await (await getMigrations(auth.options)).runMigrations();
}
