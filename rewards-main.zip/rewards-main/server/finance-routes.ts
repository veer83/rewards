import type { Express, Response } from "express";
import { z } from "zod";
import { admin, requireThat, type Actor } from "./model.js";
import { customer, audit, lead } from "./common.js";
import type { Store } from "./db.js";
import {
  approveSale,
  cancelSale,
  grants,
  recordSale,
  reconciliation,
  redemptionAction,
  reserve,
  resolveReview,
} from "./finance.js";

export function safeCsv(value: unknown) {
  const text = String(value ?? "");
  return `"${(/^[\s]*[=+\-@\t\r\n]/.test(text) ? "'" : "") + text.replaceAll('"', '""')}"`;
}
export function financialRoutes(app: Express, db: Store) {
  const actor = (res: Response) => res.locals.actor as Actor;
  app.post("/api/v1/customers/:id/verify", (req, res) => {
    const a = actor(res);
    admin(a);
    customer(db, a, req.params.id);
    const v = z
      .object({ reason: z.string().trim().min(10).max(1500) })
      .strict()
      .parse(req.body);
    db.transaction(() => {
      db.run("UPDATE customers SET verified=1 WHERE id=?", req.params.id);
      audit(db, a, "customer.identity_verified", req.params.id, v.reason);
    });
    res.json({ verified: true });
  });
  app.get("/api/v1/sales", (_req, res) => {
    const a = actor(res);
    requireThat(a.role !== "customer", 403, "Staff access required");
    res.json(
      db.all(
        `SELECT s.*,c.name recipient, r.name referrer FROM sales s JOIN leads l ON l.id=s.lead_id JOIN customers c ON c.id=l.customer_id JOIN enrolments e ON e.id=l.enrolment_id JOIN customers r ON r.id=e.customer_id WHERE s.tenant_id=? ${a.role === "sales" ? "AND l.assigned_to=?" : ""} ORDER BY s.created_at DESC`,
        a.tenant_id,
        ...(a.role === "sales" ? [a.user_id] : []),
      ),
    );
  });
  app.post("/api/v1/leads/:id/sales", (req, res) =>
    res
      .status(201)
      .json(
        recordSale(
          db,
          actor(res),
          req.params.id,
          req.body,
          req.get("Idempotency-Key"),
        ),
      ),
  );
  app.post("/api/v1/sales/:id/approve", (req, res) =>
    res.json(
      approveSale(
        db,
        actor(res),
        req.params.id,
        req.body,
        req.get("Idempotency-Key"),
      ),
    ),
  );
  app.post("/api/v1/sales/:id/cancel", (req, res) =>
    res.json(
      cancelSale(
        db,
        actor(res),
        req.params.id,
        req.body,
        req.get("Idempotency-Key"),
      ),
    ),
  );
  app.get("/api/v1/rewards/grants", (_req, res) => {
    const a = actor(res);
    requireThat(a.role !== "sales", 403, "Financial access required");
    const rows = grants(
      db,
      a.tenant_id,
      a.role === "customer" ? a.customer_id! : undefined,
    );
    res.json(
      rows.map((g) => ({
        ...g,
        name: db.get<{ name: string }>(
          "SELECT name FROM customers WHERE id=?",
          g.customer_id,
        )!.name,
      })),
    );
  });
  app.get("/api/v1/customers/:id/credit", (req, res) => {
    const a = actor(res);
    customer(db, a, req.params.id);
    requireThat(a.role !== "sales", 403, "Financial access required");
    res.json(grants(db, a.tenant_id, req.params.id));
  });
  app.get("/api/v1/ledger", (_req, res) => {
    const a = actor(res);
    requireThat(a.role !== "sales", 403, "Financial access required");
    res.json(
      db.all(
        `SELECT * FROM ledger WHERE tenant_id=? ${a.role === "customer" ? "AND customer_id=?" : ""} ORDER BY created_at DESC`,
        a.tenant_id,
        ...(a.role === "customer" ? [a.customer_id] : []),
      ),
    );
  });
  app.get("/api/v1/redemptions", (_req, res) => {
    const a = actor(res);
    requireThat(a.role !== "sales", 403, "Financial access required");
    res.json(
      db.all(
        `SELECT r.*,c.name FROM redemptions r JOIN customers c ON c.id=r.customer_id WHERE r.tenant_id=? ${a.role === "customer" ? "AND r.customer_id=?" : ""} ORDER BY r.created_at DESC`,
        a.tenant_id,
        ...(a.role === "customer" ? [a.customer_id] : []),
      ),
    );
  });
  app.get("/api/v1/redemptions/:id", (req, res) => {
    const a = actor(res);
    requireThat(a.role !== "sales", 403, "Financial access required");
    const r = db.get<{ customer_id: string }>(
      "SELECT * FROM redemptions WHERE id=? AND tenant_id=?",
      req.params.id,
      a.tenant_id,
    );
    requireThat(r, 404, "Redemption unavailable");
    customer(db, a, r.customer_id);
    res.json(r);
  });
  app.post("/api/v1/redemptions/reservations", (req, res) =>
    res
      .status(201)
      .json(reserve(db, actor(res), req.body, req.get("Idempotency-Key"))),
  );
  for (const action of ["confirm", "release", "review", "reverse"])
    app.post(`/api/v1/redemptions/:id/${action}`, (req, res) =>
      res.json(
        redemptionAction(
          db,
          actor(res),
          req.params.id,
          action,
          req.body,
          req.get("Idempotency-Key"),
        ),
      ),
    );
  app.get("/api/v1/reviews", (_req, res) => {
    const a = actor(res);
    admin(a);
    res.json(
      db.all(
        "SELECT * FROM reviews WHERE tenant_id=? ORDER BY created_at DESC",
        a.tenant_id,
      ),
    );
  });
  app.post("/api/v1/reviews/:id/resolve", (req, res) =>
    res.json(
      resolveReview(
        db,
        actor(res),
        req.params.id,
        req.body,
        req.get("Idempotency-Key"),
      ),
    ),
  );
  app.get("/api/v1/reports/reconciliation", (_req, res) =>
    res.json(reconciliation(db, actor(res))),
  );
  app.get("/api/v1/reports/export", (_req, res) => {
    const a = actor(res);
    admin(a);
    const rows = db.all<Record<string, string | number>>(
      "SELECT l.created_at,c.name,l.kind,l.amount,l.currency,l.reason FROM ledger l JOIN customers c ON c.id=l.customer_id WHERE l.tenant_id=? ORDER BY l.created_at",
      a.tenant_id,
    );
    const columns = [
      "created_at",
      "name",
      "kind",
      "amount",
      "currency",
      "reason",
    ];
    res
      .set("Content-Type", "text/csv; charset=utf-8")
      .set(
        "Content-Disposition",
        'attachment; filename="rewardpoint-ledger.csv"',
      )
      .send(
        [
          columns.join(","),
          ...rows.map((r) => columns.map((c) => safeCsv(r[c])).join(",")),
        ].join("\r\n"),
      );
  });
  app.post("/api/v1/leads/:id/contact-capture", (req, res) => {
    const a = actor(res);
    const l = lead(db, a, req.params.id);
    const v = z
      .object({ note: z.string().min(10).max(500) })
      .strict()
      .parse(req.body);
    const permitted =
      db.get<{ granted: number }>(
        "SELECT granted FROM consents WHERE customer_id=? AND purpose='offer' ORDER BY rowid DESC LIMIT 1",
        l.customer_id,
      )?.granted === 1;
    requireThat(permitted, 409, "Contact suppressed by customer preference");
    audit(db, a, "offer_contact.captured", l.id, v.note);
    res.json({ status: "captured", delivered: false });
  });
}
