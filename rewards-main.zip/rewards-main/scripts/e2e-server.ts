import { writeFileSync, mkdirSync } from "node:fs";
import { fixture } from "../tests/helpers.js";
const f = await fixture();
mkdirSync(".local", { recursive: true, mode: 0o700 });
writeFileSync(
  ".local/e2e.json",
  JSON.stringify({
    password: f.password,
    database: f.cfg.DATABASE_PATH,
    dir: f.dir,
  }),
  { mode: 0o600 },
);
const server = f.app.listen(4187, "127.0.0.1");
for (const s of ["SIGTERM", "SIGINT"])
  process.on(s, () =>
    server.close(() => {
      f.db.close();
      process.exit(0);
    }),
  );
