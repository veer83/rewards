export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function api<T>(
  path: string,
  body?: unknown,
  key?: string,
  signal?: AbortSignal,
): Promise<T> {
  const response = await fetch(
    path.startsWith("/api/") ? path : `/api/v1${path}`,
    {
      method: body === undefined ? "GET" : "POST",
      credentials: "same-origin",
      signal,
      headers:
        body === undefined
          ? undefined
          : {
              "Content-Type": "application/json",
              ...(key ? { "Idempotency-Key": key } : {}),
            },
      body: body === undefined ? undefined : JSON.stringify(body),
    },
  );
  const data = await response
    .json()
    .catch(() => ({ error: "The server returned an unreadable response" }));
  if (
    response.status === 401 &&
    path !== "/me" &&
    !path.startsWith("/api/auth/")
  )
    window.dispatchEvent(new Event("rewardpoint-session-expired"));
  if (!response.ok)
    throw new ApiError(
      Array.isArray(data.details)
        ? data.details
            .map(
              (d: { field: string; message: string }) =>
                `${d.field}: ${d.message}`,
            )
            .join("; ")
        : data.error || data.message || "Request failed",
      response.status,
    );
  return data as T;
}
export const money = (amount: number, currency = "CAD") =>
  new Intl.NumberFormat("en-CA", { style: "currency", currency }).format(
    amount / 100,
  );
export const date = (value: string) =>
  new Date(value).toLocaleString("en-CA", {
    dateStyle: "medium",
    timeStyle: "short",
  });
