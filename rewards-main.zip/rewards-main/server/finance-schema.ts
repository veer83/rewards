export const financeMigration = {
  version: 2,
  sql: `
CREATE TABLE sales (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, lead_id TEXT NOT NULL UNIQUE,
 reference TEXT NOT NULL, delivered_at TEXT NOT NULL, evidence TEXT NOT NULL,
 discount_amount INTEGER NOT NULL CHECK(discount_amount BETWEEN 0 AND 10000000),
 status TEXT NOT NULL CHECK(status IN ('pending','approved','cancelled','review','reversed')),
 created_at TEXT NOT NULL, verified_by TEXT, verified_at TEXT,
 FOREIGN KEY(tenant_id,lead_id) REFERENCES leads(tenant_id,id), UNIQUE(tenant_id,reference), UNIQUE(tenant_id,id)
);
CREATE TABLE grants (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, sale_id TEXT NOT NULL, customer_id TEXT NOT NULL,
 beneficiary TEXT NOT NULL CHECK(beneficiary IN ('referrer','recipient')),
 amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 10000000), currency TEXT NOT NULL CHECK(currency='CAD'),
 state TEXT NOT NULL CHECK(state IN ('issued','review','reversed')), created_at TEXT NOT NULL,
 FOREIGN KEY(tenant_id,sale_id) REFERENCES sales(tenant_id,id), FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id),
 UNIQUE(sale_id,beneficiary), UNIQUE(tenant_id,id)
);
CREATE TABLE redemptions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, customer_id TEXT NOT NULL,
 invoice TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 10000000), currency TEXT NOT NULL CHECK(currency='CAD'),
 status TEXT NOT NULL CHECK(status IN ('reserved','review','confirmed','released','reversed')),
 reason TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id), UNIQUE(tenant_id,invoice), UNIQUE(tenant_id,id)
);
CREATE TABLE allocations (
 redemption_id TEXT NOT NULL, tenant_id TEXT NOT NULL, grant_id TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0),
 PRIMARY KEY(redemption_id,grant_id), FOREIGN KEY(tenant_id,redemption_id) REFERENCES redemptions(tenant_id,id), FOREIGN KEY(tenant_id,grant_id) REFERENCES grants(tenant_id,id)
);
CREATE TABLE ledger (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, grant_id TEXT NOT NULL, customer_id TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('issue','use','restore','reverse')), amount INTEGER NOT NULL CHECK(amount!=0 AND amount BETWEEN -10000000 AND 10000000),
 currency TEXT NOT NULL CHECK(currency='CAD'), operation_id TEXT NOT NULL, source_id TEXT REFERENCES ledger(id),
 actor TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL,
 FOREIGN KEY(tenant_id,grant_id) REFERENCES grants(tenant_id,id), FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id), UNIQUE(grant_id,operation_id,kind),
 CHECK((kind IN ('issue','restore') AND amount>0) OR (kind IN ('use','reverse') AND amount<0))
);
CREATE UNIQUE INDEX one_issue_per_grant ON ledger(grant_id) WHERE kind='issue';
CREATE UNIQUE INDEX one_compensation_per_entry ON ledger(source_id) WHERE source_id IS NOT NULL;
CREATE TRIGGER ledger_no_UPDATE BEFORE UPDATE ON ledger BEGIN SELECT RAISE(ABORT,'Append-only ledger'); END;
CREATE TRIGGER ledger_no_DELETE BEFORE DELETE ON ledger BEGIN SELECT RAISE(ABORT,'Append-only ledger'); END;
CREATE TRIGGER ledger_ownership BEFORE INSERT ON ledger WHEN NOT EXISTS (SELECT 1 FROM grants WHERE id=NEW.grant_id AND tenant_id=NEW.tenant_id AND customer_id=NEW.customer_id AND currency=NEW.currency) BEGIN SELECT RAISE(ABORT,'Ledger ownership mismatch'); END;
CREATE TRIGGER grant_immutable_amount BEFORE UPDATE ON grants WHEN NEW.amount!=OLD.amount OR NEW.customer_id!=OLD.customer_id OR NEW.sale_id!=OLD.sale_id OR NEW.currency!=OLD.currency OR NEW.tenant_id!=OLD.tenant_id BEGIN SELECT RAISE(ABORT,'Immutable entitlement'); END;
`,
};
