import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";

const manifest = {
  commit: execFileSync("git", ["rev-parse", "HEAD"], {
    encoding: "utf8",
  }).trim(),
  dirty: Boolean(
    execFileSync("git", ["status", "--porcelain"], { encoding: "utf8" }).trim(),
  ),
  built_at: new Date().toISOString(),
  lock_sha256: createHash("sha256")
    .update(readFileSync("package-lock.json"))
    .digest("hex"),
};
writeFileSync("dist/release.json", JSON.stringify(manifest, null, 2));
console.log(
  `Build manifest: ${manifest.commit.slice(0, 12)}${manifest.dirty ? " (uncommitted changes)" : ""}`,
);
