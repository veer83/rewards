# Theme and dependency provenance

The current DriveOnyx portal source and its running login were inspected read-only, not treated as an approved new prototype. RewardPoint reconstructs the established split login, Inter typography, neutral cards, light/dark/system treatment, sidebar/header, controls, tables and modal behavior. Current tokens include light primary `#370d8d`, light canvas `#f9fafb`, dark canvas `#101720`, and dark accent `#c586ff`.

No Service Portal domain logic, records, credentials, repository files or bundled images were copied. The reference checkout had unrelated staged/unstaged work and was preserved. A local metadata-only checkpoint confirmed its Git HEAD, index diff, working diff and 514 source/config file hashes remained unchanged. The original process on 4173 was not restarted.

The text DriveOnyx wordmark is temporary. Exact approved logo and showroom artwork remain blocked on redistribution permission; same-theme does not mean exact asset parity is complete. Optional Inter is requested from Google Fonts as in the reference; no font binaries are redistributed. The application remains usable when those requests are blocked.

The frontend imports only Feather icons from `react-icons/fi`. MIT notices for React, React DOM, Scheduler, React Router, React Icons and Feather are retained in `public/THIRD_PARTY_NOTICES.txt`, served with the production build. Run `npm run notices` after dependency updates. Server packages retain their licence files in the installed dependency tree. No licence for proprietary branding is inferred from its presence in a private repository.

Reference evidence is kept private. Screenshots in the ignored `output/screenshots` directory were produced from this built application with synthetic records. They are not handoff screenshots and do not prove public deployment. No password-bearing screenshots or browser traces are intended for publication.
