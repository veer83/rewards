import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { fixture } from "./helpers.js";
import { Store } from "../server/db.js";

describe("independent authenticated referral vertical flow", () => {
  let f: Awaited<ReturnType<typeof fixture>>;
  beforeAll(async () => {
    f = await fixture();
  });
  afterAll(() => f?.db.close());
  it("authenticates, enrolls, accepts No Contact, persists across database reopen", async () => {
    const agent = await f.login();
    const me = await agent.get("/api/v1/me").expect(200);
    expect(me.body.tenant_id).toBe("northstar");
    const customers = await agent.get("/api/v1/customers").expect(200);
    const campaigns = await agent.get("/api/v1/campaigns").expect(200);
    const enrolment = await agent
      .post("/api/v1/enrolments")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .set("Idempotency-Key", randomUUID())
      .send({
        customer_id: customers.body[0].id,
        version_id: campaigns.body[0].version_id,
        eligibility: "Verified synthetic delivered purchase",
        invitation_consent: true,
      })
      .expect(201);
    const publicToken = enrolment.body.share_url.split("/").pop();
    await agent
      .post("/api/v1/notifications/dispatch")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({})
      .expect(200);
    const captured = f.db.get<{ captured_body: string }>(
      "SELECT captured_body FROM outbox WHERE purpose='invitation' AND status='captured'",
    )!;
    expect(captured.captured_body).toContain(enrolment.body.share_url);
    expect(captured.captured_body).toContain("CAD 500.00");
    const offer = await request(f.app)
      .get(`/api/v1/public/referrals/${publicToken}`)
      .expect(200);
    expect(JSON.stringify(offer.body)).not.toContain("customer@");
    expect(offer.body).not.toHaveProperty("customer_id");
    const body = {
      name: "Pat Test",
      email: "pat@example.invalid",
      version_id: offer.body.version_id,
      contact: "none",
      marketing: false,
      terms_accepted: true,
      privacy_acknowledged: true,
    };
    const key = randomUUID();
    const submit = () =>
      request(f.app)
        .post(`/api/v1/public/referrals/${publicToken}/acceptances`)
        .set("Origin", f.cfg.PUBLIC_ORIGIN)
        .set("Idempotency-Key", key)
        .send(body);
    const accepted = await submit().expect(201);
    expect(accepted.body.credit_available).toBe(false);
    expect((await submit().expect(201)).body).toEqual(accepted.body);
    const leads = await agent.get("/api/v1/leads").expect(200);
    expect(leads.body).toHaveLength(1);
    expect(leads.body[0].contact).toBe(0);
    const reopened = new Store(f.cfg.DATABASE_PATH);
    expect(reopened.get<{ n: number }>("SELECT count(*) n FROM leads")!.n).toBe(
      1,
    );
    reopened.close();
    expect(
      f.db.get<{ n: number }>(
        "SELECT count(*) n FROM outbox WHERE purpose='offer' AND status!='suppressed'",
      )!.n,
    ).toBe(0);
    await agent
      .post("/api/auth/sign-out")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({})
      .expect(200);
    await agent.get("/api/v1/me").expect(401);
  });
  it("denies anonymous and cross-dealer records, untrusted mutations and public signup", async () => {
    await request(f.app).get("/api/v1/customers").expect(401);
    const own = await f.login();
    const foreign = await f.login("admin@lakeside.invalid");
    const customers = await own.get("/api/v1/customers").expect(200);
    await foreign.get(`/api/v1/customers/${customers.body[0].id}`).expect(404);
    await own
      .post("/api/v1/customers")
      .set("Origin", "https://evil.invalid")
      .send({})
      .expect(403);
    await request(f.app)
      .post("/api/auth/sign-up/email")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({
        name: "Unsafe",
        email: "unsafe@demo.invalid",
        password: f.password,
      })
      .expect(400);
  });
});
