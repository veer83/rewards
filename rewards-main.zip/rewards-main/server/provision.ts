import { randomBytes } from "node:crypto";
import { z } from "zod";
import type { Express, Response } from "express";
import type { Store } from "./db.js";
import type { Config } from "./config.js";
import { createAuth, type Auth } from "./auth.js";
import { admin, requireThat, type Actor } from "./model.js";
import { customer, audit } from "./common.js";

export function provisioningRoutes(
  app: Express,
  db: Store,
  cfg: Config,
  auth: Auth,
) {
  const actor = (res: Response) => res.locals.actor as Actor;
  app.post("/api/v1/users", async (req, res) => {
    const a = actor(res);
    admin(a);
    const v = z
      .object({
        name: z.string().trim().min(2).max(100),
        email: z.email(),
        role: z.enum(["admin", "sales"]),
      })
      .strict()
      .parse(req.body);
    requireThat(
      v.email.toLowerCase().endsWith(".invalid"),
      400,
      "Only synthetic .invalid accounts are allowed",
    );
    requireThat(
      !db.get(
        "SELECT id FROM user WHERE lower(email)=?",
        v.email.toLowerCase(),
      ),
      409,
      "An account with this identity already exists; no automatic membership reassignment",
    );
    const provision = createAuth(db, cfg, true);
    const result = await provision.api.signUpEmail({
      body: {
        name: v.name,
        email: v.email.toLowerCase(),
        password: randomBytes(32).toString("hex"),
      },
    });
    db.transaction(() => {
      db.run(
        "INSERT INTO memberships VALUES (?,?,?,?,?)",
        result.user.id,
        a.tenant_id,
        v.role,
        null,
        1,
      );
      audit(db, a, "staff.provisioned", result.user.id);
    });
    await auth.api.requestPasswordReset({
      body: { email: v.email.toLowerCase(), redirectTo: "/login" },
    });
    res.status(201).json({
      id: result.user.id,
      status: "recovery_captured",
      message:
        "Local operator must deliver the single-use access instructions through the authorized synthetic testing process.",
    });
  });
  app.post("/api/v1/customers/:id/access", async (req, res) => {
    const a = actor(res);
    admin(a);
    const c = customer(db, a, req.params.id);
    const v = z
      .object({ reason: z.string().trim().min(10).max(1000) })
      .strict()
      .parse(req.body);
    requireThat(
      c.verified && !c.user_id,
      409,
      "Customer must be independently verified and not already linked to an account",
    );
    requireThat(
      c.email.endsWith(".invalid") &&
        !db.get(
          "SELECT id FROM user WHERE lower(email)=?",
          c.email.toLowerCase(),
        ),
      409,
      "Existing or non-synthetic identity requires separate operator review; it will not be automatically linked",
    );
    const provision = createAuth(db, cfg, true);
    const result = await provision.api.signUpEmail({
      body: {
        name: c.name,
        email: c.email,
        password: randomBytes(32).toString("hex"),
      },
    });
    db.transaction(() => {
      db.run(
        "INSERT INTO memberships VALUES (?,?,?,?,?)",
        result.user.id,
        a.tenant_id,
        "customer",
        c.id,
        1,
      );
      db.run("UPDATE customers SET user_id=? WHERE id=?", result.user.id, c.id);
      audit(db, a, "customer.private_access_provisioned", c.id, v.reason);
    });
    await auth.api.requestPasswordReset({
      body: { email: c.email, redirectTo: "/login" },
    });
    res.status(201).json({ status: "recovery_captured" });
  });
  app.post("/api/v1/settings/dealer", (req, res) => {
    const a = actor(res);
    admin(a);
    const v = z
      .object({
        name: z
          .string()
          .trim()
          .min(5)
          .max(100)
          .refine((n) => n.includes("Synthetic")),
        timezone: z.enum(["America/Toronto", "UTC"]),
      })
      .strict()
      .parse(req.body);
    db.transaction(() => {
      db.run(
        "UPDATE tenants SET name=?,timezone=? WHERE id=?",
        v.name,
        v.timezone,
        a.tenant_id,
      );
      audit(db, a, "dealer.updated", a.tenant_id);
    });
    res.json({ saved: true });
  });
}
