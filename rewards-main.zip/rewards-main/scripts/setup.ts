import { randomBytes } from "node:crypto";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";

if (existsSync(".env"))
  throw new Error(".env already exists; refusing to overwrite");
mkdirSync(".local", { recursive: true, mode: 0o700 });
const password = randomBytes(24).toString("base64url");
writeFileSync(
  ".env",
  `APP_ENV=demo\nPUBLIC_ORIGIN=http://127.0.0.1:4184\nPORT=4184\nDATABASE_PATH=.local/rewardpoint.sqlite\nAUTH_SECRET=${randomBytes(48).toString("base64url")}\nNOTIFICATION_MODE=capture\nLIVE_CAMPAIGNS_ENABLED=false\nRELEASE_ID=local-development\nCAPTURE_DIR=.local/captured\nSEED_PASSWORD=${password}\n`,
  { mode: 0o600 },
);
writeFileSync(
  ".local/demo-access.txt",
  `Synthetic accounts; keep this file private.\nadmin@northstar.invalid\nsales@northstar.invalid\ncustomer@northstar.invalid\nadmin@lakeside.invalid\nPassword: ${password}\n`,
  { mode: 0o600 },
);
console.log(
  "Created local configuration and .local/demo-access.txt; credentials were not printed.",
);
