import { test, expect } from "vitest";
import { copyFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Store, migrate } from "../server/db.js";
import { fixture } from "./helpers.js";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { randomUUID } from "node:crypto";
import type { Actor, Customer, Version } from "../server/model.js";
import { enroll, accept, leadActivity } from "../server/referrals.js";
import {
  approveSale,
  recordSale,
  reserve,
  redemptionAction,
  reconciliation,
} from "../server/finance.js";

test("online backup restores all histories and balances; migrations are repeatable", async () => {
  const f = await fixture();
  try {
    const a = f.db.get<Actor>(
      "SELECT m.*,u.name,u.email FROM memberships m JOIN user u ON u.id=m.user_id WHERE m.user_id=?",
      f.users["admin@northstar.invalid"],
    )!;
    const c = f.db.get<Customer>("SELECT * FROM customers LIMIT 1")!,
      v = f.db.get<Version>(
        "SELECT * FROM campaign_versions WHERE tenant_id=?",
        a.tenant_id,
      )!;
    const e = enroll(
      f.db,
      f.cfg,
      a,
      {
        customer_id: c.id,
        version_id: v.id,
        eligibility: "Verified synthetic delivered purchase",
        invitation_consent: true,
      },
      randomUUID(),
    );
    accept(
      f.db,
      e.share_url.split("/").pop()!,
      {
        name: "Restore Buyer",
        email: "restore@test.invalid",
        version_id: v.id,
        contact: "none",
        marketing: false,
        terms_accepted: true,
        privacy_acknowledged: true,
      },
      randomUUID(),
    );
    const l = f.db.get<{ id: string }>("SELECT id FROM leads LIMIT 1")!;
    leadActivity(f.db, a, l.id, {
      kind: "identity",
      note: "Independent verified buyer identity",
    });
    const s = recordSale(
      f.db,
      a,
      l.id,
      {
        reference: "BACKUP-SALE",
        delivered_at: new Date().toISOString(),
        evidence: "Delivered sale checked in isolated fixture",
        discount_amount: 50000,
      },
      randomUUID(),
    );
    approveSale(
      f.db,
      a,
      s.id,
      {
        verified: true,
        reason: "Both identities and sale independently verified",
      },
      randomUUID(),
    );
    const r = reserve(
      f.db,
      a,
      {
        customer_id: c.id,
        invoice: "BACKUP-INV",
        amount: 12345,
        reason: "Eligible synthetic service use for restoration test",
      },
      randomUUID(),
    );
    redemptionAction(
      f.db,
      a,
      r.id,
      "confirm",
      {
        reason: "Verified application to external synthetic invoice",
        external_outcome: "applied",
      },
      randomUUID(),
    );
    const expected = reconciliation(f.db, a);
    const dir = mkdtempSync(join(tmpdir(), "rewardpoint-restore-"));
    const backup = join(dir, "backup.sqlite"),
      restored = join(dir, "restored.sqlite");
    await f.db.db.backup(backup);
    copyFileSync(backup, restored);
    const copy = new Store(restored);
    migrate(copy);
    migrate(copy);
    for (const table of [
      "customers",
      "leads",
      "consents",
      "ledger",
      "audit",
      "operations",
      "receipts",
    ])
      expect(copy.get(`SELECT count(*) n FROM ${table}`)).toEqual(
        f.db.get(`SELECT count(*) n FROM ${table}`),
      );
    const result = reconciliation(copy, a);
    expect({ ...result, as_of: "" }).toEqual({ ...expected, as_of: "" });
    expect(copy.db.pragma("integrity_check", { simple: true })).toBe("ok");
    expect(copy.db.pragma("foreign_key_check")).toEqual([]);
    copy.close();
  } finally {
    f.db.close();
  }
});

test("built server restarts without reseeding; persistent sessions and leads survive", async () => {
  const f = await fixture();
  const actor = f.db.get<Actor>(
    "SELECT m.*,u.name,u.email FROM memberships m JOIN user u ON u.id=m.user_id WHERE m.user_id=?",
    f.users["admin@northstar.invalid"],
  )!;
  const customer = f.db.get<Customer>("SELECT * FROM customers LIMIT 1")!,
    version = f.db.get<Version>(
      "SELECT * FROM campaign_versions WHERE tenant_id='northstar'",
    )!;
  const invitation = enroll(
    f.db,
    f.cfg,
    actor,
    {
      customer_id: customer.id,
      version_id: version.id,
      eligibility: "Verified synthetic restart-test purchase",
      invitation_consent: true,
    },
    randomUUID(),
  );
  accept(
    f.db,
    invitation.share_url.split("/").pop()!,
    {
      name: "Restart Buyer",
      email: "restart@test.invalid",
      version_id: version.id,
      contact: "none",
      marketing: false,
      terms_accepted: true,
      privacy_acknowledged: true,
    },
    randomUUID(),
  );
  f.db.close();
  let child: ReturnType<typeof spawn> | undefined;
  async function start(release: string) {
    child = spawn(process.execPath, ["dist-server/server/index.js"], {
      env: {
        ...process.env,
        ...f.cfg,
        PORT: "4188",
        PUBLIC_ORIGIN: "http://127.0.0.1:4188",
        RELEASE_ID: release,
      },
      stdio: ["ignore", "pipe", "pipe"],
    });
    for (let i = 0; i < 100; i++) {
      if (child.exitCode !== null)
        throw new Error("RewardPoint isolated process failed to start");
      try {
        const h = await fetch("http://127.0.0.1:4188/api/health");
        if (h.ok && (await h.json()).release === release) return;
      } catch {
        /* Origin is not ready yet. */
      }
      await new Promise((r) => setTimeout(r, 50));
    }
    throw new Error("Isolated origin readiness timeout");
  }
  async function stop() {
    if (child && child.exitCode === null) {
      const exited = once(child, "exit");
      child.kill("SIGTERM");
      await exited;
    }
  }
  try {
    await start("restart-before");
    const login = await fetch("http://127.0.0.1:4188/api/auth/sign-in/email", {
      method: "POST",
      headers: {
        origin: "http://127.0.0.1:4188",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        email: "admin@northstar.invalid",
        password: f.password,
      }),
    });
    expect(login.status).toBe(200);
    const cookie = login.headers
      .getSetCookie()
      .map((c) => c.split(";")[0])
      .join("; ");
    const response = await fetch("http://127.0.0.1:4188/api/v1/customers", {
      headers: { cookie },
    });
    expect(response.status).toBe(200);
    const before = await response.json();
    const beforeLeads = await (
      await fetch("http://127.0.0.1:4188/api/v1/leads", { headers: { cookie } })
    ).json();
    expect(beforeLeads).toHaveLength(1);
    await stop();
    await start("restart-after");
    const after = await fetch("http://127.0.0.1:4188/api/v1/customers", {
      headers: { cookie },
    });
    expect(after.status).toBe(200);
    expect(await after.json()).toEqual(before);
    const afterLeads = await fetch("http://127.0.0.1:4188/api/v1/leads", {
      headers: { cookie },
    });
    expect(afterLeads.status).toBe(200);
    expect(await afterLeads.json()).toEqual(beforeLeads);
    expect(
      (
        await fetch("http://127.0.0.1:4188/customers", {
          headers: { accept: "text/html" },
        })
      ).status,
    ).toBe(200);
    expect(
      (await fetch("http://127.0.0.1:4188/assets/missing.js")).status,
    ).toBe(404);
    expect((await fetch("http://127.0.0.1:4188/api/missing")).status).toBe(404);
  } finally {
    await stop();
  }
}, 20000);
