import type { Config } from "./config.js";
import { Store, id, now } from "./db.js";
import { createAuth } from "./auth.js";
import { createCampaign, campaignAction } from "./referrals.js";
import type { Actor } from "./model.js";

export async function seed(db: Store, cfg: Config, password: string) {
  if (!["test", "demo"].includes(cfg.APP_ENV) || password.length < 14)
    throw new Error(
      "Explicit synthetic environment and strong seed password required",
    );
  if (db.get("SELECT id FROM tenants LIMIT 1"))
    throw new Error(
      "Seed requires a new, empty RewardPoint database; existing records preserved",
    );
  const auth = createAuth(db, cfg, true);
  const users: Record<string, string> = {};
  for (const [name, email] of [
    ["Jordan Lee", "admin@northstar.invalid"],
    ["Sam Rivera", "sales@northstar.invalid"],
    ["Alex Morgan", "customer@northstar.invalid"],
    ["Taylor Chen", "admin@lakeside.invalid"],
  ]) {
    const result = await auth.api.signUpEmail({
      body: { name, email, password },
    });
    users[email] = result.user.id;
  }
  db.transaction(() => {
    db.run(
      "INSERT INTO tenants VALUES (?,?,?,?)",
      "northstar",
      "Northstar Motors (Synthetic)",
      "CAD",
      "America/Toronto",
    );
    db.run(
      "INSERT INTO tenants VALUES (?,?,?,?)",
      "lakeside",
      "Lakeside Motors (Synthetic)",
      "CAD",
      "America/Toronto",
    );
    const cid = id();
    db.run(
      "INSERT INTO customers VALUES (?,?,?,?,?,?,?,?,?)",
      cid,
      "northstar",
      "Alex Morgan",
      "customer@northstar.invalid",
      "SYNTHETIC-PURCHASE-001",
      1,
      users["admin@northstar.invalid"],
      users["customer@northstar.invalid"],
      now(),
    );
    for (const [email, uid] of Object.entries(users))
      db.run(
        "INSERT INTO memberships VALUES (?,?,?,?,?)",
        uid,
        email.includes("lakeside") ? "lakeside" : "northstar",
        email.startsWith("customer")
          ? "customer"
          : email.startsWith("sales")
            ? "sales"
            : "admin",
        email.startsWith("customer") ? cid : null,
        1,
      );
    for (const tenant of ["northstar", "lakeside"]) {
      const actor = {
        user_id: users[`admin@${tenant}.invalid`],
        tenant_id: tenant,
        role: "admin",
      } as Actor;
      const c = createCampaign(db, actor, {
        name: "A good drive deserves another",
        referrer_amount: 50000,
        discount_amount: 50000,
        recipient_amount: 50000,
        terms:
          "Synthetic demo only. No monetary value. D01-D12 are unapproved assumptions. Credits require a delivered, verified vehicle sale. Same-dealer service usage only. No obligation to purchase. No automatic credit expiry.",
        starts_at: new Date(Date.now() - 86400000).toISOString(),
        ends_at: new Date(Date.now() + 86400000 * 90).toISOString(),
        purchase_by: new Date(Date.now() + 86400000 * 180).toISOString(),
      });
      campaignAction(db, actor, c.id, "publish");
    }
  });
  return users;
}
