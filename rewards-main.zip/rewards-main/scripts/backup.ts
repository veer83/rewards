import { mkdirSync, existsSync, chmodSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { config } from "../server/config.js";
import { Store } from "../server/db.js";

const cfg = config();
const target = resolve(
  process.argv[2] ||
    `.local/backups/rewardpoint-${new Date().toISOString().replaceAll(":", "-")}.sqlite`,
);
if (existsSync(target))
  throw new Error("Backup destination already exists; refusing to overwrite");
mkdirSync(dirname(target), { recursive: true, mode: 0o700 });
const db = new Store(cfg.DATABASE_PATH);
await db.db.backup(target);
chmodSync(target, 0o600);
const copy = new Store(target);
const check = copy.db.pragma("integrity_check", { simple: true });
if (check !== "ok") throw new Error("Backup integrity failed");
copy.close();
db.close();
console.log(`Verified RewardPoint backup written to ${target}`);
