import express, {
  type Request,
  type Response,
  type NextFunction,
} from "express";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { toNodeHandler, fromNodeHeaders } from "better-auth/node";
import { resolve } from "node:path";
import { existsSync, readFileSync } from "node:fs";
import { z } from "zod";
import type { Config } from "./config.js";
import type { Store } from "./db.js";
import type { Auth } from "./auth.js";
import {
  admin,
  DomainError,
  requireThat,
  type Actor,
  type Customer,
  type Enrollment,
} from "./model.js";
import {
  appendConsent,
  audit,
  customer,
  decrypt,
  dispatch,
  lead,
  token,
  encrypt,
} from "./common.js";
import { hash, now } from "./db.js";
import {
  accept,
  campaignAction,
  createCampaign,
  createCustomer,
  enroll,
  leadActivity,
  publicOffer,
} from "./referrals.js";
import { financialRoutes } from "./finance-routes.js";
import { provisioningRoutes } from "./provision.js";

export function createApp(db: Store, auth: Auth, cfg: Config) {
  const app = express();
  const build = existsSync("dist/release.json")
    ? JSON.parse(readFileSync("dist/release.json", "utf8"))
    : null;
  app.disable("x-powered-by");
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          imgSrc: ["'self'", "data:"],
          styleSrc: ["'self'", "https://fonts.googleapis.com"],
          scriptSrc: ["'self'"],
          fontSrc: ["'self'", "https://fonts.gstatic.com"],
          connectSrc: ["'self'"],
          upgradeInsecureRequests: cfg.PUBLIC_ORIGIN.startsWith("https:")
            ? []
            : null,
        },
      },
      referrerPolicy: { policy: "no-referrer" },
    }),
  );
  app.use("/api", (_req, res, next) => {
    res.set("Cache-Control", "no-store");
    next();
  });
  app.use("/api", (req, res, next) => {
    if (
      !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
      req.headers.origin !== cfg.PUBLIC_ORIGIN
    )
      return res.status(403).json({ error: "Untrusted request origin" });
    next();
  });
  app.use(
    "/api",
    rateLimit({
      windowMs: 60000,
      limit: 300,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
  );
  app.all("/api/auth/*splat", toNodeHandler(auth));
  app.use(express.json({ limit: "32kb" }));
  app.get("/api/health", (_req, res) =>
    res.json({ ok: true, release: cfg.RELEASE_ID, demo: true, build }),
  );
  app.get("/api/ready", (_req, res) => {
    requireThat(
      db.get("SELECT version FROM schema_migrations WHERE version=3"),
      503,
      "Database migration unavailable",
    );
    res.json({ ready: true });
  });
  app.use(
    "/api/v1/public",
    rateLimit({
      windowMs: 60000,
      limit: 30,
      standardHeaders: "draft-8",
      legacyHeaders: false,
    }),
  );
  app.get("/api/v1/public/referrals/:token", (req, res) =>
    res.json(publicOffer(db, req.params.token)),
  );
  app.get("/api/v1/public/receipts/:token", (req, res) => {
    requireThat(
      /^[A-Za-z0-9_-]{43}$/.test(req.params.token) &&
        db.get(
          "SELECT created_at FROM receipts WHERE token_hash=?",
          hash(req.params.token),
        ),
      404,
      "Receipt unavailable",
    );
    res.json({ status: "RECEIVED", credit_available: false });
  });
  app.post("/api/v1/public/referrals/:token/acceptances", (req, res) =>
    res
      .status(201)
      .json(accept(db, req.params.token, req.body, req.get("Idempotency-Key"))),
  );
  app.use("/api/v1", async (req, res, next) => {
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });
    requireThat(session, 401, "Sign in to continue");
    const a = db.get<Actor>(
      "SELECT m.*, u.name, u.email FROM memberships m JOIN user u ON u.id=m.user_id WHERE m.user_id=? AND m.active=1",
      session.user.id,
    );
    requireThat(a, 403, "No active RewardPoint membership");
    res.locals.actor = a;
    next();
  });
  const actor = (res: Response) => res.locals.actor as Actor;
  app.get("/api/v1/me", (_req, res) => {
    const a = actor(res);
    res.json({
      ...a,
      dealer: db.get("SELECT * FROM tenants WHERE id=?", a.tenant_id),
      demo: true,
      release: cfg.RELEASE_ID,
    });
  });
  app.get("/api/v1/customers", (_req, res) => {
    const a = actor(res);
    res.json(
      db.all<Customer>(
        `SELECT * FROM customers WHERE tenant_id=? ${a.role === "customer" ? "AND id=?" : a.role === "sales" ? "AND owner_id=?" : ""} ORDER BY created_at DESC`,
        a.tenant_id,
        ...(a.role === "admin"
          ? []
          : [a.role === "sales" ? a.user_id : a.customer_id]),
      ),
    );
  });
  app.post("/api/v1/customers", (req, res) =>
    res.status(201).json(createCustomer(db, actor(res), req.body)),
  );
  app.get("/api/v1/customers/:id", (req, res) =>
    res.json(customer(db, actor(res), req.params.id)),
  );
  app.get("/api/v1/customers/:id/history", (req, res) => {
    const a = actor(res);
    const c = customer(db, a, req.params.id);
    res.json({
      consents: db.all(
        "SELECT * FROM consents WHERE tenant_id=? AND customer_id=? ORDER BY rowid DESC",
        a.tenant_id,
        c.id,
      ),
      invitations: db.all(
        "SELECT id,purpose,status,attempts,created_at FROM outbox WHERE tenant_id=? AND customer_id=? ORDER BY created_at DESC",
        a.tenant_id,
        c.id,
      ),
      enrollments: db.all(
        "SELECT e.id,e.created_at,e.revoked,p.name campaign,v.version FROM enrolments e JOIN campaign_versions v ON v.id=e.version_id JOIN campaigns p ON p.id=v.campaign_id WHERE e.tenant_id=? AND e.customer_id=?",
        a.tenant_id,
        c.id,
      ),
    });
  });
  app.post("/api/v1/customers/:id/consents", (req, res) => {
    const a = actor(res);
    customer(db, a, req.params.id);
    const v = z
      .object({
        purpose: z.enum(["offer", "marketing", "invitation"]),
        granted: z.boolean(),
        evidence: z.string().trim().min(10).max(1000),
      })
      .strict()
      .parse(req.body);
    requireThat(
      a.role === "customer" || !v.granted,
      403,
      "Staff may record withdrawal, but cannot opt a customer into contact",
    );
    db.transaction(() => {
      appendConsent(
        db,
        a.tenant_id,
        req.params.id,
        v.purpose,
        v.granted,
        a.user_id,
        "demo-consent-v1",
      );
      audit(db, a, "consent.changed", req.params.id, v.evidence);
    });
    res.json({ saved: true });
  });
  app.get("/api/v1/campaigns", (_req, res) => {
    const a = actor(res);
    requireThat(a.role !== "customer", 403, "Staff access required");
    res.json(
      db.all(
        "SELECT c.*, v.id version_id, v.version, v.referrer_amount, v.recipient_amount, v.discount_amount, v.currency, v.terms, v.starts_at, v.ends_at, v.purchase_by, v.published_at FROM campaigns c JOIN campaign_versions v ON v.campaign_id=c.id WHERE c.tenant_id=? ORDER BY c.created_at DESC,v.version DESC",
        a.tenant_id,
      ),
    );
  });
  app.post("/api/v1/campaigns", (req, res) =>
    res.status(201).json(createCampaign(db, actor(res), req.body)),
  );
  app.post("/api/v1/campaigns/:id/versions", (req, res) =>
    res
      .status(201)
      .json(createCampaign(db, actor(res), req.body, req.params.id)),
  );
  for (const action of ["publish", "pause"])
    app.post(`/api/v1/campaigns/:id/${action}`, (req, res) =>
      res.json(campaignAction(db, actor(res), req.params.id, action)),
    );
  app.post("/api/v1/enrolments", (req, res) =>
    res
      .status(201)
      .json(enroll(db, cfg, actor(res), req.body, req.get("Idempotency-Key"))),
  );
  app.get("/api/v1/referrals", (_req, res) => {
    const a = actor(res);
    const rows = db.all<
      Enrollment & { name: string; campaign: string; accepted: number }
    >(
      `SELECT e.*, c.name, p.name campaign, (SELECT count(*) FROM leads l WHERE l.enrolment_id=e.id) accepted FROM enrolments e JOIN customers c ON c.id=e.customer_id JOIN campaign_versions v ON v.id=e.version_id JOIN campaigns p ON p.id=v.campaign_id WHERE e.tenant_id=? ${a.role === "customer" ? "AND e.customer_id=?" : a.role === "sales" ? "AND c.owner_id=?" : ""}`,
      a.tenant_id,
      ...(a.role === "admin"
        ? []
        : [a.role === "customer" ? a.customer_id : a.user_id]),
    );
    res.json(
      rows.map(({ token_hash: _hash, token_cipher, ...r }) => ({
        ...r,
        share_url: `${cfg.PUBLIC_ORIGIN}/r/${decrypt(token_cipher, cfg.AUTH_SECRET)}`,
      })),
    );
  });
  app.post("/api/v1/enrolments/:id/:action", (req, res) => {
    const a = actor(res);
    const e = db.get<Enrollment>(
      "SELECT * FROM enrolments WHERE id=? AND tenant_id=?",
      req.params.id,
      a.tenant_id,
    );
    requireThat(e, 404, "Enrollment unavailable");
    customer(db, a, e.customer_id);
    requireThat(
      ["rotate", "revoke", "invite"].includes(req.params.action),
      400,
      "Unknown action",
    );
    db.transaction(() => {
      if (req.params.action === "rotate") {
        const t = token();
        db.run(
          "UPDATE enrolments SET token_hash=?,token_cipher=?,revoked=0 WHERE id=?",
          hash(t),
          encrypt(t, cfg.AUTH_SECRET),
          e.id,
        );
      }
      if (req.params.action === "revoke")
        db.run("UPDATE enrolments SET revoked=1 WHERE id=?", e.id);
      if (req.params.action === "invite") {
        requireThat(!e.revoked, 409, "Link revoked");
        const last = db.get<{ created_at: string }>(
          "SELECT created_at FROM outbox WHERE customer_id=? AND purpose='invitation' ORDER BY created_at DESC LIMIT 1",
          e.customer_id,
        );
        requireThat(
          !last || Date.parse(last.created_at) < Date.now() - 60000,
          429,
          "Wait one minute before another invitation",
        );
        // The enqueue and dispatch paths independently recheck current consent.
        appendInvitation(db, a, e);
      }
      audit(db, a, `enrollment.${req.params.action}`, e.id);
    });
    res.json({ saved: true });
  });
  app.get("/api/v1/leads", (_req, res) => {
    const a = actor(res);
    requireThat(a.role !== "customer", 403, "Staff access required");
    res.json(
      db.all(
        `SELECT l.*, c.name, c.email, c.verified, r.name referrer, p.name campaign,
      COALESCE((SELECT granted FROM consents WHERE customer_id=c.id AND purpose='offer' ORDER BY rowid DESC LIMIT 1),0) contact,
      COALESCE((SELECT granted FROM consents WHERE customer_id=c.id AND purpose='marketing' ORDER BY rowid DESC LIMIT 1),0) marketing
      FROM leads l JOIN customers c ON c.id=l.customer_id JOIN enrolments e ON e.id=l.enrolment_id JOIN customers r ON r.id=e.customer_id JOIN campaign_versions v ON v.id=e.version_id JOIN campaigns p ON p.id=v.campaign_id WHERE l.tenant_id=? ${a.role === "sales" ? "AND l.assigned_to=?" : ""} ORDER BY l.created_at DESC`,
        a.tenant_id,
        ...(a.role === "sales" ? [a.user_id] : []),
      ),
    );
  });
  app.get("/api/v1/leads/:id", (req, res) => {
    const a = actor(res);
    const l = lead(db, a, req.params.id);
    res.json({
      ...l,
      customer: customer(db, a, l.customer_id),
      activities: db.all(
        "SELECT * FROM activities WHERE lead_id=? ORDER BY created_at DESC",
        l.id,
      ),
      consents: db.all(
        "SELECT * FROM consents WHERE customer_id=? ORDER BY rowid DESC",
        l.customer_id,
      ),
      offer: db.get(
        "SELECT v.* FROM campaign_versions v JOIN enrolments e ON e.version_id=v.id WHERE e.id=?",
        l.enrolment_id,
      ),
    });
  });
  app.post("/api/v1/leads/:id/activities", (req, res) =>
    res.json(leadActivity(db, actor(res), req.params.id, req.body)),
  );
  app.get("/api/v1/settings", (_req, res) => {
    const a = actor(res);
    admin(a);
    res.json({
      dealer: db.get("SELECT * FROM tenants WHERE id=?", a.tenant_id),
      users: db.all(
        "SELECT m.*,u.name,u.email FROM memberships m JOIN user u ON u.id=m.user_id WHERE m.tenant_id=?",
        a.tenant_id,
      ),
      audit: db.all(
        "SELECT * FROM audit WHERE tenant_id=? ORDER BY rowid DESC LIMIT 200",
        a.tenant_id,
      ),
      outbox: db.all(
        "SELECT * FROM outbox WHERE tenant_id=? ORDER BY created_at DESC LIMIT 100",
        a.tenant_id,
      ),
      notification_mode: "capture",
      assumptions: "D01-D12: unapproved demo assumptions",
    });
  });
  app.post("/api/v1/notifications/dispatch", (_req, res) => {
    const a = actor(res);
    admin(a);
    res.json(dispatch(db, a.tenant_id, cfg));
  });
  app.post("/api/v1/users/:id/access", (req, res) => {
    const a = actor(res);
    admin(a);
    requireThat(
      req.params.id !== a.user_id,
      409,
      "You cannot change your own access",
    );
    const v = z
      .object({ active: z.boolean(), role: z.enum(["admin", "sales"]) })
      .strict()
      .parse(req.body);
    requireThat(
      db.get(
        "SELECT user_id FROM memberships WHERE user_id=? AND tenant_id=? AND role!='customer'",
        req.params.id,
        a.tenant_id,
      ),
      404,
      "Staff unavailable",
    );
    db.transaction(() => {
      db.run(
        "UPDATE memberships SET active=?,role=? WHERE user_id=?",
        Number(v.active),
        v.role,
        req.params.id,
      );
      db.run("DELETE FROM session WHERE userId=?", req.params.id);
      audit(db, a, "staff.access_changed", req.params.id);
    });
    res.json({ saved: true });
  });
  financialRoutes(app, db);
  provisioningRoutes(app, db, cfg, auth);
  return {
    app,
    finish: () => {
      app.use("/api", (_req, res) =>
        res.status(404).json({ error: "API route not found" }),
      );
      const dist = resolve("dist");
      if (existsSync(dist)) {
        app.use(
          express.static(dist, {
            index: false,
            setHeaders: (res, path) =>
              res.setHeader(
                "Cache-Control",
                path.includes("/assets/")
                  ? "public, max-age=31536000, immutable"
                  : "no-cache",
              ),
          }),
        );
        app.get("/{*path}", (req, res) => {
          if (req.path.includes(".") || !req.accepts("html"))
            return res.sendStatus(404);
          res
            .set("Cache-Control", "no-cache")
            .sendFile("index.html", { root: dist });
        });
      }
      app.use(
        (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
          if (err instanceof DomainError)
            return res.status(err.status).json({ error: err.message });
          if (err instanceof z.ZodError)
            return res.status(400).json({
              error: "Check the form fields",
              details: err.issues.map((i) => ({
                field: i.path.join("."),
                message: i.message,
              })),
            });
          if (err instanceof Error && err.message.includes("UNIQUE constraint"))
            return res.status(409).json({
              error:
                "This business event already exists. Refresh to review it.",
            });
          console.error(
            "Request failed",
            err instanceof Error ? err.name : "unknown",
          );
          res.status(500).json({
            error:
              "The request could not be completed. Retry with the same operation key.",
          });
        },
      );
      return app;
    },
  };
}
import { queue } from "./common.js";
function appendInvitation(db: Store, a: Actor, e: Enrollment) {
  queue(
    db,
    a.tenant_id,
    e.customer_id,
    "invitation",
    `invite:${e.id}:${now()}`,
  );
}
