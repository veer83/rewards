import { copyFileSync, existsSync, mkdirSync, chmodSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { Store } from "../server/db.js";

const [sourceArg, targetArg] = process.argv.slice(2);
if (!sourceArg || !targetArg)
  throw new Error("Usage: npm run restore -- SOURCE_BACKUP NEW_DATABASE_PATH");
const source = resolve(sourceArg),
  target = resolve(targetArg);
if (!existsSync(source) || existsSync(target) || existsSync(`${target}-wal`))
  throw new Error(
    "Source must exist and destination must be new; no active database can be overwritten",
  );
mkdirSync(dirname(target), { recursive: true, mode: 0o700 });
copyFileSync(source, target);
chmodSync(target, 0o600);
const db = new Store(target);
if (
  db.db.pragma("integrity_check", { simple: true }) !== "ok" ||
  (db.db.pragma("foreign_key_check") as unknown[]).length
)
  throw new Error("Restored database integrity failed");
db.close();
console.log(
  "Restored to a separate database. Point only an isolated RewardPoint process at it for verification.",
);
