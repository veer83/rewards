import { beforeAll, afterAll, describe, expect, it } from "vitest";
import { randomUUID } from "node:crypto";
import { Worker } from "node:worker_threads";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";
import { fixture } from "./helpers.js";
import {
  accept,
  enroll,
  leadActivity,
  createCustomer,
} from "../server/referrals.js";
import {
  approveSale,
  cancelSale,
  grants,
  reconciliation,
  recordSale,
  redemptionAction,
  reserve,
  resolveReview,
} from "../server/finance.js";
import { appendConsent, dispatch } from "../server/common.js";
import { safeCsv } from "../server/finance-routes.js";
import { config } from "../server/config.js";
import type { Actor, Customer, Version } from "../server/model.js";

describe("transactional credit and isolation controls", () => {
  let f: Awaited<ReturnType<typeof fixture>>, a: Actor;
  let seq = 0;
  beforeAll(async () => {
    f = await fixture();
    a = f.db.get<Actor>(
      "SELECT m.*,u.name,u.email FROM memberships m JOIN user u ON u.id=m.user_id WHERE m.user_id=?",
      f.users["admin@northstar.invalid"],
    )!;
  });
  afterAll(() => f?.db.close());
  async function journey() {
    const c = createCustomer(f.db, a, {
      name: `Referrer ${++seq}`,
      email: `referrer${seq}@test.invalid`,
    });
    f.db.run("UPDATE customers SET verified=1 WHERE id=?", c.id);
    const version = f.db.get<Version>(
      "SELECT * FROM campaign_versions WHERE tenant_id=?",
      a.tenant_id,
    )!;
    const e = enroll(
      f.db,
      f.cfg,
      a,
      {
        customer_id: c.id,
        version_id: version.id,
        eligibility: "Synthetic purchaser evidence confirmed",
        invitation_consent: true,
      },
      randomUUID(),
    );
    const t = e.share_url.split("/").pop()!;
    accept(
      f.db,
      t,
      {
        name: `Recipient ${seq}`,
        email: `recipient${seq}@test.invalid`,
        version_id: version.id,
        contact: "none",
        marketing: false,
        terms_accepted: true,
        privacy_acknowledged: true,
      },
      randomUUID(),
    );
    const l = f.db.get<{ id: string; customer_id: string }>(
      "SELECT * FROM leads WHERE email_normalized=?",
      `recipient${seq}@test.invalid`,
    )!;
    leadActivity(f.db, a, l.id, {
      kind: "identity",
      note: "Identity and synthetic sale recipient independently verified",
    });
    const s = recordSale(
      f.db,
      a,
      l.id,
      {
        reference: `SALE-${seq}`,
        delivered_at: new Date().toISOString(),
        evidence: "Delivered vehicle verified against synthetic sales record",
        discount_amount: 50000,
      },
      randomUUID(),
    );
    return { c, l, s, t, version };
  }
  it("acceptance and pending evidence do not create spendable credit", async () => {
    const j = await journey();
    expect(grants(f.db, a.tenant_id, j.c.id)).toHaveLength(0);
    expect(reconciliation(f.db, a).pending).toBeGreaterThanOrEqual(100000);
  });
  it("issues the exact two-beneficiary bundle once across different retry keys", async () => {
    const j = await journey();
    for (let i = 0; i < 3; i++)
      approveSale(
        f.db,
        a,
        j.s.id,
        {
          verified: true,
          reason: "Delivered sale and both beneficiaries verified",
        },
        randomUUID(),
      );
    const g = grants(f.db, a.tenant_id).filter((g) => g.sale_id === j.s.id);
    expect(g.map((g) => g.amount)).toEqual([50000, 50000]);
    expect(g.reduce((s, g) => s + g.balance, 0)).toBe(100000);
  });
  it("binds idempotency keys to the payload", async () => {
    const j = await journey(),
      key = randomUUID();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Original approval attestation" },
      key,
    );
    expect(() =>
      approveSale(
        f.db,
        a,
        j.s.id,
        { verified: true, reason: "Different approval attestation" },
        key,
      ),
    ).toThrow("different request");
  });
  it("rolls back the entire bundle, audit and outbox if second beneficiary fails", async () => {
    const j = await journey();
    const before = f.db.get<{ n: number }>("SELECT count(*) n FROM audit")!.n;
    f.db.db.exec(
      "CREATE TEMP TRIGGER fail_recipient BEFORE INSERT ON grants WHEN NEW.beneficiary='recipient' BEGIN SELECT RAISE(ABORT,'test atomicity fault'); END;",
    );
    expect(() =>
      approveSale(
        f.db,
        a,
        j.s.id,
        { verified: true, reason: "Atomicity fault injection approval" },
        randomUUID(),
      ),
    ).toThrow("test atomicity fault");
    f.db.db.exec("DROP TRIGGER fail_recipient");
    expect(
      grants(f.db, a.tenant_id).filter((g) => g.sale_id === j.s.id),
    ).toHaveLength(0);
    expect(f.db.get<{ n: number }>("SELECT count(*) n FROM audit")!.n).toBe(
      before,
    );
  });
  it("rejects unverified identities before posting", async () => {
    const j = await journey();
    f.db.run("UPDATE customers SET verified=0 WHERE id=?", j.l.customer_id);
    expect(() =>
      approveSale(
        f.db,
        a,
        j.s.id,
        { verified: true, reason: "Attempt without verified identity" },
        randomUUID(),
      ),
    ).toThrow("Verify both");
  });
  it("keeps partial usage, holds, release and uncertain recovery exact", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    const r = reserve(
      f.db,
      a,
      {
        customer_id: j.c.id,
        invoice: `INV-PARTIAL-${seq}`,
        amount: 12500,
        reason: "Synthetic service invoice identity checked",
      },
      randomUUID(),
    );
    expect(grants(f.db, a.tenant_id, j.c.id)[0].available).toBe(37500);
    redemptionAction(
      f.db,
      a,
      r.id,
      "review",
      {
        reason: "External system response is uncertain",
        external_outcome: "uncertain",
      },
      randomUUID(),
    );
    expect(() =>
      redemptionAction(
        f.db,
        a,
        r.id,
        "release",
        {
          reason: "No confirmed external outcome evidence",
          external_outcome: "uncertain",
        },
        randomUUID(),
      ),
    ).toThrow("matching external outcome");
    redemptionAction(
      f.db,
      a,
      r.id,
      "confirm",
      {
        reason: "Checked external invoice and credit applied",
        external_outcome: "applied",
      },
      randomUUID(),
    );
    redemptionAction(
      f.db,
      a,
      r.id,
      "confirm",
      {
        reason: "Checked external invoice and credit applied",
        external_outcome: "applied",
      },
      randomUUID(),
    );
    expect(grants(f.db, a.tenant_id, j.c.id)[0]).toMatchObject({
      balance: 37500,
      held: 0,
      available: 37500,
    });
    expect(reconciliation(f.db, a).balanced).toBe(true);
  });
  it("cannot reserve zero, fractional or more than available credit", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    for (const amount of [0, 1.5, 50001])
      expect(() =>
        reserve(
          f.db,
          a,
          {
            customer_id: j.c.id,
            invoice: `INV-BAD-${amount}`,
            amount,
            reason: "Synthetic invalid reservation attempt",
          },
          randomUUID(),
        ),
      ).toThrow();
  });
  it("groups multiple grants into one invoice and prevents duplicate invoices", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    const secondEmail = `second-${++seq}@test.invalid`;
    accept(
      f.db,
      j.t,
      {
        name: "Second recipient",
        email: secondEmail,
        version_id: j.version.id,
        contact: "none",
        marketing: false,
        terms_accepted: true,
        privacy_acknowledged: true,
      },
      randomUUID(),
    );
    const secondLead = f.db.get<{ id: string }>(
      "SELECT id FROM leads WHERE email_normalized=?",
      secondEmail,
    )!;
    leadActivity(f.db, a, secondLead.id, {
      kind: "identity",
      note: "Second buyer identity independently verified",
    });
    const secondSale = recordSale(
      f.db,
      a,
      secondLead.id,
      {
        reference: `SALE-MULTI-${seq}`,
        delivered_at: new Date().toISOString(),
        evidence: "Second delivered vehicle sale independently verified",
        discount_amount: 50000,
      },
      randomUUID(),
    );
    approveSale(
      f.db,
      a,
      secondSale.id,
      { verified: true, reason: "Second eligible delivered sale" },
      randomUUID(),
    );
    const body = {
      customer_id: j.c.id,
      invoice: `INV-MULTI-${seq}`,
      amount: 70000,
      reason: "Multi grant synthetic service invoice",
    };
    const r = reserve(f.db, a, body, randomUUID());
    expect(
      f.db.all("SELECT * FROM allocations WHERE redemption_id=?", r.id),
    ).toHaveLength(2);
    expect(() =>
      reserve(f.db, a, { ...body, amount: 1000 }, randomUUID()),
    ).toThrow();
    redemptionAction(
      f.db,
      a,
      r.id,
      "release",
      {
        reason: "Verified benefit never applied externally",
        external_outcome: "not_applied",
      },
      randomUUID(),
    );
    expect(
      grants(f.db, a.tenant_id, j.c.id).reduce((s, g) => s + g.available, 0),
    ).toBe(100000);
  });
  it("restores a voided invoice through linked entries once", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    const r = reserve(
      f.db,
      a,
      {
        customer_id: j.c.id,
        invoice: `INV-VOID-${seq}`,
        amount: 10000,
        reason: "Synthetic invoice usage before void",
      },
      randomUUID(),
    );
    redemptionAction(
      f.db,
      a,
      r.id,
      "confirm",
      {
        reason: "External invoice applied the discount",
        external_outcome: "applied",
      },
      randomUUID(),
    );
    for (let i = 0; i < 2; i++)
      redemptionAction(
        f.db,
        a,
        r.id,
        "reverse",
        {
          reason: "External invoice voided and usage undone",
          external_outcome: "invoice_voided",
        },
        randomUUID(),
      );
    expect(grants(f.db, a.tenant_id, j.c.id)[0].balance).toBe(50000);
    expect(reconciliation(f.db, a).balanced).toBe(true);
  });
  it("reverses unspent credit with linked immutable compensation", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    const r = cancelSale(
      f.db,
      a,
      j.s.id,
      { reason: "Synthetic sale cancellation verified" },
      randomUUID(),
    );
    expect(r.status).toBe("reversed");
    expect(grants(f.db, a.tenant_id, j.c.id)[0].available).toBe(0);
    expect(() => f.db.run("UPDATE ledger SET amount=1")).toThrow("Append-only");
    expect(() => f.db.run("DELETE FROM ledger")).toThrow("Append-only");
  });
  it("freezes used-sale credit and requires an explicit reviewed resolution", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    const r = reserve(
      f.db,
      a,
      {
        customer_id: j.c.id,
        invoice: `INV-USED-${seq}`,
        amount: 2000,
        reason: "Synthetic invoice pending usage",
      },
      randomUUID(),
    );
    redemptionAction(
      f.db,
      a,
      r.id,
      "confirm",
      {
        reason: "Verified external application of credit",
        external_outcome: "applied",
      },
      randomUUID(),
    );
    expect(
      cancelSale(
        f.db,
        a,
        j.s.id,
        { reason: "Cancelled sale after partial credit use" },
        randomUUID(),
      ).status,
    ).toBe("review");
    expect(grants(f.db, a.tenant_id, j.c.id)[0]).toMatchObject({
      available: 0,
      balance: 48000,
      state: "review",
    });
    expect(() =>
      redemptionAction(
        f.db,
        a,
        r.id,
        "reverse",
        {
          reason: "Attempt restoration after source cancellation",
          external_outcome: "invoice_voided",
        },
        randomUUID(),
      ),
    ).toThrow("Source sale");
    const review = f.db.get<{ id: string }>(
      "SELECT id FROM reviews WHERE object_id=?",
      j.s.id,
    )!;
    expect(() =>
      resolveReview(
        f.db,
        a,
        review.id,
        {
          outcome: "confirm_cancellation",
          reason: "Attempt cancellation while used credit remains",
        },
        randomUUID(),
      ),
    ).toThrow("Used or held");
    resolveReview(
      f.db,
      a,
      review.id,
      {
        outcome: "uphold_sale",
        reason: "Investigated and confirmed original sale is valid",
      },
      randomUUID(),
    );
    expect(grants(f.db, a.tenant_id, j.c.id)[0].available).toBe(48000);
  });
  it("checks suppression again at dispatch after an invitation was queued", async () => {
    const j = await journey();
    appendConsent(
      f.db,
      a.tenant_id,
      j.c.id,
      "invitation",
      false,
      "customer-withdrawal",
      "demo-consent-v1",
    );
    dispatch(f.db, a.tenant_id);
    expect(
      f.db.get<{ status: string }>(
        "SELECT status FROM outbox WHERE customer_id=?",
        j.c.id,
      )!.status,
    ).toBe("suppressed");
  });
  it("rejects cross-tenant and sales-role financial requests at the server", async () => {
    const j = await journey();
    const other = await f.login("admin@lakeside.invalid"),
      sales = await f.login("sales@northstar.invalid");
    for (const [agent, status] of [
      [other, 404],
      [sales, 403],
    ] as const)
      await agent
        .post(`/api/v1/sales/${j.s.id}/approve`)
        .set("Origin", f.cfg.PUBLIC_ORIGIN)
        .set("Idempotency-Key", randomUUID())
        .send({ verified: true, reason: "Unauthorized approval test" })
        .expect(status);
  });
  it("scopes customer wallet data to ownership and rejects public links as credentials", async () => {
    const agent = await f.login("customer@northstar.invalid");
    const foreign = f.db.get<Customer>(
      "SELECT * FROM customers WHERE email LIKE 'recipient%' LIMIT 1",
    )!;
    await agent.get(`/api/v1/customers/${foreign.id}/credit`).expect(404);
    const own = await agent.get("/api/v1/rewards/grants").expect(200);
    expect(
      own.body.every(
        (g: { customer_id: string }) =>
          g.customer_id ===
          f.db.get<{ customer_id: string }>(
            "SELECT customer_id FROM memberships WHERE user_id=?",
            f.users["customer@northstar.invalid"],
          )!.customer_id,
      ),
    ).toBe(true);
  });
  it("rejects mutation of published terms and formula-like CSV cells", () => {
    expect(() =>
      f.db.run("UPDATE campaign_versions SET referrer_amount=1"),
    ).toThrow("immutable");
    for (const s of ["=SUM(1)", " +1", "-2", "@x", "\tformula"])
      expect(safeCsv(s)).toMatch(/^"'/);
  });
  it("fails closed on missing or live configuration", () => {
    expect(() => config({})).toThrow("Invalid configuration");
    expect(() =>
      config({ ...f.cfg, PORT: "4187", APP_ENV: "production" }),
    ).toThrow("Invalid configuration");
  });
  it("serializes competing approvals across independent database connections", async () => {
    const j = await journey();
    const results = await race("approve", j.s.id, {});
    expect(results.filter((r) => r.ok)).toHaveLength(2);
    expect(
      grants(f.db, a.tenant_id).filter((g) => g.sale_id === j.s.id),
    ).toHaveLength(2);
  });
  it("serializes simultaneous reservations across independent database connections", async () => {
    const j = await journey();
    approveSale(
      f.db,
      a,
      j.s.id,
      { verified: true, reason: "Confirmed eligible delivered sale" },
      randomUUID(),
    );
    const results = await race("reserve", j.c.id, { amount: 40000 });
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok)).toHaveLength(1);
    expect(grants(f.db, a.tenant_id, j.c.id)[0].available).toBe(10000);
    expect(reconciliation(f.db, a).balanced).toBe(true);
  });
  async function race(
    action: string,
    object: string,
    body: Record<string, unknown>,
  ) {
    const barrier = new SharedArrayBuffer(4);
    const code = `const {parentPort,workerData:d}=require('node:worker_threads'); (async()=>{const {Store}=await import(d.dbModule);const m=await import(d.financeModule);const db=new Store(d.path);const barrier=new Int32Array(d.barrier);Atomics.add(barrier,0,1);Atomics.notify(barrier,0);while(Atomics.load(barrier,0)<2)Atomics.wait(barrier,0,1,100);try{const result=d.action==='approve'?m.approveSale(db,d.actor,d.object,{verified:true,reason:'Concurrent sale approval verification'},d.key):m.reserve(db,d.actor,{customer_id:d.object,invoice:d.key,amount:d.body.amount,reason:'Concurrent invoice reservation verification'},d.key);parentPort.postMessage({ok:true,result});}catch(e){parentPort.postMessage({ok:false,error:e.message});}finally{db.close();}})().catch(e=>{throw e});`;
    return Promise.all(
      [1, 2].map(
        () =>
          new Promise<{ ok: boolean; error?: string }>(
            (resolveResult, reject) => {
              const w = new Worker(code, {
                eval: true,
                workerData: {
                  action,
                  object,
                  body,
                  actor: a,
                  path: f.cfg.DATABASE_PATH,
                  key: randomUUID(),
                  barrier,
                  dbModule: pathToFileURL(resolve("dist-server/server/db.js"))
                    .href,
                  financeModule: pathToFileURL(
                    resolve("dist-server/server/finance.js"),
                  ).href,
                },
              });
              w.once("message", resolveResult);
              w.once("error", reject);
            },
          ),
      ),
    );
  }
});
