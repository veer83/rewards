import { useEffect, useState } from "react";
import { FiDownload, FiPlus, FiCheckCircle } from "react-icons/fi";
import { api, date, money } from "./api";
import {
  ActionForm,
  Badge,
  Empty,
  Modal,
  Notice,
  Table,
  type Field,
} from "./ui";
import type {
  Grant,
  Ledger,
  Me,
  Reconciliation,
  Redemption,
  Review,
  Sale,
} from "./shared";

type Action = {
  title: string;
  path: string;
  fields: Field[];
  extra?: Record<string, unknown>;
  submit?: string;
};
export function FinancialWorkspace({
  me,
  reports = false,
  revision,
  onChange,
}: {
  me: Me;
  reports?: boolean;
  revision: number;
  onChange: () => void;
}) {
  const [data, setData] = useState<{
    grants: Grant[];
    ledger: Ledger[];
    redemptions: Redemption[];
    sales: Sale[];
    reviews: Review[];
    report: Reconciliation | null;
  } | null>(null);
  const [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [action, setAction] = useState<Action | null>(null),
    [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("credits");
  const admin = me.role === "admin";
  useEffect(() => {
    const c = new AbortController();
    setError("");
    setLoading(true);
    Promise.all([
      api<Grant[]>("/rewards/grants", undefined, undefined, c.signal),
      api<Ledger[]>("/ledger", undefined, undefined, c.signal),
      api<Redemption[]>("/redemptions", undefined, undefined, c.signal),
      admin
        ? api<Sale[]>("/sales", undefined, undefined, c.signal)
        : Promise.resolve([]),
      admin
        ? api<Review[]>("/reviews", undefined, undefined, c.signal)
        : Promise.resolve([]),
      admin
        ? api<Reconciliation>(
            "/reports/reconciliation",
            undefined,
            undefined,
            c.signal,
          )
        : Promise.resolve(null),
    ])
      .then(([grants, ledger, redemptions, sales, reviews, report]) => {
        if (!c.signal.aborted)
          setData({ grants, ledger, redemptions, sales, reviews, report });
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(e.message);
      })
      .finally(() => {
        if (!c.signal.aborted) setLoading(false);
      });
    return () => c.abort();
  }, [revision, admin]);
  const reason: Field = {
    name: "reason",
    label: "Evidence and reason",
    type: "textarea",
    hint: "Record what was independently checked. At least 10 characters.",
  };
  const done = () => {
    setAction(null);
    setNotice(
      "The operation was recorded. Balances are refreshed from the ledger.",
    );
    onChange();
  };
  const reserve = (g?: Grant) =>
    setAction({
      title: "Reserve service credit",
      path: "/redemptions/reservations",
      submit: "Reserve credit",
      fields: [
        {
          name: "customer_id",
          label: "Customer",
          value: g?.customer_id,
          options: [
            ...new Map(
              (data?.grants || []).map((g) => [
                g.customer_id,
                { value: g.customer_id, label: g.name },
              ]),
            ).values(),
          ],
        },
        {
          name: "invoice",
          label: "External invoice reference",
          hint: "This records a reference. RewardPoint does not post to your invoice system.",
        },
        {
          name: "amount",
          label: "Amount to reserve (CAD cents)",
          type: "number",
          min: 1,
          max: 10000000,
          value: 10000,
        },
        reason,
      ],
    });
  const redemption = (r: Redemption, act: string) => {
    const label =
      {
        confirm: "Confirm external application",
        release: "Release unused reservation",
        review: "Flag uncertain invoice usage",
        reverse: "Restore credit from voided invoice",
      }[act] || act;
    setAction({
      title: label,
      path: `/redemptions/${r.id}/${act}`,
      submit: label,
      fields: [
        {
          name: "external_outcome",
          label: "Verified external outcome",
          options: [
            {
              value: {
                confirm: "applied",
                release: "not_applied",
                review: "uncertain",
                reverse: "invoice_voided",
              }[act]!,
              label: {
                confirm: "I verified the discount was applied externally",
                release: "I verified the discount was NOT applied externally",
                review: "The external outcome is uncertain; keep the hold",
                reverse: "I verified the invoice was voided and usage undone",
              }[act]!,
            },
          ],
        },
        reason,
      ],
    });
  };
  if (error)
    return (
      <Notice error>
        {error}
        <button onClick={onChange}>Retry</button>
      </Notice>
    );
  if (loading || !data) return <Notice>Loading the credit ledger...</Notice>;
  const own = {
    available: data.grants.reduce((s, g) => s + g.available, 0),
    held: data.grants.reduce((s, g) => s + g.held, 0),
    balance: data.grants.reduce((s, g) => s + g.balance, 0),
  };
  return (
    <>
      {notice && (
        <Notice>
          {notice}
          <button className="text-button" onClick={() => setNotice("")}>
            Dismiss
          </button>
        </Notice>
      )}
      <section className="kpis">
        {[
          [
            reports ? "Issued service credit" : "Available credit",
            reports ? data.report!.issued : own.available,
            "CAD · Service benefits only",
          ],
          ["Reserved credit", own.held, "Held pending external confirmation"],
          ["Posted balance", own.balance, "Includes held and frozen credit"],
          [
            admin ? "Pending approval" : "Your grants",
            admin ? money(data.report!.pending) : data.grants.length,
            admin
              ? "Not spendable until verified"
              : "Earned through verified sales",
          ],
        ].map(([title, value, hint]) => (
          <article key={title}>
            <span>{title}</span>
            <strong>
              {typeof value === "number" && title !== "Your grants"
                ? money(value)
                : value}
            </strong>
            <small>{hint}</small>
          </article>
        ))}
      </section>
      {reports && data.report ? (
        <>
          <section className="panel padded">
            <div className="section-heading flush">
              <div>
                <h2>Every credit accounted for</h2>
                <p>{data.report.cohort}</p>
              </div>
              <a className="button" href="/api/v1/reports/export">
                <FiDownload />
                Export ledger CSV
              </a>
            </div>
            <div className="reconciliation">
              <div>
                <span>Issued</span>
                <strong>{money(data.report.issued)}</strong>
              </div>
              <div>
                <span>+ Restored</span>
                <strong>{money(data.report.restored)}</strong>
              </div>
              <div>
                <span>− Used</span>
                <strong>{money(data.report.used)}</strong>
              </div>
              <div>
                <span>− Reversed</span>
                <strong>{money(data.report.reversed)}</strong>
              </div>
              <div>
                <span>= Posted</span>
                <strong>{money(data.report.posted)}</strong>
              </div>
            </div>
            <Notice error={!data.report.balanced}>
              <FiCheckCircle />
              {data.report.balanced
                ? "Ledger reconciles exactly."
                : "Reconciliation mismatch requires investigation."}{" "}
              Available = posted − held − frozen ({money(data.report.frozen)}).
            </Notice>
            <div className="report-facts">
              <p>
                Accepted leads <strong>{data.report.accepted}</strong>
              </p>
              <p>
                Recorded sales <strong>{data.report.recorded_sales}</strong>
              </p>
              <p>
                Currently verified sales{" "}
                <strong>{data.report.verified_sales}</strong>
              </p>
              <p>
                Open review cases <strong>{data.report.open_reviews}</strong>
              </p>
            </div>
            <p className="small">
              As of {date(data.report.as_of)}. Vehicle discounts are separate
              from this ledger. These demo totals are not an accounting
              liability valuation.
            </p>
          </section>
          <LedgerTable entries={data.ledger} />
        </>
      ) : (
        <>
          <div
            className="workspace-tabs"
            role="tablist"
            aria-label="Credit workspaces"
          >
            {[
              ["credits", "Service credits"],
              ...(admin
                ? [
                    [
                      "approvals",
                      `Sale approvals (${data.sales.filter((s) => s.status === "pending").length})`,
                    ],
                    ["reservations", "Redemptions"],
                    [
                      "reviews",
                      `Reconciliation (${data.reviews.filter((r) => r.status === "open").length})`,
                    ],
                  ]
                : [["reservations", "Your redemptions"]]),
              ["history", "Ledger history"],
            ].map(([id, label]) => (
              <button
                key={id}
                role="tab"
                aria-selected={tab === id}
                onClick={() => setTab(id)}
              >
                {label}
              </button>
            ))}
          </div>
          {tab === "credits" && (
            <section className="panel">
              <div className="section-heading">
                <div>
                  <h2>
                    {admin ? "Service credit register" : "Your service credits"}
                  </h2>
                  <p>Referrer and recipient benefits are independent grants.</p>
                </div>
                {admin && (
                  <button
                    className="primary"
                    onClick={() => reserve()}
                    disabled={!data.grants.length}
                  >
                    <FiPlus />
                    Reserve credit
                  </button>
                )}
              </div>
              <Table
                label="Service credits"
                headers={[
                  "Beneficiary",
                  "Benefit",
                  "Issued",
                  "Held",
                  "Available",
                  "State",
                  ...(admin ? ["Action"] : []),
                ]}
              >
                {data.grants.map((g) => (
                  <tr key={g.id}>
                    <td>
                      <strong>{g.name}</strong>
                      <small>{date(g.created_at)}</small>
                    </td>
                    <td>{g.beneficiary} service credit</td>
                    <td>{money(g.amount)}</td>
                    <td>{money(g.held)}</td>
                    <td>
                      <strong>{money(g.available)}</strong>
                    </td>
                    <td>
                      <Badge
                        tone={g.state === "review" ? "warning" : "success"}
                      >
                        {g.state === "issued"
                          ? g.balance === 0
                            ? "Redeemed"
                            : g.balance < g.amount
                              ? "Partly used"
                              : "Available"
                          : g.state}
                      </Badge>
                    </td>
                    {admin && (
                      <td>
                        <button
                          disabled={g.available <= 0}
                          onClick={() => reserve(g)}
                        >
                          Reserve
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </Table>
              {!data.grants.length && (
                <Empty>
                  No earned service credits yet. Acceptance alone does not
                  create credit.
                </Empty>
              )}
            </section>
          )}
          {tab === "approvals" && admin && (
            <section className="panel">
              <div className="section-heading">
                <h2>Delivered-sale verification</h2>
                <Badge tone="warning">ADMINISTRATOR CONTROL</Badge>
              </div>
              <Table
                label="Sale approvals"
                headers={[
                  "Sale reference",
                  "Beneficiaries",
                  "Vehicle discount",
                  "Status",
                  "Actions",
                ]}
              >
                {data.sales.map((s) => (
                  <tr key={s.id}>
                    <td>
                      <strong>{s.reference}</strong>
                      <small>{date(s.delivered_at)}</small>
                      <details>
                        <summary>Evidence</summary>
                        <p>{s.evidence}</p>
                      </details>
                    </td>
                    <td>
                      {s.recipient}
                      <small>Referrer: {s.referrer}</small>
                    </td>
                    <td>
                      {money(s.discount_amount)}
                      <small>Outside the service-credit ledger</small>
                    </td>
                    <td>
                      <Badge>{s.status}</Badge>
                    </td>
                    <td>
                      <div className="row-actions">
                        {s.status === "pending" && (
                          <button
                            className="primary"
                            onClick={() =>
                              setAction({
                                title: "Verify sale and issue credits",
                                path: `/sales/${s.id}/approve`,
                                submit: "Approve & issue once",
                                fields: [
                                  {
                                    name: "verified",
                                    label:
                                      "I verified the delivered sale, both identities, qualification and evidence",
                                    type: "checkbox",
                                    required: true,
                                  },
                                  reason,
                                ],
                              })
                            }
                          >
                            Verify & issue
                          </button>
                        )}
                        {["pending", "approved"].includes(s.status) && (
                          <button
                            onClick={() =>
                              setAction({
                                title: "Record source-sale cancellation",
                                path: `/sales/${s.id}/cancel`,
                                submit: "Record cancellation",
                                fields: [reason],
                              })
                            }
                          >
                            Cancel / reverse
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </Table>
              {!data.sales.length && (
                <Empty>
                  Record sale evidence from a lead to start verification.
                </Empty>
              )}
            </section>
          )}
          {tab === "reservations" && (
            <section className="panel">
              <div className="section-heading">
                <div>
                  <h2>External invoice reservations</h2>
                  <p>
                    Reserve here, apply in the dealer system, then confirm here.
                  </p>
                </div>
              </div>
              <Notice>
                Uncertain usage stays held until reconciled. No automatic
                release or invoice-system integration.
              </Notice>
              <Table
                label="Redemptions"
                headers={[
                  "Invoice / customer",
                  "Amount",
                  "State",
                  "Evidence",
                  ...(admin ? ["Actions"] : []),
                ]}
              >
                {data.redemptions.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <strong>{r.invoice}</strong>
                      <small>{r.name}</small>
                    </td>
                    <td>{money(r.amount)}</td>
                    <td>
                      <Badge
                        tone={r.status === "review" ? "warning" : "neutral"}
                      >
                        {r.status}
                      </Badge>
                      <small>{date(r.updated_at)}</small>
                    </td>
                    <td>{r.reason}</td>
                    {admin && (
                      <td>
                        <div className="row-actions">
                          {["reserved", "review"].includes(r.status) && (
                            <>
                              <button onClick={() => redemption(r, "confirm")}>
                                Confirm
                              </button>
                              <button onClick={() => redemption(r, "release")}>
                                Release
                              </button>
                              {r.status !== "review" && (
                                <button onClick={() => redemption(r, "review")}>
                                  Uncertain
                                </button>
                              )}
                            </>
                          )}
                          {r.status === "confirmed" && (
                            <button onClick={() => redemption(r, "reverse")}>
                              Invoice voided
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </Table>
              {!data.redemptions.length && (
                <Empty>No reservations or redemptions yet.</Empty>
              )}
            </section>
          )}
          {tab === "reviews" && admin && (
            <section className="panel">
              <div className="section-heading">
                <h2>Reconciliation & exceptions</h2>
                <Badge tone={data.report?.balanced ? "success" : "warning"}>
                  {data.report?.balanced
                    ? "Ledger balanced"
                    : "Review required"}
                </Badge>
              </div>
              <Table
                label="Review cases"
                headers={["Review", "Reason", "State", "Resolution"]}
              >
                {data.reviews.map((r) => (
                  <tr key={r.id}>
                    <td>
                      {r.kind.replaceAll("_", " ")}
                      <small>{date(r.created_at)}</small>
                    </td>
                    <td>{r.reason}</td>
                    <td>
                      <Badge>{r.status}</Badge>
                    </td>
                    <td>
                      {r.status === "open" ? (
                        r.kind === "uncertain_invoice" ? (
                          <button onClick={() => setTab("reservations")}>
                            Review reservation
                          </button>
                        ) : (
                          <button
                            onClick={() =>
                              setAction({
                                title: "Resolve reviewed exception",
                                path: `/reviews/${r.id}/resolve`,
                                fields: [
                                  {
                                    name: "outcome",
                                    label: "Reviewed outcome",
                                    options:
                                      r.kind === "used_credit_cancellation"
                                        ? [
                                            {
                                              value: "uphold_sale",
                                              label:
                                                "Evidence confirms original sale remains valid",
                                            },
                                            {
                                              value: "confirm_cancellation",
                                              label:
                                                "Cancel only after all used/held credit is resolved",
                                            },
                                          ]
                                        : [
                                            {
                                              value: "reviewed_no_change",
                                              label:
                                                "Keep original attribution after review",
                                            },
                                          ],
                                  },
                                  reason,
                                ],
                              })
                            }
                          >
                            Resolve
                          </button>
                        )
                      ) : (
                        r.resolution
                      )}
                    </td>
                  </tr>
                ))}
              </Table>
              {!data.reviews.length && (
                <Empty>
                  No review cases. Uncertain usage and cancellation exceptions
                  appear here.
                </Empty>
              )}
            </section>
          )}
          {tab === "history" && <LedgerTable entries={data.ledger} />}
        </>
      )}
      {action && (
        <Modal title={action.title} onClose={() => setAction(null)}>
          <ActionForm {...action} onDone={done} />
        </Modal>
      )}
    </>
  );
}
function LedgerTable({ entries }: { entries: Ledger[] }) {
  return (
    <section className="panel">
      <div className="section-heading">
        <h2>Append-only ledger history</h2>
        <Badge>{entries.length} entries</Badge>
      </div>
      <Table
        label="Ledger history"
        headers={["Movement", "Amount", "Evidence", "Posted"]}
      >
        {entries.map((l) => (
          <tr key={l.id}>
            <td>
              <Badge>{l.kind}</Badge>
              {l.source_id && <small>Linked compensating entry</small>}
            </td>
            <td>{money(l.amount, l.currency)}</td>
            <td>{l.reason}</td>
            <td>{date(l.created_at)}</td>
          </tr>
        ))}
      </Table>
      {!entries.length && (
        <Empty>No financial movements have been posted.</Empty>
      )}
    </section>
  );
}
