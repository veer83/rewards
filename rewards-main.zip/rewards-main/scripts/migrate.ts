import { config } from "../server/config.js";
import { Store, migrate } from "../server/db.js";
import { createAuth, migrateAuth } from "../server/auth.js";
const cfg = config();
const db = new Store(cfg.DATABASE_PATH);
await migrateAuth(createAuth(db, cfg));
migrate(db);
db.close();
console.log("RewardPoint migrations applied.");
