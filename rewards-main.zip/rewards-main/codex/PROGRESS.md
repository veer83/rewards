# RewardPoint implementation progress

## RP-00: verified baseline
- Existing rewards clone: clean main at 0754fe92a7890101bd13ee1cea5c3c9f9d14c569; README only; no repository AGENTS or CI.
- Origin: driveonyxsolutions-oss/rewards, PRIVATE, authenticated permission ADMIN.
- Implementation branch: codex/rewardpoint-initial. No default branch merge/deployment.
- Handoff v0.3 inspected outside the repository. Private historical documents excluded.
- Current Service Portal source and live login inspected read-only. React 19 / Vite 8 / TypeScript conventions; Inter, reviewed violet controls, neutral surfaces, split login. Source tree is dirty and preserved.
- Architecture: React/TypeScript, Express, Better Auth, SQLite WAL with immediate write transactions, same-origin production static serving. SQLite is an intentional single-host demo choice; no shared database or sibling imports.
- D01-D12 are synthetic-demo assumptions only. Live operations fail closed. Captured notifications only.
- Asset redistribution confirmation pending. No proprietary binary assets copied yet.
- Proposed hostname currently has no DNS answer. Existing portal on 4173 left running. No local default Cloudflare directory or launch agent found; deployment discovery continues.

## Implemented checkpoint
- RP-01/02/03: production-built same-theme shell, real Better Auth login/recovery, server tenant/customer ownership, two synthetic dealers, campaigns/versioning, explicit eligibility enrollment, opaque encrypted links, separate consent, durable public acceptance and lead activity.
- RP-04/05 core: delivered-sale evidence, independently verified beneficiaries, atomic two-beneficiary grants, append-only ledger, event uniqueness, payload-bound idempotency, multi-grant partial reservations, confirm/release/uncertain review, linked invoice/source reversals and reconciliation.
- Financial and reporting screens connected. Additional customer administration, receipt validation and hardening are next; stages are not declared fully complete yet.
- Local Express production-build server: 4184. Isolated automated browser server: 4187. Existing Service Portal 4173 untouched.

## Actual evidence at this checkpoint
- `npm run lint`: PASS.
- `npm run build`: PASS (TypeScript frontend/server and Vite production bundle).
- `npm test`: PASS, 20 tests across 2 files, including independent SQLite-connection racing approval/reservation, atomic rollback injection, roles, cross-dealer access, consent, financial retries and reversal ordering.
- `PLAYWRIGHT_BROWSERS_PATH=.local/browsers npm run test:browser`: first browser flow PASS, 1 Chromium test covering login/enrollment/No Contact acceptance/lead reload/dialog Escape/themes/logout with external origins blocked.
- Extended financial browser flow: PASS, same Chromium test extended through identity verification, sale evidence, two-beneficiary issuance, partial reservation, uncertain-use hold, confirmation and balanced reporting. Found and fixed loading-form and tab-preservation bugs during this run.
- `npm audit --omit=dev`: 0 known vulnerabilities at inspection.
- Screenshots from the actual built application are local under `output/screenshots/`, not historical handoff evidence. Font declaration now matches the portal's optional Google-hosted Inter; no font binaries bundled.
- A local build snapshot `checkpoint-a` is retained for the upcoming rollback rehearsal. It is an uncommitted development checkpoint, not a production release.

## Narrow blockers
- Asset redistribution permission pending; logo and showroom files not copied.
- RP-06B: proposed hostname has no DNS answer. Existing system Cloudflare service uses a connector token file, not discovered account/zone administration access. No connector or existing route was changed. User asked for local configuration path or signed-in dashboard, not secret values.

## Verified follow-up, 2026-09-25
- RP-02/03 hardening: valid hashed receipts; current-version enrollment; attribution review cannot be bypassed by identity verification; customer history and preferences; synthetic staff/customer provisioning with captured single-use recovery; no automatic existing-account reassignment.
- Identity boundaries now include cross-tab sign-out/account changes, expired-session clearing, guarded requests and cancellation. An unavailable session/API never becomes a fake demo identity.
- Overview uses actual reconciliation totals. Lead Bank has search, stage, contact and assignment filters. Captured invitation previews include the correct public offer and versioned benefits. Campaign actions avoid misleading historical-version controls.
- RP-04/05: verified-sale credit, partial redemption, uncertain hold, confirmation, reversals and reconciliation tested through real API/database paths and the dealer browser journey. Customer browser access shows only their own grant/remaining balance and cannot reserve credit.
- RP-06A operations: checksummed migrations, build identity manifest, immutable artifacts, online backup, new-path restore, compatible application rollback rehearsal, separate production static/API origin and operational runbook implemented.
- Final expanded local checks: lint/build PASS; 31 tests in 4 API/database/operations files PASS; 2 Chromium browser tests PASS. Production dependency audit: 0 known vulnerabilities. No historical preview counts reused.
- The browser run covers No Contact acceptance, lead reload, identity verification, sale approval, both grants, partial use, uncertain review, confirmation, exact reconciliation, customer ownership, account switch, cross-tab logout, keyboard focus restoration, responsive 390/768/1440 widths, light/dark/system and API failure/invalid-link states. External origins are blocked during the complete business flow; Service Portal remains running.
- Online backup and separate restore scripts PASS on the local synthetic demo. The restoration test preserves financial/history records and exact balances. A real built-server restart preserves a nonempty lead and the same authenticated session.
- A -> B -> A rehearsal PASS with distinct immutable frontend builds, durable customer records and sessions on a disposable database. This does not assert database downgrade compatibility. The first rehearsal exposed a hidden-path static fallback issue, fixed in current code and documented.
- Keyboard testing exposed lost focus after drawer close; fixed and verified. Test selector ambiguity introduced by the contact filter was corrected. Authentication rate limiting remained enabled during all recovery tests.
- A subsequent combined run exposed whole-second rounding in the sale form during a fast acceptance-to-sale sequence. Delivery defaults now retain milliseconds and server dates normalize to canonical UTC before comparisons. A precision-boundary regression test and the final combined lint/build/31-test/2-browser run passed after this correction.
- Read-only checkpoint confirms unchanged reference Git state and 514 source/config hashes. Original Service Portal listener remains PID 15992 on 4173. No original DNS/tunnel/account settings altered.
- First checkpoint `4c460443a30d33e7c54beb328ef86fed69dec76d` was pushed and independently matched on origin. GitHub Actions run `36196276102` passed. Follow-up commit/push checks are reported with their exact SHA and CI result in the task handover; main is not merged.

## Stage status and precise resume point
- RP-00 verified; RP-01 functional same-theme shell implemented, exact proprietary asset parity blocked by permission.
- RP-02 through RP-05 implemented and locally verified for synthetic demo scope; D01-D12 are not approved live-business policy.
- RP-06A implemented and locally verified. Final branch CI is the remote reproducibility check, not deployment evidence.
- RP-06B BLOCKED: no verified separate hostname/route or authorized Cloudflare account/zone administration access. No public demo URL is claimed. Provide a local account configuration path or signed-in dashboard, not secret values in chat; then follow `docs/OPERATIONS.md` and verify HTTPS/build identity/full flow and original-portal preservation.
- Await explicit logo/showroom redistribution permission before copying those assets. Nothing proprietary has been published.
- RP-07 integration, paid hosting, live messaging, real-customer/monetary launch and default-branch merge remain out of scope.
