import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { financeMigration } from "./finance-schema.js";
import { hardeningMigration } from "./hardening-schema.js";

export type Value = string | number | null;
export class Store {
  readonly db: Database.Database;
  constructor(path: string) {
    if (path !== ":memory:")
      mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
    this.db = new Database(path);
    this.db.pragma("foreign_keys = ON");
    this.db.pragma("journal_mode = WAL");
    this.db.pragma("busy_timeout = 10000");
  }
  get<T>(sql: string, ...params: Value[]): T | undefined {
    return this.db.prepare(sql).get(...params) as T | undefined;
  }
  all<T>(sql: string, ...params: Value[]): T[] {
    return this.db.prepare(sql).all(...params) as T[];
  }
  run(sql: string, ...params: Value[]) {
    return this.db.prepare(sql).run(...params);
  }
  transaction<T>(fn: () => T): T {
    return this.db.transaction(fn).immediate();
  }
  close() {
    this.db.close();
  }
}
export const id = () => randomUUID();
export const now = () => new Date().toISOString();
export const hash = (value: string) =>
  createHash("sha256").update(value).digest("hex");

const migrations = [
  {
    version: 1,
    sql: `
CREATE TABLE tenants (id TEXT PRIMARY KEY, name TEXT NOT NULL, currency TEXT NOT NULL CHECK(currency = 'CAD'), timezone TEXT NOT NULL);
CREATE TABLE customers (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), name TEXT NOT NULL, email TEXT NOT NULL,
 dealer_reference TEXT NOT NULL DEFAULT '', verified INTEGER NOT NULL DEFAULT 0, owner_id TEXT NOT NULL,
 user_id TEXT UNIQUE, created_at TEXT NOT NULL, UNIQUE(tenant_id,id)
);
CREATE TABLE memberships (
 user_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), role TEXT NOT NULL CHECK(role IN ('admin','sales','customer')),
 customer_id TEXT, active INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id)
);
CREATE TABLE campaigns (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), name TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('draft','active','paused','ended')), created_at TEXT NOT NULL, UNIQUE(tenant_id,id)
);
CREATE TABLE campaign_versions (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, campaign_id TEXT NOT NULL, version INTEGER NOT NULL,
 referrer_amount INTEGER NOT NULL CHECK(referrer_amount BETWEEN 0 AND 10000000),
 discount_amount INTEGER NOT NULL CHECK(discount_amount BETWEEN 0 AND 10000000),
 recipient_amount INTEGER NOT NULL CHECK(recipient_amount BETWEEN 0 AND 10000000),
 currency TEXT NOT NULL CHECK(currency='CAD'), terms TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
 purchase_by TEXT NOT NULL, published_at TEXT,
 FOREIGN KEY(tenant_id,campaign_id) REFERENCES campaigns(tenant_id,id), UNIQUE(campaign_id,version), UNIQUE(tenant_id,id)
);
CREATE TRIGGER immutable_version BEFORE UPDATE ON campaign_versions WHEN OLD.published_at IS NOT NULL BEGIN SELECT RAISE(ABORT,'Published terms are immutable'); END;
CREATE TABLE enrolments (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, customer_id TEXT NOT NULL, version_id TEXT NOT NULL,
 token_hash TEXT NOT NULL UNIQUE, token_cipher TEXT NOT NULL, eligibility TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, UNIQUE(customer_id,version_id), UNIQUE(tenant_id,id),
 FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id), FOREIGN KEY(tenant_id,version_id) REFERENCES campaign_versions(tenant_id,id)
);
CREATE TABLE leads (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, enrolment_id TEXT NOT NULL, customer_id TEXT NOT NULL,
 email_normalized TEXT NOT NULL, interest TEXT NOT NULL DEFAULT '', stage TEXT NOT NULL DEFAULT 'New',
 assigned_to TEXT NOT NULL, review INTEGER NOT NULL DEFAULT 0, receipt_hash TEXT NOT NULL UNIQUE,
 created_at TEXT NOT NULL, UNIQUE(tenant_id,email_normalized), UNIQUE(tenant_id,id),
 FOREIGN KEY(tenant_id,enrolment_id) REFERENCES enrolments(tenant_id,id), FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id)
);
CREATE TABLE activities (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, lead_id TEXT NOT NULL, actor TEXT NOT NULL,
 kind TEXT NOT NULL, note TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(tenant_id,lead_id) REFERENCES leads(tenant_id,id));
CREATE TABLE consents (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, customer_id TEXT NOT NULL,
 purpose TEXT NOT NULL CHECK(purpose IN ('offer','marketing','invitation','terms')), granted INTEGER NOT NULL CHECK(granted IN(0,1)),
 text_version TEXT NOT NULL, source TEXT NOT NULL, created_at TEXT NOT NULL,
 FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id));
CREATE TABLE outbox (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, customer_id TEXT NOT NULL, purpose TEXT NOT NULL,
 event_key TEXT NOT NULL UNIQUE, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
 FOREIGN KEY(tenant_id,customer_id) REFERENCES customers(tenant_id,id));
CREATE TABLE audit (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL,
 object_id TEXT NOT NULL, reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE operations (scope TEXT NOT NULL, key TEXT NOT NULL, request_hash TEXT NOT NULL, result TEXT NOT NULL,
 created_at TEXT NOT NULL, PRIMARY KEY(scope,key));
CREATE TABLE reviews (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, object_id TEXT NOT NULL, kind TEXT NOT NULL,
 reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', resolution TEXT, created_at TEXT NOT NULL);
`,
  },
  financeMigration,
  hardeningMigration,
];

export function migrate(store: Store) {
  store.db.exec(
    "CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL)",
  );
  for (const m of migrations) {
    const prior = store.get<{ checksum: string }>(
      "SELECT checksum FROM schema_migrations WHERE version=?",
      m.version,
    );
    if (prior && prior.checksum !== hash(m.sql))
      throw new Error("Migration checksum mismatch");
    if (!prior)
      store.transaction(() => {
        store.db.exec(m.sql);
        store.run(
          "INSERT INTO schema_migrations VALUES (?,?,?)",
          m.version,
          hash(m.sql),
          now(),
        );
      });
  }
  for (const table of ["consents", "audit", "activities"]) {
    for (const operation of ["UPDATE", "DELETE"])
      store.db.exec(
        `CREATE TRIGGER IF NOT EXISTS ${table}_no_${operation} BEFORE ${operation} ON ${table} BEGIN SELECT RAISE(ABORT,'Append-only history'); END;`,
      );
  }
}
