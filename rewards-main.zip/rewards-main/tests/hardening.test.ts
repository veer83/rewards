import { beforeAll, afterAll, describe, it, expect } from "vitest";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { fixture } from "./helpers.js";
import {
  enroll,
  accept,
  publicOffer,
  createCampaign,
  campaignAction,
  leadActivity,
  campaignSchema,
} from "../server/referrals.js";
import type { Actor, Customer, Version } from "../server/model.js";
import { resolveReview } from "../server/finance.js";

describe("public safety, recovery and administration", () => {
  let f: Awaited<ReturnType<typeof fixture>>,
    a: Actor,
    c: Customer,
    v: Version,
    t: string;
  let adminAgent: Awaited<
    ReturnType<Awaited<ReturnType<typeof fixture>>["login"]>
  >;
  let otherAgent: typeof adminAgent;
  beforeAll(async () => {
    f = await fixture();
    a = f.db.get<Actor>(
      "SELECT m.*,u.name,u.email FROM memberships m JOIN user u ON u.id=m.user_id WHERE m.user_id=?",
      f.users["admin@northstar.invalid"],
    )!;
    c = f.db.get<Customer>("SELECT * FROM customers LIMIT 1")!;
    v = f.db.get<Version>(
      "SELECT * FROM campaign_versions WHERE tenant_id='northstar'",
    )!;
    t = enroll(
      f.db,
      f.cfg,
      a,
      {
        customer_id: c.id,
        version_id: v.id,
        eligibility: "Verified synthetic purchase eligibility",
        invitation_consent: true,
      },
      randomUUID(),
    )
      .share_url.split("/")
      .pop()!;
  });
  afterAll(() => f?.db.close());
  it('normalizes UTC timestamp precision before comparing campaign windows',()=>{
    const input={name:'Precision demo',referrer_amount:50000,recipient_amount:50000,discount_amount:50000,terms:'Synthetic terms for precision boundary verification',starts_at:'2026-09-01T00:00:00Z',ends_at:'2026-09-01T00:00:00.100Z',purchase_by:'2026-09-02T00:00:00Z'};
    const result=campaignSchema.parse(input);expect(result.starts_at).toBe('2026-09-01T00:00:00.000Z');
    expect(campaignSchema.safeParse({...input,starts_at:'2026-09-01T00:00:00.000Z',ends_at:'2026-09-01T00:00:00Z'}).success).toBe(false);
  });
  beforeAll(async () => {
    adminAgent = await f.login();
    otherAgent = await f.login("admin@lakeside.invalid");
  });
  const body = (email: string) => ({
    name: "Synthetic Recipient",
    email,
    version_id: v.id,
    contact: "none",
    marketing: false,
    terms_accepted: true,
    privacy_acknowledged: true,
  });
  it("rejects tampered amounts, missing consent, live addresses and invalid tokens", async () => {
    expect(() =>
      accept(
        f.db,
        t,
        { ...body("tamper@test.invalid"), amount: 10000000 },
        randomUUID(),
      ),
    ).toThrow();
    expect(() =>
      accept(
        f.db,
        t,
        { ...body("tamper@test.invalid"), terms_accepted: false },
        randomUUID(),
      ),
    ).toThrow();
    expect(() =>
      accept(
        f.db,
        t,
        { ...body("tamper@test.invalid"), marketing: true },
        randomUUID(),
      ),
    ).toThrow();
    expect(() =>
      accept(f.db, t, body("someone@example.com"), randomUUID()),
    ).toThrow("synthetic");
    expect(() => publicOffer(f.db, "guess")).toThrow("unavailable");
    await request(f.app).get("/api/v1/public/receipts/guess").expect(404);
  });
  it("acknowledges duplicates generically without extra leads or claims on private identities", () => {
    const first = accept(f.db, t, body("duplicate@test.invalid"), randomUUID());
    const second = accept(
      f.db,
      t,
      body("duplicate@test.invalid"),
      randomUUID(),
    );
    expect(first.status).toBe(second.status);
    expect(first.message).toBe(second.message);
    expect(
      f.db.get<{ n: number }>(
        "SELECT count(*) n FROM leads WHERE email_normalized='duplicate@test.invalid'",
      )!.n,
    ).toBe(1);
    expect(f.db.get<{ n: number }>("SELECT count(*) n FROM receipts")!.n).toBe(
      2,
    );
    const prior = f.db.get<Customer>(
      "SELECT * FROM customers WHERE id=?",
      c.id,
    )!;
    accept(f.db, t, body(c.email), randomUUID());
    expect(
      f.db.get<Customer>("SELECT * FROM customers WHERE id=?", c.id),
    ).toEqual(prior);
  });
  it("preserves consent events and denies staff opt-in forgery", async () => {
    await adminAgent
      .post(`/api/v1/customers/${c.id}/consents`)
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({
        purpose: "marketing",
        granted: true,
        evidence: "Staff attempting to invent customer consent",
      })
      .expect(403);
    expect(() => f.db.run("DELETE FROM consents")).toThrow("Append-only");
  });
  it("blocks paused and superseded links but preserves accepted version evidence", () => {
    campaignAction(f.db, a, v.campaign_id, "pause");
    expect(() => publicOffer(f.db, t)).toThrow("paused");
    campaignAction(f.db, a, v.campaign_id, "publish");
    createCampaign(
      f.db,
      a,
      {
        name: "Revised draft",
        referrer_amount: 32100,
        recipient_amount: 12300,
        discount_amount: 10000,
        terms:
          "Synthetic revised terms. No real monetary value. D01-D12 unapproved.",
        starts_at: v.starts_at,
        ends_at: v.ends_at,
        purchase_by: v.purchase_by,
      },
      v.campaign_id,
    );
    campaignAction(f.db, a, v.campaign_id, "publish");
    expect(() => publicOffer(f.db, t)).toThrow("superseded");
    expect(
      f.db.get<Version>("SELECT * FROM campaign_versions WHERE id=?", v.id)!
        .referrer_amount,
    ).toBe(50000);
  });
  it("prevents attribution conflicts from being cleared by identity verification alone", () => {
    const l = f.db.get<{ id: string }>(
      "SELECT id FROM leads WHERE email_normalized='duplicate@test.invalid'",
    )!;
    expect(() =>
      leadActivity(f.db, a, l.id, {
        kind: "identity",
        note: "Attempt to skip unresolved attribution review",
      }),
    ).toThrow("Resolve the attribution");
    const reviews = f.db.all<{ id: string }>(
      "SELECT id FROM reviews WHERE object_id=?",
      l.id,
    );
    for (const r of reviews)
      resolveReview(
        f.db,
        a,
        r.id,
        {
          outcome: "reviewed_no_change",
          reason: "Investigated duplicate and retained original attribution",
        },
        randomUUID(),
      );
    expect(() =>
      leadActivity(f.db, a, l.id, {
        kind: "identity",
        note: "Verified identity after attribution review",
      }),
    ).not.toThrow();
  });
  it("captures single-use password recovery and revokes old sessions", async () => {
    const agent = await f.login("sales@northstar.invalid");
    await request(f.app)
      .post("/api/auth/request-password-reset")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ email: "sales@northstar.invalid", redirectTo: "/login" })
      .expect(200);
    const file = readdirSync(f.cfg.CAPTURE_DIR).find((n) =>
      n.startsWith("recovery-"),
    )!;
    const content = readFileSync(join(f.cfg.CAPTURE_DIR, file), "utf8");
    const url = content.split("\n").find((s) => s.startsWith("http"))!;
    // Captured recovery secrets stay in memory and are never printed or uploaded.
    const resetToken = new URL(url).pathname.split("/").pop()!;
    const password = `${randomUUID()}-Reset`;
    await request(f.app)
      .post("/api/auth/reset-password")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ token: resetToken, newPassword: password })
      .expect(200);
    await agent.get("/api/v1/me").expect(401);
    const replay = await request(f.app)
      .post("/api/auth/reset-password")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ token: resetToken, newPassword: password });
    expect(replay.status).toBeGreaterThanOrEqual(400);
    await request(f.app)
      .post("/api/auth/sign-in/email")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ email: "sales@northstar.invalid", password })
      .expect(429);
    // Keep the real authentication limiter enabled and let its documented window expire.
    await new Promise((resolve) => setTimeout(resolve, 10500));
    await request(f.app)
      .post("/api/auth/sign-in/email")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ email: "sales@northstar.invalid", password })
      .expect(200);
  }, 20000);
  it("provisions synthetic staff with local capture and refuses existing identities", async () => {
    const admin = adminAgent;
    const input = {
      name: "New Sales Demo",
      email: "new-sales@test.invalid",
      role: "sales",
    };
    const result = await admin
      .post("/api/v1/users")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send(input)
      .expect(201);
    expect(result.body).not.toHaveProperty("password");
    await admin
      .post("/api/v1/users")
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send(input)
      .expect(409);
    await admin
      .post(`/api/v1/users/${result.body.id}/access`)
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ active: false, role: "sales" })
      .expect(200);
    await admin
      .post(`/api/v1/users/${a.user_id}/access`)
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ active: false, role: "sales" })
      .expect(409);
  });
  it("denies record reassignment through arbitrary nested IDs", async () => {
    await otherAgent.get(`/api/v1/customers/${c.id}/history`).expect(404);
    await otherAgent
      .post(`/api/v1/customers/${c.id}/access`)
      .set("Origin", f.cfg.PUBLIC_ORIGIN)
      .send({ reason: "Attempt cross dealer private account provisioning" })
      .expect(404);
  });
});
