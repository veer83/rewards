import { z } from "zod";
import type { Config } from "./config.js";
import { hash, id, now, type Store } from "./db.js";
import {
  admin,
  staff,
  requireThat,
  type Actor,
  type Campaign,
  type Customer,
  type Enrollment,
  type Version,
} from "./model.js";
import {
  appendConsent,
  audit,
  customer,
  decrypt,
  encrypt,
  lead,
  operation,
  queue,
  token,
} from "./common.js";

const text = z.string().trim().min(1).max(250);
const email = z
  .email()
  .max(254)
  .transform((s) => s.trim().toLowerCase());
export const customerSchema = z
  .object({
    name: text,
    email,
    dealer_reference: z.string().trim().max(100).default(""),
  })
  .strict();
export const campaignSchema = z
  .object({
    name: text,
    referrer_amount: z.number().int().min(0).max(10000000),
    discount_amount: z.number().int().min(0).max(10000000),
    recipient_amount: z.number().int().min(0).max(10000000),
    terms: z.string().trim().min(20).max(5000),
    starts_at: z.iso
      .datetime()
      .transform((value) => new Date(value).toISOString()),
    ends_at: z.iso
      .datetime()
      .transform((value) => new Date(value).toISOString()),
    purchase_by: z.iso
      .datetime()
      .transform((value) => new Date(value).toISOString()),
  })
  .strict()
  .refine(
    (v) => v.starts_at < v.ends_at && v.ends_at <= v.purchase_by,
    "Acceptance and purchase dates must be ordered",
  );
export const acceptanceSchema = z
  .object({
    name: text,
    email,
    interest: z.string().trim().max(200).default(""),
    version_id: z.string(),
    contact: z.enum(["email", "none"]),
    marketing: z.boolean(),
    terms_accepted: z.literal(true),
    privacy_acknowledged: z.literal(true),
  })
  .strict()
  .refine(
    (v) => v.contact !== "none" || !v.marketing,
    "No Contact cannot be combined with marketing",
  );

export function createCustomer(db: Store, actor: Actor, input: unknown) {
  staff(actor);
  const v = customerSchema.parse(input);
  requireThat(
    v.email.endsWith(".invalid"),
    400,
    "This demo accepts synthetic .invalid email addresses only",
  );
  return db.transaction(() => {
    const customerId = id();
    db.run(
      "INSERT INTO customers(id,tenant_id,name,email,dealer_reference,owner_id,created_at) VALUES (?,?,?,?,?,?,?)",
      customerId,
      actor.tenant_id,
      v.name,
      v.email,
      v.dealer_reference,
      actor.user_id,
      now(),
    );
    audit(db, actor, "customer.created", customerId);
    return { id: customerId };
  });
}
export function createCampaign(
  db: Store,
  actor: Actor,
  input: unknown,
  campaignId?: string,
) {
  admin(actor);
  const v = campaignSchema.parse(input);
  return db.transaction(() => {
    const cid = campaignId || id();
    if (campaignId)
      requireThat(
        db.get(
          "SELECT id FROM campaigns WHERE id=? AND tenant_id=?",
          cid,
          actor.tenant_id,
        ),
        404,
        "Campaign unavailable",
      );
    else
      db.run(
        "INSERT INTO campaigns VALUES (?,?,?,?,?)",
        cid,
        actor.tenant_id,
        v.name,
        "draft",
        now(),
      );
    const count = db.get<{ n: number }>(
      "SELECT COALESCE(MAX(version),0) n FROM campaign_versions WHERE campaign_id=?",
      cid,
    )!.n;
    const vid = id();
    db.run(
      "INSERT INTO campaign_versions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
      vid,
      actor.tenant_id,
      cid,
      count + 1,
      v.referrer_amount,
      v.discount_amount,
      v.recipient_amount,
      "CAD",
      v.terms,
      v.starts_at,
      v.ends_at,
      v.purchase_by,
      null,
    );
    audit(db, actor, "campaign.draft", cid);
    return { id: cid, version_id: vid };
  });
}
export function campaignAction(
  db: Store,
  actor: Actor,
  cid: string,
  action: string,
) {
  admin(actor);
  return db.transaction(() => {
    requireThat(
      db.get<Campaign>(
        "SELECT * FROM campaigns WHERE id=? AND tenant_id=?",
        cid,
        actor.tenant_id,
      ),
      404,
      "Campaign unavailable",
    );
    if (action === "publish") {
      const v = db.get<Version>(
        "SELECT * FROM campaign_versions WHERE campaign_id=? ORDER BY version DESC LIMIT 1",
        cid,
      )!;
      requireThat(v.ends_at > now(), 409, "Acceptance window has ended");
      if (!v.published_at)
        db.run(
          "UPDATE campaign_versions SET published_at=? WHERE id=?",
          now(),
          v.id,
        );
      db.run("UPDATE campaigns SET status='active' WHERE id=?", cid);
    } else {
      requireThat(action === "pause", 400, "Unsupported action");
      db.run("UPDATE campaigns SET status='paused' WHERE id=?", cid);
    }
    audit(db, actor, `campaign.${action}.demo-only`, cid);
    return { status: action === "publish" ? "active" : "paused", demo: true };
  });
}
export function enroll(
  db: Store,
  cfg: Config,
  actor: Actor,
  input: unknown,
  key?: string,
) {
  staff(actor);
  const v = z
    .object({
      customer_id: z.string(),
      version_id: z.string(),
      eligibility: z.string().trim().min(10).max(1000),
      invitation_consent: z.boolean(),
    })
    .strict()
    .parse(input);
  customer(db, actor, v.customer_id);
  return operation(
    db,
    `${actor.tenant_id}:${actor.user_id}:enroll`,
    key,
    v,
    () => {
      const version = db.get<Version>(
        "SELECT v.* FROM campaign_versions v JOIN campaigns c ON c.id=v.campaign_id WHERE v.id=? AND v.tenant_id=? AND v.published_at IS NOT NULL AND c.status='active'",
        v.version_id,
        actor.tenant_id,
      );
      requireThat(
        version && version.ends_at > now(),
        409,
        "Select an active published demo campaign",
      );
      requireThat(
        db.get<{ id: string }>(
          "SELECT id FROM campaign_versions WHERE campaign_id=? AND published_at IS NOT NULL ORDER BY version DESC LIMIT 1",
          version.campaign_id,
        )?.id === version.id,
        409,
        "Choose the current published campaign version",
      );
      const existing = db.get<Enrollment>(
        "SELECT * FROM enrolments WHERE customer_id=? AND version_id=?",
        v.customer_id,
        v.version_id,
      );
      if (existing)
        return {
          id: existing.id,
          share_url: `${cfg.PUBLIC_ORIGIN}/r/${decrypt(existing.token_cipher, cfg.AUTH_SECRET)}`,
        };
      const eid = id();
      const publicToken = token();
      db.run(
        "INSERT INTO enrolments VALUES (?,?,?,?,?,?,?,?,?)",
        eid,
        actor.tenant_id,
        v.customer_id,
        v.version_id,
        hash(publicToken),
        encrypt(publicToken, cfg.AUTH_SECRET),
        v.eligibility,
        0,
        now(),
      );
      appendConsent(
        db,
        actor.tenant_id,
        v.customer_id,
        "invitation",
        v.invitation_consent,
        `staff-attestation:${actor.user_id}`,
        "demo-consent-v1",
      );
      queue(
        db,
        actor.tenant_id,
        v.customer_id,
        "invitation",
        `enrollment:${eid}`,
      );
      audit(db, actor, "customer.enrolled", eid, v.eligibility);
      return { id: eid, share_url: `${cfg.PUBLIC_ORIGIN}/r/${publicToken}` };
    },
  );
}
export function resolveOffer(db: Store, publicToken: string) {
  requireThat(
    /^[A-Za-z0-9_-]{43}$/.test(publicToken),
    404,
    "Offer unavailable",
  );
  const e = db.get<Enrollment>(
    "SELECT * FROM enrolments WHERE token_hash=? AND revoked=0",
    hash(publicToken),
  );
  requireThat(e, 404, "Offer unavailable");
  const v = db.get<Version>(
    "SELECT * FROM campaign_versions WHERE id=?",
    e.version_id,
  )!;
  const c = db.get<Campaign>(
    "SELECT * FROM campaigns WHERE id=?",
    v.campaign_id,
  )!;
  requireThat(
    c.status === "active" &&
      v.published_at &&
      v.starts_at <= now() &&
      v.ends_at > now(),
    410,
    "Offer is paused or outside its acceptance window",
  );
  requireThat(
    db.get<{ id: string }>(
      "SELECT id FROM campaign_versions WHERE campaign_id=? AND published_at IS NOT NULL ORDER BY version DESC LIMIT 1",
      v.campaign_id,
    )?.id === v.id,
    410,
    "This offer version was superseded. Ask the dealership for a current invitation.",
  );
  return { e, v, c };
}
export function publicOffer(db: Store, publicToken: string) {
  const { e, v, c } = resolveOffer(db, publicToken);
  const dealer = db.get<{ name: string }>(
    "SELECT name FROM tenants WHERE id=?",
    e.tenant_id,
  )!;
  return {
    campaign: c.name,
    dealer: dealer.name,
    version_id: v.id,
    version: v.version,
    referrer_amount: v.referrer_amount,
    recipient_amount: v.recipient_amount,
    discount_amount: v.discount_amount,
    currency: v.currency,
    terms: v.terms,
    ends_at: v.ends_at,
    purchase_by: v.purchase_by,
    demo: true,
  };
}
export function accept(
  db: Store,
  publicToken: string,
  input: unknown,
  key?: string,
) {
  const v = acceptanceSchema.parse(input);
  requireThat(
    v.email.endsWith(".invalid"),
    400,
    "Use a synthetic address ending in .invalid in this demo",
  );
  return operation(db, `accept:${hash(publicToken)}`, key, v, () => {
    const offer = resolveOffer(db, publicToken);
    requireThat(
      v.version_id === offer.v.id,
      409,
      "Offer version changed; reload before accepting",
    );
    const { e } = offer;
    const referrer = db.get<Customer>(
      "SELECT * FROM customers WHERE id=?",
      e.customer_id,
    )!;
    const receipt = token();
    const existing = db.get<{ id: string; enrolment_id: string }>(
      "SELECT id,enrolment_id FROM leads WHERE tenant_id=? AND email_normalized=?",
      e.tenant_id,
      v.email,
    );
    const self = referrer.email.toLowerCase() === v.email;
    if (existing || self) {
      if (existing && existing.enrolment_id !== e.id)
        db.run("UPDATE leads SET review=1 WHERE id=?", existing.id);
      db.run(
        "INSERT INTO reviews(id,tenant_id,object_id,kind,reason,created_at) VALUES (?,?,?,?,?,?)",
        id(),
        e.tenant_id,
        existing?.id || e.id,
        "attribution",
        "Repeated or conflicting acceptance requires dealer review",
        now(),
      );
    } else {
      const cid = id();
      const lid = id();
      const match = db.get(
        "SELECT id FROM customers WHERE tenant_id=? AND lower(email)=?",
        e.tenant_id,
        v.email,
      );
      // Public contact data never claims or merges an existing authenticated customer.
      db.run(
        "INSERT INTO customers(id,tenant_id,name,email,owner_id,created_at) VALUES (?,?,?,?,?,?)",
        cid,
        e.tenant_id,
        v.name,
        v.email,
        referrer.owner_id,
        now(),
      );
      db.run(
        "INSERT INTO leads VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        lid,
        e.tenant_id,
        e.id,
        cid,
        v.email,
        v.interest,
        "New",
        referrer.owner_id,
        Number(Boolean(match)),
        hash(receipt),
        now(),
      );
      appendConsent(
        db,
        e.tenant_id,
        cid,
        "offer",
        v.contact === "email",
        "public-acceptance",
        "demo-consent-v1",
      );
      appendConsent(
        db,
        e.tenant_id,
        cid,
        "marketing",
        v.marketing,
        "public-acceptance",
        "demo-consent-v1",
      );
      appendConsent(
        db,
        e.tenant_id,
        cid,
        "terms",
        true,
        "public-acceptance",
        offer.v.id,
      );
      queue(db, e.tenant_id, cid, "offer", `acceptance:${lid}`);
      audit(
        db,
        { user_id: "public", tenant_id: e.tenant_id } as Actor,
        "referral.accepted",
        lid,
      );
    }
    db.run("INSERT INTO receipts VALUES (?,?)", hash(receipt), now());
    return {
      receipt_token: receipt,
      status: "RECEIVED",
      message:
        "Your request is recorded. The dealership will review eligibility. No credit is earned by accepting.",
      credit_available: false,
    };
  });
}
export function leadActivity(
  db: Store,
  actor: Actor,
  lid: string,
  input: unknown,
) {
  const v = z
    .object({
      kind: z.enum(["note", "stage", "assign", "identity"]),
      note: z.string().trim().min(3).max(1500),
      value: z.string().max(100).optional(),
    })
    .strict()
    .parse(input);
  return db.transaction(() => {
    const l = lead(db, actor, lid);
    if (v.kind === "stage") {
      requireThat(
        ["New", "Contacted", "Qualified", "Lost"].includes(v.value || "") &&
          l.stage !== "Sold",
        400,
        "Use sale evidence to mark Sold",
      );
      if (v.value === "Contacted")
        requireThat(
          db.get<{ granted: number }>(
            "SELECT granted FROM consents WHERE customer_id=? AND purpose='offer' ORDER BY rowid DESC LIMIT 1",
            l.customer_id,
          )?.granted === 1,
          409,
          "No Contact: outreach is suppressed",
        );
      db.run("UPDATE leads SET stage=? WHERE id=?", v.value!, lid);
    }
    if (v.kind === "assign") {
      admin(actor);
      requireThat(
        db.get(
          "SELECT user_id FROM memberships WHERE user_id=? AND tenant_id=? AND role IN ('admin','sales') AND active=1",
          v.value || "",
          actor.tenant_id,
        ),
        400,
        "Choose active dealership staff",
      );
      db.run("UPDATE leads SET assigned_to=? WHERE id=?", v.value!, lid);
      db.run(
        "UPDATE customers SET owner_id=? WHERE id=?",
        v.value!,
        l.customer_id,
      );
    }
    if (v.kind === "identity") {
      admin(actor);
      requireThat(
        !db.get(
          "SELECT id FROM reviews WHERE object_id=? AND tenant_id=? AND kind='attribution' AND status='open'",
          lid,
          actor.tenant_id,
        ),
        409,
        "Resolve the attribution review before clearing identity checks",
      );
      db.run("UPDATE leads SET review=0 WHERE id=?", lid);
      db.run("UPDATE customers SET verified=1 WHERE id=?", l.customer_id);
    }
    db.run(
      "INSERT INTO activities VALUES (?,?,?,?,?,?,?)",
      id(),
      actor.tenant_id,
      lid,
      actor.user_id,
      v.kind,
      v.note,
      now(),
    );
    audit(db, actor, `lead.${v.kind}`, lid, v.note);
    return { id: lid };
  });
}
