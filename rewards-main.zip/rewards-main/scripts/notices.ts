import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
const packages = [
  ["react", "LICENSE"],
  ["react-dom", "LICENSE"],
  ["scheduler", "LICENSE"],
  ["react-router", "LICENSE.md"],
  ["react-router-dom", "LICENSE.md"],
  ["react-icons", "LICENSE"],
];
const blocks = packages.map(
  ([name, file]) =>
    `${name}\n${readFileSync(`node_modules/${name}/${file}`, "utf8")}`,
);
const mit = readFileSync("node_modules/react/LICENSE", "utf8").replace(
  "Copyright (c) Meta Platforms, Inc. and affiliates.",
  "Copyright (c) 2013-2023 Cole Bemis",
);
blocks.push(
  `Feather icons (only react-icons/fi is imported)\nSource: https://github.com/feathericons/feather/blob/main/LICENSE\n${mit}`,
);
mkdirSync("public", { recursive: true });
writeFileSync(
  "public/THIRD_PARTY_NOTICES.txt",
  `RewardPoint bundled frontend dependency notices\n\n${blocks.join("\n\n---\n\n")}`,
);
console.log(
  "Updated bundled frontend dependency notices. Server dependencies retain their installed notices.",
);
