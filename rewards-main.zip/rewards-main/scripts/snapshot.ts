import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { resolve } from "node:path";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";

const name = process.argv[2];
if (!name || !/^[a-zA-Z0-9_-]{3,80}$/.test(name))
  throw new Error(
    "Provide an artifact name using letters, digits, hyphen or underscore",
  );
const target = resolve(".local/releases", name);
if (existsSync(target)) throw new Error("Immutable artifact already exists");
if (
  !existsSync("dist/index.html") ||
  !existsSync("dist-server/server/index.js")
)
  throw new Error("Build first");
mkdirSync(target, { recursive: true, mode: 0o700 });
for (const dir of ["dist", "dist-server"])
  cpSync(dir, resolve(target, dir), { recursive: true });
writeFileSync(
  resolve(target, "package.json"),
  JSON.stringify({ type: "module" }),
);
writeFileSync(
  resolve(target, "manifest.json"),
  JSON.stringify(
    {
      name,
      created_at: new Date().toISOString(),
      git_head: execFileSync("git", ["rev-parse", "HEAD"], {
        encoding: "utf8",
      }).trim(),
      dirty: Boolean(
        execFileSync("git", ["status", "--porcelain"], {
          encoding: "utf8",
        }).trim(),
      ),
      lock_sha256: createHash("sha256")
        .update(readFileSync("package-lock.json"))
        .digest("hex"),
    },
    null,
    2,
  ),
);
console.log(
  `Preserved build artifact ${name}; database and secrets were not copied.`,
);
