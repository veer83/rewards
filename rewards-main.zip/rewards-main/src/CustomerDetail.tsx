import { useEffect, useState } from "react";
import { api, date, money } from "./api";
import { ActionForm, Badge, Empty, Notice, Table } from "./ui";
import type { Customer, Grant, Me } from "./shared";

interface History {
  consents: {
    id: string;
    purpose: string;
    granted: number;
    source: string;
    created_at: string;
  }[];
  invitations: {
    id: string;
    purpose: string;
    status: string;
    created_at: string;
  }[];
  enrollments: {
    id: string;
    campaign: string;
    version: number;
    revoked: number;
  }[];
}
export function CustomerDetail({
  customer,
  me,
}: {
  customer: Customer;
  me: Me;
}) {
  const [data, setData] = useState<History | null>(null),
    [credits, setCredits] = useState<Grant[]>([]),
    [error, setError] = useState(""),
    [revision, setRevision] = useState(0),
    [saved, setSaved] = useState(false);
  useEffect(() => {
    const c = new AbortController();
    setError("");
    Promise.all([
      api<History>(
        `/customers/${customer.id}/history`,
        undefined,
        undefined,
        c.signal,
      ),
      me.role === "sales"
        ? Promise.resolve([])
        : api<Grant[]>(
            `/customers/${customer.id}/credit`,
            undefined,
            undefined,
            c.signal,
          ),
    ])
      .then(([h, g]) => {
        if (!c.signal.aborted) {
          setData(h);
          setCredits(g);
        }
      })
      .catch((e) => {
        if (!c.signal.aborted) setError(e.message);
      });
    return () => c.abort();
  }, [customer.id, me.role, revision]);
  if (error)
    return (
      <Notice error>
        {error}
        <button onClick={() => setRevision((n) => n + 1)}>Retry</button>
      </Notice>
    );
  if (!data) return <Notice>Loading customer history...</Notice>;
  return (
    <div className="padded">
      <div className="customer-details">
        <div>
          <p className="eyebrow">CUSTOMER PROFILE</p>
          <h3>{customer.name}</h3>
          <p>{customer.email}</p>
          <p>{customer.dealer_reference || "No dealer reference recorded"}</p>
          <Badge tone={customer.verified ? "success" : "warning"}>
            {customer.verified
              ? "Identity independently verified"
              : "Identity not verified"}
          </Badge>
        </div>
        {me.role !== "sales" && (
          <div>
            <p className="eyebrow">SERVICE CREDIT</p>
            <h2>{money(credits.reduce((s, g) => s + g.available, 0))}</h2>
            <p>Available, excluding holds and frozen credit.</p>
            <small>
              {money(credits.reduce((s, g) => s + g.held, 0))} reserved
            </small>
          </div>
        )}
      </div>
      <h3>Campaign enrollments</h3>
      {data.enrollments.length ? (
        data.enrollments.map((e) => (
          <p key={e.id}>
            {e.campaign} · v{e.version}{" "}
            <Badge>{e.revoked ? "Revoked" : "Active link"}</Badge>
          </p>
        ))
      ) : (
        <Empty>No enrollments yet.</Empty>
      )}
      <h3>Consent history</h3>
      <Table
        label="Customer consents"
        headers={["Purpose", "Preference", "Recorded"]}
      >
        {data.consents.map((c) => (
          <tr key={c.id}>
            <td>{c.purpose}</td>
            <td>
              <Badge tone={c.granted ? "success" : "warning"}>
                {c.granted ? "Granted" : "Not granted / withdrawn"}
              </Badge>
            </td>
            <td>{date(c.created_at)}</td>
          </tr>
        ))}
      </Table>
      <h3>Invitation & notification history</h3>
      {data.invitations.length ? (
        data.invitations.map((i) => (
          <p key={i.id}>
            {i.purpose} <Badge>{i.status}</Badge>{" "}
            <small>{date(i.created_at)}</small>
          </p>
        ))
      ) : (
        <Empty>No notification activity.</Empty>
      )}
      {me.role === "customer" && (
        <>
          <h3>Your communication preferences</h3>
          <p>
            Offer contact, invitations and marketing are separate choices. Every
            change is recorded.
          </p>
          {saved && <Notice>Your preference was saved.</Notice>}
          <ActionForm
            path={`/customers/${customer.id}/consents`}
            fields={[
              {
                name: "purpose",
                label: "Contact purpose",
                options: [
                  { value: "offer", label: "Contact about accepted offer" },
                  { value: "marketing", label: "Future email marketing" },
                  { value: "invitation", label: "Referral invitations" },
                ],
              },
              {
                name: "granted",
                label:
                  "Allow this type of contact (leave unchecked to withdraw)",
                type: "checkbox",
              },
              {
                name: "evidence",
                label: "Your instruction",
                value: "I am updating my own communication preference",
              },
            ]}
            onDone={() => {
              setSaved(true);
              setRevision((n) => n + 1);
            }}
          />
        </>
      )}
    </div>
  );
}
