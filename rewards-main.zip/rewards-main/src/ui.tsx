import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { FiX, FiSun, FiMoon, FiMonitor, FiArrowRight } from "react-icons/fi";
import { api } from "./api";

export function Brand() {
  return (
    <div className="brand">
      <span className="brand-word">
        DriveOnyx<small>REWARDPOINT</small>
      </span>
    </div>
  );
}
export function Theme() {
  const [mode, setMode] = useState(
    () => localStorage.getItem("rewardpoint-theme") || "system",
  );
  useEffect(() => {
    const query = matchMedia("(prefers-color-scheme: dark)");
    const apply = () =>
      (document.documentElement.dataset.theme =
        mode === "system" ? (query.matches ? "dark" : "light") : mode);
    apply();
    query.addEventListener("change", apply);
    localStorage.setItem("rewardpoint-theme", mode);
    return () => query.removeEventListener("change", apply);
  }, [mode]);
  return (
    <label className="theme-control">
      {mode === "dark" ? (
        <FiMoon />
      ) : mode === "light" ? (
        <FiSun />
      ) : (
        <FiMonitor />
      )}
      <span className="sr-only">Theme</span>
      <select
        aria-label="Theme"
        value={mode}
        onChange={(e) => setMode(e.target.value)}
      >
        <option value="light">Light</option>
        <option value="dark">Dark</option>
        <option value="system">System</option>
      </select>
    </label>
  );
}
export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: string;
}) {
  return <span className={`badge ${tone}`}>{children}</span>;
}
export function Empty({ children }: { children: ReactNode }) {
  return <div className="empty">{children}</div>;
}
export function Notice({
  children,
  error = false,
}: {
  children: ReactNode;
  error?: boolean;
}) {
  return (
    <div
      className={`notice ${error ? "error" : ""}`}
      role={error ? "alert" : "status"}
    >
      {children}
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current!;
    const opener =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    d.showModal();
    return () => {
      d.close();
      queueMicrotask(() => {
        if (opener?.isConnected) opener.focus();
      });
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className={wide ? "wide" : ""}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      aria-labelledby="dialog-title"
    >
      <header className="modal-header">
        <h2 id="dialog-title">{title}</h2>
        <button
          className="icon-button"
          aria-label="Close dialog"
          onClick={onClose}
        >
          <FiX />
        </button>
      </header>
      {children}
    </dialog>
  );
}
export interface Field {
  name: string;
  label: string;
  type?: string;
  value?: string | number | boolean;
  required?: boolean;
  hint?: string;
  options?: { value: string; label: string }[];
  min?: number;
  max?: number;
}
export function ActionForm({
  fields,
  path,
  extra = {},
  submit = "Save",
  onDone,
}: {
  fields: Field[];
  path: string;
  extra?: Record<string, unknown>;
  submit?: string;
  onDone: (result: Record<string, unknown>) => void;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const pending = useRef({ payload: "", key: "" });
  async function send(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const body: Record<string, unknown> = { ...extra };
    for (const f of fields)
      body[f.name] =
        f.type === "checkbox"
          ? form.has(f.name)
          : f.type === "number"
            ? Number(form.get(f.name))
            : f.type === "datetime-local"
              ? new Date(String(form.get(f.name))).toISOString()
              : String(form.get(f.name) || "");
    const payload = JSON.stringify(body);
    if (pending.current.payload !== payload)
      pending.current = { payload, key: crypto.randomUUID() };
    try {
      onDone(await api(path, body, pending.current.key));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={send} className="form-stack">
      {fields.map((f) => (
        <label
          className={f.type === "checkbox" ? "check-field" : "field"}
          key={f.name}
        >
          {f.type !== "checkbox" && <span>{f.label}</span>}
          {f.options ? (
            <select
              aria-label={f.label}
              name={f.name}
              defaultValue={String(f.value || "")}
              required={f.required !== false}
            >
              <option value="" disabled>
                Select...
              </option>
              {f.options.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          ) : f.type === "textarea" ? (
            <textarea
              aria-label={f.label}
              name={f.name}
              defaultValue={String(f.value || "")}
              required={f.required !== false}
              maxLength={5000}
            />
          ) : (
            <input
              aria-label={f.label}
              name={f.name}
              type={f.type || "text"}
              step={f.type === "datetime-local" ? 0.001 : undefined}
              defaultValue={
                f.type === "checkbox" ? undefined : String(f.value ?? "")
              }
              defaultChecked={
                f.type === "checkbox" ? Boolean(f.value) : undefined
              }
              required={
                f.type === "checkbox"
                  ? f.required === true
                  : f.required !== false
              }
              min={f.min}
              max={f.max}
              maxLength={f.type === "password" ? 128 : 500}
              autoComplete={f.type === "password" ? "current-password" : "off"}
            />
          )}{" "}
          {f.type === "checkbox" && <span>{f.label}</span>}
          {f.hint && <small>{f.hint}</small>}
        </label>
      ))}
      {error && <Notice error>{error}</Notice>}
      <div className="form-footer">
        <button className="primary" disabled={busy}>
          {busy ? "Saving..." : submit}
          <FiArrowRight />
        </button>
      </div>
    </form>
  );
}
export function Table({
  headers,
  children,
  label,
}: {
  headers: string[];
  children: ReactNode;
  label: string;
}) {
  return (
    <div className="table-scroll" role="region" aria-label={label} tabIndex={0}>
      <table>
        <thead>
          <tr>
            {headers.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}
